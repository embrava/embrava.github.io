#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../EmbravaApi/embravaapi.h"

int nNumberOfBlyncDevices = 0;

int main(int argc, char* argv[])
{
	int nNumberOfDevices = 0;

	// Find and open Embrava Blync Devices
	InitBlyncDevices(&nNumberOfDevices, aosDeviceInfo);

        // Check bitness 64 bit or 32 bit
        // printf("sizeof(size_t): %d\n", sizeof(size_t));
	if (nNumberOfDevices > 0)
	{
		printf("Number of Embrava Devices detected: %d\n", nNumberOfDevices);
	}
	else
	{
		printf("No Embrava Devices detected\n");
		printf("Exiting...\n");
		return(0);
	}

	printf("Devices:\n");

	// Print Device name
	for (int i=0; i < nNumberOfDevices; i++)
	{
		printf("%s", aosDeviceInfo[i].pchDeviceName);
		printf("\n");
	}

	// Turning on Green light for 5 seconds
	printf("Turning On Green Light for 5 seconds\n");

	for (int i=0; i < nNumberOfDevices; i++)
	{
		TurnOnGreenLight(i);
	}

	usleep(5000 * 1000);

	printf("Turning Off Light\n");

	for (int i=0; i < nNumberOfDevices; i++)
	{
		ResetLight(i);
	}
	
	CloseDevices(nNumberOfDevices);

	printf("Exiting...\n");

	return 0;
}
