#ifndef _BLYNCLIGHTNATIVE_H_
#define _BLYNCLIGHTNATIVE_H_

	#include <Windows.h>

	#ifdef BLYNCLIGHTNATIVE_EXPORTS
	#define BLYNCLIGHTNATIVE_API __declspec(dllexport)
	#else
	#define BLYNCLIGHTNATIVE_API __declspec(dllimport)
	#endif

	#define MAX_DEVICES												10

	#define DEVICETYPE_NODEVICE_INVALIDDEVICE_TYPE					0
	#define DEVICETYPE_BLYNC_CHIPSET_TENX_10						1
	#define DEVICETYPE_BLYNC_CHIPSET_TENX_20						2
	#define DEVICETYPE_BLYNC_CHIPSET_V30							3
	#define DEVICETYPE_BLYNC_CHIPSET_V30S							4
	#define DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110			5
	#define DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S					6
	#define DEVICETYPE_BLYNC_MINI_CHIPSET_V30S						7
	#define DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120			8
	#define DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA				9
	#define DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210			10
	#define DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220			11
	#define DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30					12
	#define DEVICETYPE_BLYNC_MINI_CHIPSET_V40S						13
	#define DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S					14
	#define DEVICETYPE_BLYNC_CHIPSET_V40							15
	#define DEVICETYPE_BLYNC_CHIPSET_V40S							16
	#define DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE						17
	#define DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR			21
	#define DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20			22 // version 2.0 - BrightTrend devices
	#define DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20					23
	#define DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20					24

	typedef struct _sDeviceInfo
	{
		HANDLE pHandle;
		char szDeviceName[MAX_PATH];
		wchar_t szDevicePath[MAX_PATH];
		int nDeviceIndex;
		BYTE byDeviceType;
		BYTE abyBlyncOutputReportBuffer[9];
		BYTE abyBlyncOutputReportBufferPreviousValue[9];

	} DEVICEINFO, *PDEVICEINFO;

	// Exported DEVICEINFO struct variable
	extern BLYNCLIGHTNATIVE_API DEVICEINFO aoDevInfo[MAX_DEVICES];

	int InitBlyncDevices();
	void CloseDevices(int nNumberOfDevices);
	BOOL ResetLight(int nDeviceIndex);
	BOOL TurnOnRGBLights(int nDeviceIndex, BYTE byRedLevel, BYTE byGreenLevel, BYTE byBlueLevel);
	BOOL TurnOnRedLight(int nDeviceIndex);
	BOOL TurnOnGreenLight(int nDeviceIndex);
	BOOL TurnOnBlueLight(int nDeviceIndex);
	BOOL TurnOnCyanLight(int nDeviceIndex);
	BOOL TurnOnMagentaLight(int nDeviceIndex);
	BOOL TurnOnYellowLight(int nDeviceIndex);
	BOOL TurnOnWhiteLight(int nDeviceIndex);
	BOOL TurnOnOrangeLight(int nDeviceIndex);
	BOOL SetLightDim(int nDeviceIndex);
	BOOL ClearLightDim(int nDeviceIndex);
	BOOL SelectLightFlashSpeed(int nDeviceIndex, BYTE bySelectedFlashSpeed);
	BOOL StartLightFlash(int nDeviceIndex);
	BOOL StopLightFlash(int nDeviceIndex);
	BOOL SelectMusicToPlay(int nDeviceIndex, BYTE bySelectedMusic);
	BOOL StartMusicPlay(int nDeviceIndex);
	BOOL StopMusicPlay(int nDeviceIndex);
	BOOL SetMusicRepeat(int nDeviceIndex);
	BOOL ClearMusicRepeat(int nDeviceIndex);
	BOOL SetMusicVolume(int nDeviceIndex, BYTE byVolumeLevel);
	BOOL SetVolumeMute(int nDeviceIndex);
	BOOL ClearVolumeMute(int nDeviceIndex);
	UINT64 GetDeviceUniqueId(int nDeviceIndex);

#endif
