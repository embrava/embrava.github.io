Installation of Embrava Connect Software:
------------------------------------------

EmbravaConnect.msi;
--------------------

If you are using EmbravaConnect.msi to install Embrava Connect software, you have optional command line parameters for certain customizations during installation.

Default installation:
----------------------

Install the software by running the MSI installer EmbravaConnect.msi, it will install the Embrava Connect with default settings. After installation of the software, 
the user will be prompted for selecting the necessary Connections such as Skype for Business, Microsoft Teams, Cisco Jabber, RingCentral, Skype for Business (Server Side), Skype for Home, 
CounterPath Bria, BroadView OfficeSuite Softphone, Broadsoft, Genesys Premium, Plantronics Hub and Manual mode. The user can select the connections they require and apply the settings accordingly.

Command line usage and parameters:
----------------------------------

Example:

msiexec /i EmbravaConnect.msi /qn Connections=SFB ConnectionsSelected=SFB SilentConnectionSettings=Yes StartApp=Yes

1. All the msiexec specific flags or parameters are applicable.

2. User specific parameters:

a. Connections
---------------

Use this parameter to add only user specific Connections to the Embrava Conenct Connections list, so that the unwanted connections will not be listed on the Available Connections list
in the Manage Connections dialog of the Embrava Connect software. By default, i.e. without using this parameter, after installation and running the Embrava Connect application, 
all the connections will be added to the Embrava Connect application.

usage:
Connections=SFB;TEAMS;CJAB;SFH;RNG;SFBSERVER;BRIA;BROADVIEW;MANUAL;BROADSOFT;GENPREMIUM;PHUB

The above will add Skype for Business, Microsoft Teams, Cisco Jabber, RingCentral, Skype for Home, Skype for Business Server Side, CounterPath Bria, BroadView OfficeSuite Softphone,  Broadsoft, Genesys Premium,Plantronics Hub and Manual connections to the Embrava Connect Application's connection list.  In multiple connection environment, the connections priority will be based on the order in which the connections are entered in the "Connections" parameter. 
For example in the above, the higher priority connection will be SFB, then Cisco Jabber, then Skype for Home and so on.

Adding only one connection:

Connections=SFB

The above will add only Skype for Business to the Embrava Connect Application's connection list.

Parameter details:

SFB - Skype for Business
TEAMS - Microsoft Teams
CJAB - Cisco Jabber
RNG - RingCentral
SFH - Skype for Home
SFBSERVER - Skype for Business Server Side
BRIA - CounterPath Bria
BROADVIEW - BroadView OfficeSuite Softphone
MANUAL - Manual
BROADSOFT - Broadsoft UC Communicator
GENPREMIUM - Genesys Premium 
PHUB - Plantronics Hub


b. ConnectionsSelected
-----------------------

It is used to select the connections in the connections list. So the user is not required to check in the connections list in the Manage connections dialog of Embrava Connect
application.

usage:
ConnectionsSelected=SFB

For example, if Connections=SFB and ConnectionsSelected=SFB, then on the Manage Connections dialog of the Embrava Connect application, the user will see the Skype for Business 
connection selected by default.

This parameter "ConnectionsSelected" will be applicable only when the parameter "Connections" is entered in the command line.

c. SilentConnectionSettings
----------------------------

This parameter is used to avoid user intervention in selecting the connections in the Manage Connections dialog. 

usage:

SilentConnectionSettings=Yes

For example if Connections=SFB and ConnectionsSelected=SFB and SilentConnectionSettings=Yes - as entered on the command line during installation, then once the Embrava Connect 
application is executed after installation the user is not required to make any configuration changes and the device will begin syncing with Skype for Business immediately.

This parameter "SilentConnectionSettings" will be applicable only when the parameters "Connections" and "ConnectionsSelected" is entered in the command line.

d. StartApp
------------

This parameter is used to automatically start the Embrava Connect application once the installation finishes through commandline.

usage:

StartApp=Yes

If its not intended to automatically start the application please don't add this parameter in the commandline.

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

SCCM Deployment of Embrava Connect Software - starting installation with EmbravaConnect.msi:

You can use EmbravaConnect.msi file for sccm deployment.

Command line usage:

msiexec /i EmbravaConnect.msi /qn

You can deploy the software through msi deployment and the user specific parameters are applicable in the command line.
