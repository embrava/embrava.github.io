﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Blynclight;
using System.Threading;
using System.Runtime.InteropServices;
using System.IO;

namespace BlyncLightTest
{
    public partial class Form1 : Form
    {
        // Create object for the base class BlynclightController
        internal BlynclightController oBlynclightController = new BlynclightController();

        private int nNumberOfBlyncDevices = 0;
        private int nSelectedDeviceIndex = 0;

        internal const byte DEVICETYPE_NODEVICE_INVALIDDEVICE_TYPE = 0x00;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_TENX_10 = 0x01;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_TENX_20 = 0x02;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V30 = 0x03;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V30S = 0x04;
        internal const byte DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 = 0x05;
        internal const byte DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S = 0x06;
        internal const byte DEVICETYPE_BLYNC_MINI_CHIPSET_V30S = 0x07;
        internal const byte DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 = 0x08;
        internal const byte DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA = 0x09;
        internal const byte DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 = 0x0A;
        internal const byte DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220 = 0x0B;
        internal const byte DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 = 0x0C;
        internal const byte DEVICETYPE_BLYNC_MINI_CHIPSET_V40S = 13;
        internal const byte DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S = 14;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V40 = 15;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V40S = 16;
        internal const byte DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE = 17;
        internal const byte DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR = 21;
        internal const byte DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 = 22; // version 2.0 - BrightTrend devices
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 = 23;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 = 24;

        private byte bySelectedMusic = 1;
        private byte bySelectedFlashSpeed = 1;
        private byte byVolumeLevel = 5;

        private string[] arrMusicListForBlyncUSB30S = { 
                                                          "Music 1", "Music 2", "Music 3", "Music 4", "Music 5", 
                                                          "Music 6", "Music 7", "Music 8", "Music 9", "Music 10"
                                                      };
        
        private string[] arrMusicListForBlyncMiniWireless = { 
                                                                "Music 1", "Music 2", "Music 3", "Music 4", "Music 5", 
                                                                "Music 6", "Music 7", "Music 8", "Music 9", "Music 10", 
                                                                "Music 11", "Music 12", "Music 13", "Music 14"
                                                            };

        /*private bool bLumenaBluetoothDeviceNotificationInterfaceAvailable = false;
        private Thread[] threadReadInputReport = new Thread[10];
        private ThreadProc[] aoThreadProc= ThreadProc.NewInitArray(10);
        // private int nNumberOfLumenaBluetoothHeadsetDevices = 0;*/

        internal const UInt32 ERROR_IO_PENDING = 997;
        internal const UInt32 INFINITE = 0xFFFFFFFF;
        internal const UInt32 WAIT_ABANDONED = 0x00000080;
        internal const UInt32 WAIT_OBJECT_0 = 0x00000000;
        internal const UInt32 WAIT_TIMEOUT = 0x00000102;

        // Logging support
        private bool bloggingEnabled = false;
        private String strUserAppDir = "";
        private String strUserBlynclightTestDir = "";
        private String strLogFile = "";

        /*public class ThreadProc
        {
            public int nIndex = -1;
            
            public Form1 form1 = null;

            public bool bResult = true;

            public bool bExitFromReadThread = false;

            /*public void ReadInputReportThreadProc()
            {
                form1.WriteToLog("ReadInputReportThreadProc Enter");

                InitializeReadInputReport();

                bExitFromReadThread = false;

                while (true)
                {
                    if (bExitFromReadThread == true)
                    {
                        break;
                    }

                    bResult = ReadInputReport();

                    if (bResult == false)
                    {
                        bExitFromReadThread = true;
                    }

                    //Thread.Sleep(1);
                }

                form1.WriteToLog("ReadInputReportThreadProc Exit");
            }

            private void InitializeReadInputReport()
            {
                form1.WriteToLog("InitializeReadInputReport Enter");

                form1.oBlynclightController.aoDevInfo[nIndex].oNativeOverlapped.hEvent = NativeMethods.CreateEvent(IntPtr.Zero, true, false, "");                
                form1.oBlynclightController.aoDevInfo[nIndex].oNativeOverlapped.Offset = 0;

                form1.WriteToLog("InitializeReadInputReport Exit");
            }

            private bool ReadInputReport()
            {
                form1.WriteToLog("ReadInputReport Enter");

                bool bResult = true;
                uint unResult = 0;
                uint unError = 0;
                uint unNumberOfBytesRead = 0;
                byte[] abyReportBuffer = new byte[16];

                IntPtr psOverLapped = IntPtr.Zero;

                psOverLapped = Marshal.AllocHGlobal(Marshal.SizeOf(form1.oBlynclightController.aoDevInfo[nIndex].oNativeOverlapped));
                Marshal.StructureToPtr(form1.oBlynclightController.aoDevInfo[nIndex].oNativeOverlapped, psOverLapped, true);

                form1.WriteToLog("Calling ReadFile with device handle: " + form1.oBlynclightController.aoDevInfo[nIndex].pHandle.ToInt64());

                bResult = NativeMethods.ReadFile(form1.oBlynclightController.aoDevInfo[nIndex].pHandle, abyReportBuffer, 16, ref unNumberOfBytesRead, psOverLapped);

                do
                {
                    if (!bResult)
                    {
                        unError = NativeMethods.GetLastError();

                        form1.WriteToLog("Error from GetLastError: " + unError);

                        if (unError != ERROR_IO_PENDING)
                        {
                            bResult = false;
                            break;
                        }
                    }
                    else
                    {

                    }

                    unResult = NativeMethods.WaitForSingleObject(form1.oBlynclightController.aoDevInfo[nIndex].oNativeOverlapped.hEvent, INFINITE);

                    form1.WriteToLog("Result from WaitForSingleObject: " + unResult);

                    if (bExitFromReadThread == true)
                    {
                        return false;
                    }

                    switch (unResult)
                    {
                        case WAIT_OBJECT_0:
                            if (form1.oBlynclightController.aoDevInfo[nIndex].oNativeOverlapped.hEvent != IntPtr.Zero)
                            {
                                bResult = NativeMethods.ResetEvent(form1.oBlynclightController.aoDevInfo[nIndex].oNativeOverlapped.hEvent);
                            }
                            form1.WriteToLog("ReadFile Success");
                            form1.WriteToLog("abyReportBuffer: " );

                            for (int i = 0; i < abyReportBuffer.Length; i++)
                            {
                                form1.WriteToLog("abyReportBuffer[" + i + "]: " + abyReportBuffer[i]);
                            }

                            ProcessInputReport(abyReportBuffer);
                            bResult = true;
                            break;

                        case WAIT_TIMEOUT:
                            //form1.WriteToLog("ReadFile Timedout");
                            NativeMethods.CancelIo(form1.oBlynclightController.aoDevInfo[nIndex].pHandle);
                            bResult = false;
                            break;

                        default:
                            //form1.WriteToLog("Other Error Result");
                            bResult = false;
                            break;

                    }

                } while (false);

                if (psOverLapped != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(psOverLapped);
                    psOverLapped = IntPtr.Zero;
                }

                form1.WriteToLog("ReadInputReport Exit: " + bResult);

                return bResult;
            }

            private void ProcessInputReport(byte[] abyReportBuffer)
            {
                form1.WriteToLog("ProcessInputReport Enter");

                try
                {
                    if (abyReportBuffer[0] == 0x06)
                    {
                        if (abyReportBuffer[1] == 0x01)
                        {
                            form1.WriteToLog("OnCall Notification received from the device");

                            form1.BeginInvoke((Action)delegate
                            {
                                // Print the activity string
                                form1.textBoxLog.AppendText("OnCall:   ");
                                // Print the buffer contents
                                for (int i = 0; i < 16; i++)
                                {
                                    form1.textBoxLog.AppendText(abyReportBuffer[i].ToString("X2"));
                                    form1.textBoxLog.AppendText(" ");
                                }

                                form1.textBoxLog.AppendText("\n");
                                form1.textBoxLog.AppendText("\n");
                            });
                        }
                        else if (abyReportBuffer[1] == 0x00)
                        {
                            form1.WriteToLog("Standby Notification received from the device");

                            form1.BeginInvoke((Action)delegate
                            {
                                // Print the activity string
                                form1.textBoxLog.AppendText("Standby: ");
                                // Print the buffer contents
                                for (int i = 0; i < 16; i++)
                                {
                                    form1.textBoxLog.AppendText(abyReportBuffer[i].ToString("X2"));
                                    form1.textBoxLog.AppendText(" ");
                                }

                                form1.textBoxLog.AppendText("\n");
                                form1.textBoxLog.AppendText("\n");
                            });
                        }
                    }
                    else if (abyReportBuffer[0] == 0x07)
                    {
                        if (abyReportBuffer[1] == 0x01)
                        {
                            form1.WriteToLog("AnsweredCall Notification received from the device");

                            form1.BeginInvoke((Action)delegate
                            {
                                // Print the activity string
                                form1.textBoxLog.AppendText("AnsCall:   ");
                                // Print the buffer contents
                                for (int i = 0; i < 16; i++)
                                {
                                    form1.textBoxLog.AppendText(abyReportBuffer[i].ToString("X2"));
                                    form1.textBoxLog.AppendText(" ");
                                }

                                form1.textBoxLog.AppendText("\n");
                                form1.textBoxLog.AppendText("\n");
                            });
                        }
                    }
                    else if (abyReportBuffer[0] == 0x08)
                    {
                        if (abyReportBuffer[1] == 0x01)
                        {
                            form1.WriteToLog("EndCall Notification received from the device");

                            form1.BeginInvoke((Action)delegate
                            {
                                // Print the activity string
                                form1.textBoxLog.AppendText("EndCall:   ");
                                // Print the buffer contents
                                for (int i = 0; i < 16; i++)
                                {
                                    form1.textBoxLog.AppendText(abyReportBuffer[i].ToString("X2"));
                                    form1.textBoxLog.AppendText(" ");
                                }

                                form1.textBoxLog.AppendText("\n");
                                form1.textBoxLog.AppendText("\n");
                            });
                        }
                    }
                    else if (abyReportBuffer[0] == 0x09)
                    {
                        if (abyReportBuffer[1] == 0x01)
                        {
                            form1.WriteToLog("IncomingCall Notification received from the device");

                            form1.BeginInvoke((Action)delegate
                            {
                                // Print the activity string
                                form1.textBoxLog.AppendText("IncomingCall:   ");
                                // Print the buffer contents
                                for (int i = 0; i < 16; i++)
                                {
                                    form1.textBoxLog.AppendText(abyReportBuffer[i].ToString("X2"));
                                    form1.textBoxLog.AppendText(" ");
                                }

                                form1.textBoxLog.AppendText("\n");
                                form1.textBoxLog.AppendText("\n");
                            });
                        }
                        else if (abyReportBuffer[1] == 0x00)
                        {
                            form1.WriteToLog("OutgoingCall Notification received from the device");

                            form1.BeginInvoke((Action)delegate
                            {
                                // Print the activity string
                                form1.textBoxLog.AppendText("OutgoingCall:   ");
                                // Print the buffer contents
                                for (int i = 0; i < 16; i++)
                                {
                                    form1.textBoxLog.AppendText(abyReportBuffer[i].ToString("X2"));
                                    form1.textBoxLog.AppendText(" ");
                                }

                                form1.textBoxLog.AppendText("\n");
                                form1.textBoxLog.AppendText("\n");
                            });
                        }
                    }
                }
                catch (Exception ex)
                {

                }               

                form1.WriteToLog("ProcessInputReport Exit");
            }

            public void Cleanup()
            {
                if (nIndex < 0)
                {
                    return;
                }

                form1.WriteToLog("Threadproc Cleanup Entry");

                bExitFromReadThread = true;

                // Cancel the IO
                if (form1.oBlynclightController.aoDevInfo[nIndex].pHandle != IntPtr.Zero)
                {
                    NativeMethods.CancelIo(form1.oBlynclightController.aoDevInfo[nIndex].pHandle);
                }

                // Set events to signaled state
                if (form1.oBlynclightController.aoDevInfo[nIndex].oNativeOverlapped.hEvent != IntPtr.Zero)
                {
                    NativeMethods.SetEvent(form1.oBlynclightController.aoDevInfo[nIndex].oNativeOverlapped.hEvent);
                    form1.oBlynclightController.aoDevInfo[nIndex].oNativeOverlapped.hEvent = IntPtr.Zero;
                }

                form1.WriteToLog("Threadproc Cleanup Exit");
            }

            static internal ThreadProc[] NewInitArray(ulong num)
            {
                ThreadProc[] aoThreadProc = new ThreadProc[num];
                for (ulong i = 0; i < num; i++)
                {
                    aoThreadProc[i] = new ThreadProc();
                }
                return aoThreadProc;
            }
        }*/

        public Form1()
        {
            InitializeComponent();

            if (bloggingEnabled == true)
            {
                InitLogging(true);
                oBlynclightController.InitLogging();
            }

            WriteToLog("Main form Initializing");

            /*for (int i = 0; i < aoThreadProc.Length; i++)
            {
                aoThreadProc[i].form1 = this;
            }*/

            // Form_Closing event while exiting the application
            this.Closing += Form1_Closing;

            Byte bySelectedFlashSpeed = 0x04;
            Byte byLightControl = 0x00;
            
            byLightControl |= (Byte)((bySelectedFlashSpeed & 0x0F) << 3);

            //DisableUIComponentsForBlyncUsb1020Devices();
            DisableUIComponentsForBlyncUsb30Devices();

            /*var blc = new BlynclightController();
            for (var i = 0; i < 1000; ++i)
            {
                var numDevices = blc.InitBlyncDevices();
                blc.CloseDevices(numDevices);
            }*/

            SearchAndListBlyncDevices();

            //comboBoxMusicList.SelectedIndex = 0;
            comboBoxFlashSpeedList.SelectedIndex = 0;
            comboBoxFontsL1.SelectedIndex = 0;
            comboBoxFontsL2.SelectedIndex = 0;
        }

        private void InitLogging(bool bDeleteExistingLogFile)
        {
            if (bloggingEnabled == false)
            {
                return;
            }

            strUserAppDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            strUserBlynclightTestDir = strUserAppDir + "\\BlynclightTest";

            try
            {
                // If the directory doesn't exist, create it.
                if (!Directory.Exists(strUserBlynclightTestDir))
                {
                    Directory.CreateDirectory(strUserBlynclightTestDir);
                }

                strLogFile = strUserBlynclightTestDir + "\\dbglog_blynclighttest.txt";

                if (bDeleteExistingLogFile == true)
                {
                    if (File.Exists(strLogFile))
                    {
                        File.Delete(strLogFile);
                    }
                }


                // if the file doen't exist, create it.
                if (!File.Exists(strLogFile))
                {
                    File.Create(strLogFile).Close();
                    File.AppendAllText(strLogFile, "Debug Log written by BlynclightTest software:");
                    File.AppendAllText(strLogFile, Environment.NewLine);
                }
            }
            catch (Exception)
            {

            }
        }

        internal void WriteToLog(String logText)
        {
            if (bloggingEnabled == false)
            {
                return;
            }

            try
            {
                InitLogging(false);

                File.AppendAllText(strLogFile, DateTime.Now.ToString("HH:mm:ss.fff", System.Globalization.DateTimeFormatInfo.InvariantInfo) + "    ");
                File.AppendAllText(strLogFile, logText);
                File.AppendAllText(strLogFile, Environment.NewLine);
            }
            catch (Exception)
            {

            }
        }

        private void SearchAndListBlyncDevices()
        {
            WriteToLog("SearchAndListBlyncDevices Entry");

            // int nCbIndex = 0;

            // If there is already a list of devices, free the list of device and resources allocated
            comboBoxDeviceList.Items.Clear();

            // Look for the Blync devices connected to the System
            // the nNumberOfBlyncDevices will be equal to the number 
            // of Blync devices connected to the System USB Ports

            //bLumenaBluetoothDeviceNotificationInterfaceAvailable = false;
            //nNumberOfLumenaBluetoothHeadsetDevices = 0;

            CleanUp();

            WriteToLog("Searching for Blynclight devices");

            nNumberOfBlyncDevices = oBlynclightController.InitBlyncDevices();

            if (nNumberOfBlyncDevices > 0)
            {
                WriteToLog("Listing Blynclight devices");

                WriteToLog("Number of Blynclight devices: " + nNumberOfBlyncDevices);

                // Add the Blync devices detected to the combobox
                for (int i = 0; i < nNumberOfBlyncDevices; i++)
                {
                    comboBoxDeviceList.Items.Insert(i, oBlynclightController.aoDevInfo[i].szDeviceName);

                    if (oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_TENX_10 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_TENX_20)
                    {
                        //comboBoxDeviceList.Items.Insert(nCbIndex, oBlynclightController.aoDevInfo[i].szDeviceName);
                        //nCbIndex++;

                        //EnableUIComponentsForBlyncUsb1020Devices();
                        //DisableUIComponentsForBlyncUsb30Devices();
                    }
                    else if (oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
                    {
                        //comboBoxDeviceList.Items.Insert(nCbIndex, oBlynclightController.aoDevInfo[i].szDeviceName);
                        //nCbIndex++;

                        EnableUIComponentsForBlyncUsb30Devices();
                        //DisableUIComponentsForBlyncUsb1020Devices();
                    }
                    /*else if (oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210_NOTIFICATIONINTERFACE ||
                    oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220_NOTIFICATIONINTERFACE)
                    {
                        DisableUIComponentsForBlyncUsb1020Devices();
                        DisableUIComponentsForBlyncUsb30Devices();
                    }*/
                }

                comboBoxDeviceList.SelectedIndex = 0;
                nSelectedDeviceIndex = 0;

                /*// Check for the availability of Lumena 210/220 Bluetooth Headset devices
                for (int i = 0; i < nNumberOfBlyncDevices; i++)
                {
                    if (oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
                    {
                        bLumenaBluetoothDeviceNotificationInterfaceAvailable = true;
                        //nNumberOfLumenaBluetoothHeadsetDevices++;
                    }
                }

                // If Lumena 210/220 Bluetooth Headset devices are available start the thread that receives the input report from the 
                // devices for the following notifications - IsOnCall, AnsweredCall, EndCall

                if (bLumenaBluetoothDeviceNotificationInterfaceAvailable == true)
                {
                    WriteToLog("Lumena Bluetooth Headset Device Notification Interfaces detected");

                    for (int i = 0; i < nNumberOfBlyncDevices; i++)
                    {
                        if (oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 || 
                            oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
                        {
                            try
                            {
                                aoThreadProc[i].nIndex = i;
                                // aoThreadProc[i].form1 = this;
                                threadReadInputReport[i] = new Thread(new ThreadStart(aoThreadProc[i].ReadInputReportThreadProc));
                                threadReadInputReport[i].Priority = ThreadPriority.Normal;
                                // bExitFromReadThread = false;
                                threadReadInputReport[i].Start();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Exception: " + ex.Message, "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                            }
                        }
                    }
                }*/
            }
            else
            {
                MessageBox.Show("No Blync Devices Detected", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                // If device is not present disable all UI components
                //DisableUIComponentsForBlyncUsb1020Devices();
                DisableUIComponentsForBlyncUsb30Devices();
            }

            WriteToLog("SearchAndListBlyncDevices Exit");
        }

        /*private void EnableUIComponentsForBlyncUsb1020Devices()
        {
            WriteToLog("EnableUIComponentsForBlyncUsb1020Devices Entry");

            groupBoxOldDeviceControls.Enabled = true;

            WriteToLog("EnableUIComponentsForBlyncUsb1020Devices Exit");
        }

        private void DisableUIComponentsForBlyncUsb1020Devices()
        {
            WriteToLog("DisableUIComponentsForBlyncUsb1020Devices Entry");

            groupBoxOldDeviceControls.Enabled = false;

            WriteToLog("DisableUIComponentsForBlyncUsb1020Devices Exit");
        }
        */
        private void EnableUIComponentsForBlyncUsb30Devices()
        {
            WriteToLog("EnableUIComponentsForBlyncUsb30Devices Entry");

            groupBoxNameDisplayLcd.Enabled = false;

            groupBoxUID.Enabled = true;

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20)
            {
                groupBoxLightControls.Enabled = true;
                groupBoxMusicControls.Enabled = true;
            }
            else if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
            {
                groupBoxLightControls.Enabled = true;
                groupBoxMusicControls.Enabled = false;
            }

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20)
            {
                buttonWriteUid.Enabled = true;
                textBoxUid.Enabled = true;
                buttonIncUID.Enabled = true;
                buttonDecUID.Enabled = true;
                buttonGetUid.Enabled = true;
            }
            else
            {
                buttonWriteUid.Enabled = false;
                textBoxUid.Enabled = false;
                buttonIncUID.Enabled = false;
                buttonDecUID.Enabled = false;
                buttonGetUid.Enabled = true;
            }

            buttonGetNdUID.Enabled = false;
            buttonWriteNdUID.Enabled = false;
            textBoxNdUid.Enabled = false;

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE)
            {
                groupBoxNameDisplayLcd.Enabled = true;

                buttonGetUid.Enabled = false;
                buttonWriteUid.Enabled = false;
                textBoxUid.Enabled = false;

                buttonGetNdUID.Enabled = true;
                buttonWriteNdUID.Enabled = true;
                textBoxNdUid.Enabled = true;
            }

            WriteToLog("EnableUIComponentsForBlyncUsb30Devices Exit");
        }

        private void DisableUIComponentsForBlyncUsb30Devices()
        {
            WriteToLog("DisableUIComponentsForBlyncUsb30Devices Entry");

            groupBoxLightControls.Enabled = false;
            groupBoxMusicControls.Enabled = false;

            groupBoxNameDisplayLcd.Enabled = false;

            groupBoxUID.Enabled = false;

            WriteToLog("DisableUIComponentsForBlyncUsb30Devices Exit");
        } 

        private void comboBoxDeviceList_SelectedIndexChanged(object sender, EventArgs e)
        {
            WriteToLog("comboBoxDeviceList_SelectedIndexChanged Entry");

            /*if (comboBoxDeviceList.SelectedIndex >= 0)
            {
                nSelectedDeviceIndex = oBlynclightController.aoDevInfo[comboBoxDeviceList.SelectedIndex].nDeviceIndex;
            }*/

            nSelectedDeviceIndex = comboBoxDeviceList.SelectedIndex;

            if (nSelectedDeviceIndex >= 0)
            {
                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_TENX_10 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_TENX_20)
                {
                    //EnableUIComponentsForBlyncUsb1020Devices();
                    //DisableUIComponentsForBlyncUsb30Devices();
                }
                else if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
                {
                    EnableUIComponentsForBlyncUsb30Devices();
                    //DisableUIComponentsForBlyncUsb1020Devices();

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR)
                    {
                        if (comboBoxMusicList.Items.Count > 0)
                        {
                            comboBoxMusicList.Items.Clear();                            
                        }

                        for (int j = 0; j < arrMusicListForBlyncUSB30S.Length; j++)
                        {
                            comboBoxMusicList.Items.Insert(j, arrMusicListForBlyncUSB30S[j]);
                        }

                        comboBoxMusicList.SelectedIndex = 0;
                    }
                    else if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        if (comboBoxMusicList.Items.Count > 0)
                        {
                            comboBoxMusicList.Items.Clear();
                        }

                        for (int j = 0; j < arrMusicListForBlyncMiniWireless.Length; j++)
                        {
                            comboBoxMusicList.Items.Insert(j, arrMusicListForBlyncMiniWireless[j]);
                        }

                        comboBoxMusicList.SelectedIndex = 0;
                    }
                }
            }

            WriteToLog("comboBoxDeviceList_SelectedIndexChanged Exit");
        }

        private void buttonRed_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonRed_Click Entry");
            // Call TurnOnRedLight and pass the nSelectedDeviceIndex.
            // nSelectedDeviceIndex value will be updated on device selection in the Combo box

            bool bResult = false;
            bResult = oBlynclightController.TurnOnRedLight(nSelectedDeviceIndex);

            WriteToLog("buttonRed_Click Exit");
        }

        private void buttonBlue_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonBlue_Click Entry");
            oBlynclightController.TurnOnBlueLight(nSelectedDeviceIndex);
            WriteToLog("buttonBlue_Click Exit");
        }

        private void buttonMagenta_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonMagenta_Click Entry");
            oBlynclightController.TurnOnMagentaLight(nSelectedDeviceIndex);
            WriteToLog("buttonMagenta_Click Exit");
        }

        private void buttonCyan_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonCyan_Click Entry");
            oBlynclightController.TurnOnCyanLight(nSelectedDeviceIndex);
            WriteToLog("buttonCyan_Click Exit");
        }

        private void buttonGreen_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonGreen_Click Entry");
            oBlynclightController.TurnOnGreenLight(nSelectedDeviceIndex);
            WriteToLog("buttonGreen_Click Exit");
        }

        private void buttonYellow_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonYellow_Click Entry");
            oBlynclightController.TurnOnYellowLight(nSelectedDeviceIndex);
            WriteToLog("buttonYellow_Click Exit");
        }

        private void buttonWhite_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonWhite_Click Entry");
            oBlynclightController.TurnOnWhiteLight(nSelectedDeviceIndex);
            WriteToLog("buttonWhite_Click Exit");
        }

        private void buttonResetEffects_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonResetEffects_Click Entry");
            oBlynclightController.ResetLight(nSelectedDeviceIndex);
            WriteToLog("buttonWhite_Click Exit");
        }

        private void buttonUpdateDevList_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonUpdateDevList_Click Entry");

            SearchAndListBlyncDevices();

            String nameString = "ABCDEFGHI";

            Byte[] abyCommandBuffer = new Byte[64];

            for (int i = 0; i < abyCommandBuffer.Length; i++)
            {
                abyCommandBuffer[i] = 0;
            }

            if (String.IsNullOrEmpty(nameString) == true)
            {
                return;
            }

            byte[]? nameStringAscii = null;

            try
            {
                nameStringAscii = ASCIIEncoding.ASCII.GetBytes(nameString);
            }
            catch (Exception)
            {
                return;
            }

            if (nameStringAscii == null)
            {
                return;
            }

            if (nameStringAscii.Length == 0)
            {
                return;
            }

            byte byNameStringLength = (Byte)nameStringAscii.Length;

            if (byNameStringLength > 29)
            {
                byNameStringLength = 29;
            }

            abyCommandBuffer[0] = (Byte)(nameStringAscii.Length + 3);

            abyCommandBuffer[1] = 0x3C;
            abyCommandBuffer[2] = 0x01;

            Array.Copy(nameStringAscii, 0, abyCommandBuffer, 3, byNameStringLength);

            abyCommandBuffer[(byNameStringLength + 3)] = 0x3E;

            WriteToLog("buttonUpdateDevList_Click Exit");
        }

        private void Form1_Closing(object? sender, CancelEventArgs e)
        {
            WriteToLog("Form1_Closing Entry");

            if (nNumberOfBlyncDevices > 0)
            {
                for (int i = 0; i < nNumberOfBlyncDevices; i++)
                {
                    oBlynclightController.ResetLight(i);

                    byte byDetectedDeviceType = oBlynclightController.aoDevInfo[i].byDeviceType;

                    // Clear Music
                    if (byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        oBlynclightController.StopMusicPlay(i);
                        oBlynclightController.ClearMusicRepeat(i);
                        oBlynclightController.SetVolumeMute(i);
                    }

                    // Clear light
                    if (byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 || 
                        byDetectedDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
                    {
                        oBlynclightController.StopLightFlash(i);
                        oBlynclightController.ClearLightDim(i);
                        oBlynclightController.ResetLight(i);
                    }
                }

                CleanUp();
            }

            WriteToLog("Form1_Closing Exit");
        }

        private void checkBoxDisplayLight_CheckedChanged(object sender, EventArgs e)
        {
            WriteToLog("checkBoxDisplayLight_CheckedChanged Entry");

            bool bDisplayLight = checkBoxDisplayLight.Checked;
            bool bResult = false;

            // Select turn on or off light based on check box value
            if (bDisplayLight == true)
            {
                // Send the RGB color values
                SetRgbValues();
            }
            else
            {
                bResult = oBlynclightController.ResetLight(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("TurnOffLight failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }

                //pictureBoxColorDisplayed.BackColor = Color.FromArgb(0, 0, 0);

                StopPulsating = true;
                WaitForPulsatingInProgress();
            }

            WriteToLog("checkBoxDisplayLight_CheckedChanged Exit");
        }

        private void checkBoxPlayMusic_CheckedChanged(object sender, EventArgs e)
        {
            WriteToLog("checkBoxPlayMusic_CheckedChanged Entry");

            bool bPlayMusic = checkBoxPlayMusic.Checked;
            bool bResult = false;
            byVolumeLevel = (Byte)trackBar1.Value;
            
            bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
            {
                Thread.Sleep(250);
            }            

            bResult = oBlynclightController.SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
            {
                Thread.Sleep(250);
            }

            bResult = oBlynclightController.SetMusicVolume(nSelectedDeviceIndex, byVolumeLevel);

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
            {
                Thread.Sleep(250);
            }

            if (bPlayMusic == true)
            {
                if (checkBoxRepeatMusic.Checked == true)
                {
                    bResult = oBlynclightController.SetMusicRepeat(nSelectedDeviceIndex);
                }
                else
                {
                    //bResult = oBlynclightController.ClearMusicRepeat(nSelectedDeviceIndex);
                }

                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                {
                    Thread.Sleep(500);
                }

                bResult = oBlynclightController.StartMusicPlay(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("StartMusicPlay failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }

                //Thread.Sleep(100);

                /*bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("StopMusicPlay failed", "Information",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }*/
            }
            else
            {
                bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("StopMusicPlay failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }

            WriteToLog("checkBoxPlayMusic_CheckedChanged Exit");
        }

        private void checkBoxDimLight_CheckedChanged(object sender, EventArgs e)
        {
            WriteToLog("checkBoxDimLight_CheckedChanged Entry");

            bool bDimLight = checkBoxDimLight.Checked;
            bool bResult = false;

            if (bDimLight == true)
            {
                bResult = oBlynclightController.SetLightDim(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("SetLightDim failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }
            else
            {
                bResult = oBlynclightController.ClearLightDim(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("ClearLightDim failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }

            WriteToLog("checkBoxDimLight_CheckedChanged Exit");
        }

        private void checkBoxFlashLight_CheckedChanged(object sender, EventArgs e)
        {
            WriteToLog("checkBoxFlashLight_CheckedChanged Entry");

            bool bFlashLight = checkBoxFlashLight.Checked;
            bool bResult = false;

            if (bFlashLight == true)
            {
                bResult = oBlynclightController.StartLightFlash(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("StartLightFlash failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }
            else
            {
                bResult = oBlynclightController.StopLightFlash(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("StopLightFlash failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }

            // Select light flash speed
            bResult = oBlynclightController.SelectLightFlashSpeed(nSelectedDeviceIndex, bySelectedFlashSpeed);
            if (bResult == false)
            {
                MessageBox.Show("SelectLightFlashSpeed failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }

            WriteToLog("checkBoxFlashLight_CheckedChanged Exit");
        }

        private void checkBoxRepeatMusic_CheckedChanged(object sender, EventArgs e)
        {
            WriteToLog("checkBoxRepeatMusic_CheckedChanged Entry");

            bool bRepeatMusic = checkBoxRepeatMusic.Checked;
            bool bResult = false;

            if (bRepeatMusic == true)
            {
                if (checkBoxPlayMusic.Checked == true)
                {
                    bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);

                    bResult = oBlynclightController.SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        Thread.Sleep(250);
                    }

                    bResult = oBlynclightController.SetMusicVolume(nSelectedDeviceIndex, byVolumeLevel);

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        Thread.Sleep(250);
                    }

                    bResult = oBlynclightController.SetMusicRepeat(nSelectedDeviceIndex);

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        Thread.Sleep(300);
                    }

                    bResult = oBlynclightController.StartMusicPlay(nSelectedDeviceIndex);
                }
            }
            else
            {
                bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);
                bResult = oBlynclightController.ClearMusicRepeat(nSelectedDeviceIndex);

                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                {
                    Thread.Sleep(300);
                }
                
                bResult = oBlynclightController.StartMusicPlay(nSelectedDeviceIndex);
                bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);               
            }

            WriteToLog("checkBoxRepeatMusic_CheckedChanged Exit");
        }

        private void buttonSetRgbValues_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonSetRgbValues_Click Entry");

            if (checkBoxDisplayLight.Checked)
            {
                SetRgbValues();
            }

            WriteToLog("buttonSetRgbValues_Click Exit");
        }

        private void SetRgbValues()
        {
            WriteToLog("SetRgbValues Entry");

            Boolean bResult = false;

            Byte byRedLevel = 255;
            Byte byGreenLevel = 255;
            Byte byBlueLevel = 255;

            try
            {
                byRedLevel = Byte.Parse(textBoxRed.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\nPlease check Red color value. It should be a value from 0 to 255.", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            try
            {
                byGreenLevel = Byte.Parse(textBoxGreen.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\nPlease check Green color value. It should be a value from 0 to 255.", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            try
            {
                byBlueLevel = Byte.Parse(textBoxBlue.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\nPlease check Blue color value. It should be a value from 0 to 255.", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            bResult = oBlynclightController.TurnOnRGBLights(nSelectedDeviceIndex, byRedLevel, byGreenLevel, 
                byBlueLevel);

            if (!bResult)
            {
                MessageBox.Show("TurnOnRGBColors failed.", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }

            //pictureBoxColorDisplayed.BackColor = Color.FromArgb(byRedLevel, byGreenLevel, byBlueLevel);

            WriteToLog("SetRgbValues Exit");
        }

        private void comboBoxMusicList_SelectedIndexChanged(object sender, EventArgs e)
        {
            WriteToLog("comboBoxMusicList_SelectedIndexChanged Entry");

            bySelectedMusic = (Byte)(comboBoxMusicList.SelectedIndex + 1);

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20)
            {
                if (checkBoxPlayMusic.Checked == true)
                {
                    bool bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);

                    bResult = oBlynclightController.SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        Thread.Sleep(500);
                    }

                    if (checkBoxRepeatMusic.Checked == true)
                    {
                        bResult = oBlynclightController.SetMusicRepeat(nSelectedDeviceIndex);
                    }
                    else
                    {
                        bResult = oBlynclightController.ClearMusicRepeat(nSelectedDeviceIndex);
                    }

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        Thread.Sleep(500);
                    }

                    bResult = oBlynclightController.StartMusicPlay(nSelectedDeviceIndex);
                }
            }

            WriteToLog("comboBoxMusicList_SelectedIndexChanged Exit");
        }

        private void comboBoxFlashSpeedList_SelectedIndexChanged(object sender, EventArgs e)
        {
            WriteToLog("comboBoxFlashSpeedList_SelectedIndexChanged Entry");

            bySelectedFlashSpeed = (Byte)(comboBoxFlashSpeedList.SelectedIndex + 1);

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA || 
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE)
            {
                // Select light flash speed
                bool bResult = oBlynclightController.SelectLightFlashSpeed(nSelectedDeviceIndex, bySelectedFlashSpeed);
                if (bResult == false)
                {
                    MessageBox.Show("SelectLightFlashSpeed failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }

            WriteToLog("comboBoxFlashSpeedList_SelectedIndexChanged Exit");
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            WriteToLog("trackBar1_Scroll Entry");

            byVolumeLevel = (Byte)trackBar1.Value;
            bool bResult = false;

            bySelectedMusic = (Byte)(comboBoxMusicList.SelectedIndex + 1);

            if (checkBoxPlayMusic.Checked == true)
            {
                bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);

                bResult = oBlynclightController.SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);

                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                {
                    Thread.Sleep(250);
                }

                bResult = oBlynclightController.SetMusicVolume(nSelectedDeviceIndex, byVolumeLevel);

                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                {
                    Thread.Sleep(250);
                }

                if (checkBoxRepeatMusic.Checked == true)
                {
                    bResult = oBlynclightController.SetMusicRepeat(nSelectedDeviceIndex);
                }
                else
                {
                    bResult = oBlynclightController.ClearMusicRepeat(nSelectedDeviceIndex);
                }

                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                {
                    Thread.Sleep(500);
                }

                bResult = oBlynclightController.StartMusicPlay(nSelectedDeviceIndex);
            }

            WriteToLog("trackBar1_Scroll Exit");
        }

        private void vScrollBarRed_Scroll(object sender, ScrollEventArgs e)
        {
            WriteToLog("vScrollBarRed_Scroll Entry");
            textBoxRed.Text = vScrollBarRed.Value.ToString();
            WriteToLog("trackBar1_Scroll Exit");
        }

        private void vScrollBarGreen_Scroll(object sender, ScrollEventArgs e)
        {
            WriteToLog("vScrollBarGreen_Scroll Entry");
            textBoxGreen.Text = vScrollBarGreen.Value.ToString();
            WriteToLog("vScrollBarGreen_Scroll Exit");
        }

        private void vScrollBarBlue_Scroll(object sender, ScrollEventArgs e)
        {
            WriteToLog("vScrollBarBlue_Scroll Entry");
            textBoxBlue.Text = vScrollBarBlue.Value.ToString();
            WriteToLog("vScrollBarBlue_Scroll Exit");
        }

        private void CleanUp()
        {
            WriteToLog("CleanUp Entry");

            bQuitThread1 = true;

            StopPulsating = true;
            WaitForPulsatingInProgress();

            /*for (int i = 0; i < aoThreadProc.Length; i++)
            {
                aoThreadProc[i].Cleanup();
            }*/

            oBlynclightController.CloseDevices(nNumberOfBlyncDevices);

            WriteToLog("CleanUp Exit");
        }

        private void buttonClearLog_Click(object sender, EventArgs e)
        {
            textBoxLog.Text = "";
        }

        private void buttonGetUid_Click(object? sender, EventArgs? e)
        {
            ulong unUniqueId = 0x00;

            unUniqueId = oBlynclightController.GetDeviceUniqueId(nSelectedDeviceIndex);

            // Print the activity string
            this.textBoxLog.AppendText("Device Unique ID: " + unUniqueId);

            this.textBoxLog.AppendText("\r\n");
        }

        private void buttonDisplayTextPxL1_Click(object sender, EventArgs e)
        {
            String nameStringL1 = textBoxNameStringL1.Text;

            if (String.IsNullOrEmpty(nameStringL1) == true)
            {
                return;
            }

            String nameString = "Test String 1";

            nameString = nameString.Substring(0, 3);

            bool bResult = false;

            // bool bResult = oBlynclightController.ClearDisplayOnNameDisplayDevice(nSelectedDeviceIndex);

            nFontTypeL1 = comboBoxFontsL1.SelectedIndex + 1;

            bResult = oBlynclightController.DisplayTextOnNameDisplayUsingPixelControlNameAdjust(nSelectedDeviceIndex, nameStringL1, nFontTypeL1);
        }

        private void buttonClearText_Click(object sender, EventArgs e)
        {
            bool bResult = true;

            bResult = oBlynclightController.ClearTextOnNameDisplay(nSelectedDeviceIndex);
        }

        private void buttonResetNameDisplay_Click(object sender, EventArgs e)
        {
            bool bResult = true;

            bResult = oBlynclightController.ResetNameDisplay(nSelectedDeviceIndex);
        }

        private void buttonWriteNdUID_Click(object sender, EventArgs e)
        {
            bool bResult = true;

            string uidString = textBoxNdUid.Text;

            if (uidString.Length != 10)
            {
                MessageBox.Show("UID Digits count should be 10 digits", "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }

            try
            {
                ulong parsed = Convert.ToUInt64(uidString, 10);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.Message, "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            bResult = oBlynclightController.WriteUidToNameDisplay(nSelectedDeviceIndex, uidString);

            //Thread.Sleep(300);

            buttonGetNdUID_Click(null, null);
        }

        private void buttonTurnOnPixels_Click(object sender, EventArgs e)
        {
            oBlynclightController.TurnOnAllPixelsOnNameDisplay(nSelectedDeviceIndex);
        }

        int nFontTypeL1 = 1;
        int nFontTypeL2 = 1;
        private void comboBoxFonts_SelectedIndexChanged(object sender, EventArgs e)
        {
            nFontTypeL1 = comboBoxFontsL1.SelectedIndex + 1;
        }

        private void buttonDisplayTextDefault_Click(object sender, EventArgs e)
        {
            String nameString = textBoxNameStringL1.Text;

            if (String.IsNullOrEmpty(nameString) == true)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.DisplayTextOnNameDisplay(nSelectedDeviceIndex, nameString);
        }

        private void comboBoxFontsL2_SelectedIndexChanged(object sender, EventArgs e)
        {
            nFontTypeL2 = comboBoxFontsL2.SelectedIndex + 1;
        }

        private void buttonDisplayTextPxL1L2_Click(object sender, EventArgs e)
        {
            String nameStringL1 = textBoxNameStringL1.Text;

            if (String.IsNullOrEmpty(nameStringL1) == true)
            {
                return;
            }

            String nameStringL2 = textBoxNameStringL2.Text;

            if (String.IsNullOrEmpty(nameStringL2) == true)
            {
                return;
            }

            bool bResult = false;

            // bool bResult = oBlynclightController.ClearDisplayOnNameDisplayDevice(nSelectedDeviceIndex);

            nFontTypeL1 = comboBoxFontsL1.SelectedIndex + 1;
            nFontTypeL2 = comboBoxFontsL2.SelectedIndex + 1;

            /*String stringLine1 = "Waiting   Agents   Answered   Avg Call Time";
            String stringLine2 = "     7            2            24             00:09:59    ";

            int nFontTypeLine1 = 1;
            int nFontTypeLine2 = 1;
            */

            /*string stringLine1 = "Answered    Not Ready    Avg Talk    Svc Lvl";

            string st1 = "0";
            string st2 = "0";
            string st3 = "0";
            string st4 = "000";

            string string1 = "       " + st1 + "        ";

            if (st1.Length == 2)
            {
                string1 = "      " + st1 + "        ";
            }
            else if (st1.Length == 3)
            {
                string1 = "     " + st1 + "        ";
            }

            string string2 = "        " + st2 + "         ";
            if (st2.Length == 2)
            {
                string2 = "       " + st2 + "        ";
            }
            else if (st2.Length == 3)
            {
                string2 = "      " + st2 + "         ";
            }

            string string3 = "        " + st3 + "     ";
            if (st3.Length == 2)
            {
                string3 = "        " + st3 + "     ";
            }
            else if (st3.Length == 3)
            {
                string3 = "       " + st3 + "     ";
            }

            string string4 = "         " + st4 + "       ";
            if (st4.Length == 2)
            {
                string4 = "        " + st4 + "       ";
            }
            else if (st4.Length == 3)
            {
                string4 = "       " + st4 + "       ";
            }

            string stringLine2 = string1 + string2 + string3 + string4;*/

            bResult = oBlynclightController.DisplayTextOnNameDisplayUsingPixelControlEx(nSelectedDeviceIndex, nameStringL1, nFontTypeL1, nameStringL2, nFontTypeL2);
        }

        private void buttonWriteUid_Click(object sender, EventArgs e)
        {
            bool bResult = true;

            string uidString = textBoxUid.Text;

            if (uidString.Length != 10)
            {
                MessageBox.Show("UID Digits count should be 10 digits", "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }

            ulong ulUid = 0;

            try
            {
                ulUid = Convert.ToUInt64(uidString, 10);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.Message, "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            bResult = oBlynclightController.WriteUid(nSelectedDeviceIndex, ulUid);

            buttonGetUid_Click(null, null);
        }

        private void buttonGetNdUID_Click(object? sender, EventArgs? e)
        {
            ulong unUniqueId = 0x00;

            unUniqueId = oBlynclightController.GetDeviceUniqueId(nSelectedDeviceIndex);

            //Thread.Sleep(10);

            // Print the activity string
            this.textBoxLog.AppendText("Device Unique ID: " + unUniqueId);

            this.textBoxLog.AppendText("\n");

            this.textBoxLog.AppendText("\n");
        }

        private void buttonIncUID_Click(object sender, EventArgs e)
        {
            string uidString = textBoxUid.Text;

            if (uidString.Length != 10)
            {
                MessageBox.Show("UID Digits count should be 10 digits", "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }

            ulong ulUid = 0;

            try
            {
                ulUid = Convert.ToUInt64(uidString, 10);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.Message, "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            ulUid++;

            textBoxUid.Text = ulUid.ToString();
        }

        private void buttonDecUID_Click(object sender, EventArgs e)
        {
            string uidString = textBoxUid.Text;

            if (uidString.Length != 10)
            {
                MessageBox.Show("UID Digits count should be 10 digits", "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }

            ulong ulUid = 0;

            try
            {
                ulUid = Convert.ToUInt64(uidString, 10);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.Message, "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            ulUid--;

            textBoxUid.Text = ulUid.ToString();
        }

        private void buttonRed1_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnRedLight(nSelectedDeviceIndex);
            if (bResult == false)
            {
                MessageBox.Show("TurnOnRedLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }

            //pictureBoxColorDisplayed.BackColor = Color.FromArgb(255, 0, 0);
        }

        private void buttonGreen1_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnGreenLight(nSelectedDeviceIndex);
            if (bResult == false)
            {
                MessageBox.Show("TurnOnGreenLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }

            //pictureBoxColorDisplayed.BackColor = Color.FromArgb(0, 255, 0);
        }

        private void buttonBlue1_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnBlueLight(nSelectedDeviceIndex);
            if (bResult == false)
            {
                MessageBox.Show("TurnOnBlueLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }

            //pictureBoxColorDisplayed.BackColor = Color.FromArgb(0, 0, 255);
        }

        private void buttonWhite1_Click(object sender, EventArgs e)
        {
            bool bResult = false;

            bResult = oBlynclightController.TurnOnWhiteLight(nSelectedDeviceIndex);
            if (bResult == false)
            {
                MessageBox.Show("TurnOnWhiteLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }

            //pictureBoxColorDisplayed.BackColor = Color.FromArgb(255, 255, 255);
        }

        private void buttonDecUIDNp_Click(object sender, EventArgs e)
        {
            string uidString = textBoxNdUid.Text;

            if (uidString.Length != 10)
            {
                MessageBox.Show("UID Digits count should be 10 digits", "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }

            ulong ulUid = 0;

            try
            {
                ulUid = Convert.ToUInt64(uidString, 10);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.Message, "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            ulUid--;

            textBoxNdUid.Text = ulUid.ToString();
        }

        private void buttonIncUIDNp_Click(object sender, EventArgs e)
        {
            string uidString = textBoxNdUid.Text;

            if (uidString.Length != 10)
            {
                MessageBox.Show("UID Digits count should be 10 digits", "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }

            ulong ulUid = 0;

            try
            {
                ulUid = Convert.ToUInt64(uidString, 10);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.Message, "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            ulUid++;

            textBoxNdUid.Text = ulUid.ToString();
        }

        private void buttonOrange_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnOrangeLight(nSelectedDeviceIndex);

            if (bResult == false)
            {
                MessageBox.Show("TurnOnOrangeLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }

            //pictureBoxColorDisplayed.BackColor = Color.FromArgb(255, 100, 0);
        }

        private void buttonYellow1_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnYellowLight(nSelectedDeviceIndex);

            if (bResult == false)
            {
                MessageBox.Show("TurnOnYellowLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }

            //pictureBoxColorDisplayed.BackColor = Color.FromArgb(255, 200, 0);
        }

        private void buttonPurple_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnMagentaLight(nSelectedDeviceIndex);

            if (bResult == false)
            {
                MessageBox.Show("TurnOnMagentaLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }

            //pictureBoxColorDisplayed.BackColor = Color.FromArgb(255, 0, 255);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            if (nSelectedDeviceIndex < 0)
            {
                return;
            }

            if (bQuitThread1 == true)
            {
                bQuitThread1 = false;
            }
            else
            {
                bQuitThread1 = true;
            }

            if (bQuitThread1 == false)
            {
                Thread th1 = new Thread(OnStartStressTest);
                th1.Start();
            }            
        }

        bool bQuitThread1 = true;

        private void OnStartStressTest()
        {
            while (!bQuitThread1)
            {
                // LS: 850 ms
                // MS: 650 ms
                // HS: 325 ms
                oBlynclightController.TurnOnGreenLight(nSelectedDeviceIndex);
                Thread.Sleep(325);
                oBlynclightController.ResetLight(nSelectedDeviceIndex);
                Thread.Sleep(325);
            }

            /*
            oBlynclightController.ResetLight(nSelectedDeviceIndex);
            oBlynclightController.ClearMusicRepeat(nSelectedDeviceIndex);
            oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);
            oBlynclightController.ClearVolumeMute(nSelectedDeviceIndex);

            for (int i = 0; i < 10; i++)
            {
                oBlynclightController.TurnOnRedLight(nSelectedDeviceIndex);
                Thread.Sleep(300);
                oBlynclightController.TurnOnWhiteLight(nSelectedDeviceIndex);
                Thread.Sleep(300);
                oBlynclightController.SelectMusicToPlay(nSelectedDeviceIndex, 1);
                Thread.Sleep(300);
                oBlynclightController.StartMusicPlay(nSelectedDeviceIndex);
                Thread.Sleep(300);
                oBlynclightController.SetMusicVolume(nSelectedDeviceIndex, 2);
                Thread.Sleep(300);
                oBlynclightController.SetMusicRepeat(nSelectedDeviceIndex);
                Thread.Sleep(300);
                oBlynclightController.SetVolumeMute(nSelectedDeviceIndex);
                Thread.Sleep(300);
            }

            */

            oBlynclightController.ResetLight(nSelectedDeviceIndex);
            oBlynclightController.ResetLight(nSelectedDeviceIndex);
            oBlynclightController.ClearMusicRepeat(nSelectedDeviceIndex);
            oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);
            oBlynclightController.ClearVolumeMute(nSelectedDeviceIndex);
        }

        private void checkBoxMute_CheckedChanged(object sender, EventArgs e)
        {
            if (nSelectedDeviceIndex < 0)
            {
                return;
            }

            if (checkBoxMute.Checked)
            {
                oBlynclightController.SetVolumeMute(nSelectedDeviceIndex);
            }
            else
            {
                oBlynclightController.ClearVolumeMute(nSelectedDeviceIndex);
            }
        }

        private bool StopPulsating = true;

        private Thread? thPulsating = null;
        private bool PulsatingInProgress = false;
        byte byRedLevelForPulsating = 0;
        byte byGreenLevelForPulsating = 0;
        byte byBlueLevelForPulsating = 0;

        private void checkBoxPulsate_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxDisplayLight.Checked == false)
            {
                return;
            }

            if (checkBoxPulsate.Checked)
            {
                // Start pulsate function
                Byte byRedLevel = 255;
                Byte byGreenLevel = 255;
                Byte byBlueLevel = 255;

                try
                {
                    byRedLevel = Byte.Parse(textBoxRed.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message + "\nPlease check Red color value. It should be a value from 0 to 255.", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                    return;
                }

                try
                {
                    byGreenLevel = Byte.Parse(textBoxGreen.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message + "\nPlease check Green color value. It should be a value from 0 to 255.", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                    return;
                }

                try
                {
                    byBlueLevel = Byte.Parse(textBoxBlue.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message + "\nPlease check Blue color value. It should be a value from 0 to 255.", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                    return;
                }

                bool bResult = oBlynclightController.TurnOnRGBLights(nSelectedDeviceIndex, byRedLevel, byGreenLevel,
                    byBlueLevel);

                if (!bResult)
                {
                    MessageBox.Show("TurnOnRGBColors failed.", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }

                byRedLevelForPulsating = byRedLevel;
                byBlueLevelForPulsating = byBlueLevel;
                byGreenLevelForPulsating = byGreenLevel;

                StopPulsating = false;
                StartPulsatingThread();
            }
            else
            {
                // Stop pulsate if it was already pulsating
                StopPulsating = true;
                WaitForPulsatingInProgress();
            }
        }

        internal void StartPulsatingThread()
        {
            try
            {
                if (PulsatingInProgress == false)
                {
                    Thread.Sleep(100);
                    thPulsating = new Thread(new ThreadStart(StartPulsating));
                    thPulsating.Priority = ThreadPriority.Highest;
                    thPulsating.Start();
                }
            }
            catch
            {

            }
        }

        public void StartPulsating()
        {
            try
            {
                while (!StopPulsating)
                {
                    System.Windows.Forms.Application.DoEvents();
                    PulsatingInProgress = true;

                    Pulsate(byRedLevelForPulsating, byGreenLevelForPulsating, byBlueLevelForPulsating);
                }

                PulsatingInProgress = false;
                StopPulsating = true;
            }
            catch
            {
                PulsatingInProgress = false;
                StopPulsating = true;
            }
        }

        private void Pulsate(int r, int g, int b)
        {
            double i, o;

            byte redLevel = 0;
            byte greenLevel = 0;
            byte blueLevel = 0;

            for (i = 0; i < 6.283; i = i + (0.00628 * 7))
            {
                o = (Math.Sin(i) * 127.5 + 127.5) / 255;
                redLevel = (byte)(o * r);

                o = (Math.Sin(i) * 127.5 + 127.5) / 255;
                greenLevel = (byte)(o * g);

                o = (Math.Sin(i) * 127.5 + 127.5) / 255;
                blueLevel = (byte)(o * b);

                oBlynclightController.TurnOnRGBLights(nSelectedDeviceIndex, redLevel, greenLevel, blueLevel);

                Thread.Sleep(10);
            }
        }

        internal void WaitForPulsatingInProgress()
        {
            int i = 0;

            if (thPulsating != null)
            {
                while (thPulsating.IsAlive)
                {
                    Thread.Sleep(100);
                    i++;
                    if (i >= 50)
                    {
                        break;
                    }
                }

                PulsatingInProgress = false;
            }
        }
    }
}
