Embrava SDK for Linux:
------------------------------
The SDK contains test application that uses Embrava API.

Embrava API
-----------------
This API related files are put under /EmbravaApi folder.

Embrava API is written in pure C that uses signal11 hidapi and libusb1.0.

The Embrava API is supplied as a static library libembravaapi.a



Prerequisites for using Embrava API and test application:
---------------------------------------------------------------------

libusb1.0 development package
Install the libusb1.0 development package as per the flavour of the Linux

Udev rules:
Put the file embrava.rules supplied with this SDK at the following folder on the Linux machine.
etc/udev/rules.d/

Otherwise the Embrava USB devices can't be accessed on the Linux machine.

Reload and trigger udev rules as per the following command on the terminal with sudo
udevadm control --reload-rules 
udevadm trigger



Embrava Test Application
-------------------------------

Embrava Test Application - Makefile Cmdline application
-----------------------------------------------------------

This is a simple cmd line appplication that can be compiled using a simple makefile present in the 
folder EmbravaSdkForLinux/EmbravaTestApp_Make_Cmd

Here the make file is provided to compile the code. The make file adds library reference to the 
EmbravaApi static library libembravaapi.a and libusb1.0 library. Please refer the Makefile for further details.

To compile: Open the terminal and navigate to the project folder and enter make.
To clean: enter make clean on the terminal.

Compilation will result in the generation of the executable "EmbravaTestApp"

To run the application: enter ./EmbravaTestApp

This make file can be extended and can be used in your own application develpoment that integrates Embrava API.
---------------------------------------------------------------------------------------------------------------
