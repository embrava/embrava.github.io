# Define the registry path
$registryPath = "HKLM:\SOFTWARE\WOW6432Node\Embrava\EmbravaConnectInstallConfig"

# Check if the registry key exists
if (Test-Path -Path $registryPath) {
    try {
        # Remove the registry key and all its subkeys without confirmation
        Remove-Item -Path $registryPath -Force -Recurse -Confirm:$false
        Write-Host "Registry key and all subkeys removed: $registryPath"
    } catch {
        Write-Host "Error occurred: $_"
    }
} else {
    Write-Host "Registry key not found: $registryPath"
}
