Embrava SDK for Linux:
------------------------------
The SDK contains test application that uses Embrava API.

Embrava API
-----------------
This API related files are put under EmbravaSdkForLinux/EmbravaApi folder.

Embrava API is written in pure C that uses signal11 hidapi and libusb1.0.

The Embrava API is supplied as a static library libembravaapi.a



Prerequisites for using Embrava API and test application:
---------------------------------------------------------------------

libusb1.0 development package
Install the libusb1.0 development package as per the flavour of the Linux

Udev rules:
Put the file embrava.rules supplied with this SDK at the following folder on the Linux machine.
etc/udev/rules.d/

Otherwise the Embrava USB devices can't be accessed on the Linux machine.

Reload and trigger udev rules as per the following command on the terminal with sudo
udevadm control --reload-rules 
udevadm trigger



Embrava Test Application
-------------------------------

The Embrava Test Application is provided in two project formats.

1. Embrava Test Application - QT application
2. Embrava Test Application - Makefile Cmdline application


1. Embrava Test Application - QT application
-------------------------------------------------------

This Test Applicaiton is a QT project put under EmbravaSdkForLinux/EmbravaTestApp_Qt folder.
QT Gui Widget based application that calls functions exported by the Embrava API.

The Embrava API library has been added to the QT project. LibUsb v1.0 library has also been added to the project file.
See the file EmbravaTestApp.pro in the EmbravaSdkForLinux/EmbravaTestApp_Qt for library inclusion.

Compilation of the Embrava Test App - QT
----------------------------------------

Development Platform: Linux OS - CentOs 7 or Ubuntu 15 or above

QT 5.5.1 32 bit

Makefile for QT:

We don't supply the makefile for QT project. The file you may find in the build-release directory is generated 
by the QT creator during code building. This makefile can have hardcoded paths that QT puts during compilation.
QT uses absolute paths instead of the relative paths.

To compile the code, run the QT Creator, open the project EmbravaTestApp.pro file. Go to the project build settings found in this Test application project folder EmbravaSdkForLinux/EmbravaTestApp_Qt

Check Shadow build and enter the value "build-release" in the Build directory field as shown.

Now build the project in the QT creator as usually.



2. Embrava Test Application - Makefile Cmdline application
-----------------------------------------------------------

This is a simple cmd line appplication that can be compiled using a simple makefile present in the 
folder EmbravaSdkForLinux/EmbravaTestApp_Make_Cmd

Here the make file is provided to compile the code. The make file adds library reference to the 
EmbravaApi static library libembravaapi.a and libusb1.0 library. Please refer the Makefile for further details.

To compile: Open the terminal and navigate to the project folder and enter make.
To clean: enter make clean on the terminal.

Compilation will result in the generation of the executable "EmbravaTestApp"

To run the application: enter ./EmbravaTestApp

This make file can be extended and can be used in your own application develpoment that integrates Embrava API.
---------------------------------------------------------------------------------------------------------------
