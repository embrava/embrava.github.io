# Define the process name
$processName = "EmbravaConnect"

# Directly access the 'Program Files (x86)' environment variable
$programFilesX86Path = ${Env:ProgramFiles(x86)}

# Construct the path to the executable
$processPath = Join-Path -Path $programFilesX86Path -ChildPath "Embrava\Embrava Connect\EmbravaConnect.exe"

# Check if the executable exists at the specified location
if (Test-Path -Path $processPath) {
    Write-Host "Found $processName executable at $processPath."

    # Check if the process is running
    $process = Get-Process $processName -ErrorAction SilentlyContinue

    # If the process is not found, start it
    if (-not $process) {
        Write-Host "$processName is not running. Attempting to start..."
        Start-Process -FilePath $processPath -ErrorAction Stop
        Write-Host "$processName started successfully."
    } else {
        Write-Host "$processName is already running."
    }
} else {
    Write-Host "The $processName executable does not exist at $processPath"
}
