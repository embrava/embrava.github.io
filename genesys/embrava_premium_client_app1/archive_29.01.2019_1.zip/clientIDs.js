export default {
    'mypurecloud.com': 'bab69ff9-7e90-4765-9237-daeb4956134c',
    'mypurecloud.ie': '77b877d9-31cc-45b3-aec0-4cbf9a10f201',
    'mypurecloud.com.au': 'adddd327-0027-4714-b807-d61d8cad7a1b'
}