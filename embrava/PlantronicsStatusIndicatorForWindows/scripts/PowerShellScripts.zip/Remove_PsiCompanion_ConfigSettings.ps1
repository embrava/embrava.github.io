Stop-Process -name PlantronicsStatusIndicator -Force
$users = Get-ChildItem C:\Users
foreach ($user in $users) {
    $folder = "$($user.fullname)\AppData\Local\Plantronics_Inc"
    If (Test-Path $folder) {
        Get-ChildItem $folder | Remove-Item -Recurse -Force -ErrorAction silentlycontinue 
    } 
}