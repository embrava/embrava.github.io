﻿// ************************************************************************
//
//	    Project : .Net Dll for Blync USB HID Device Access
//	   FileName : NativeMethods.cs
//	     Author : Senthil, for Ensyst Pty Ltd
//     Co-Author(s) : 
//	    Created : 11 February, 2014
//
// ************************************************************************
//
// Module Description
//
// Class that imports low level Windows APIs related to Device SetupAPI,
// USB HID API and File IO API
//
// ************************************************************************
//
// History
//
// Date			    Version		Author		Changes
//
// 11 February, 2014	1.00		Senthil		Initial version
//
// ************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace BlyncLightTest
{
    // This class contains Imported unmanaged function calls for 
    // accessing low level windows APIs

    #region NativeMethods

    internal class NativeMethods
    {
        [DllImport("kernel32.dll")]
        internal static extern IntPtr CreateEvent(IntPtr lpEventAttributes, bool bManualReset, bool bInitialState, string lpName);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool ReadFile(IntPtr hFile, [Out] byte[] lpBuffer, uint nNumberOfBytesToRead, ref uint lpNumberOfBytesRead, IntPtr lpOverlapped);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern uint GetLastError();

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern UInt32 WaitForSingleObject(IntPtr hHandle, UInt32 dwMilliseconds);

        [DllImport("kernel32.dll")]
        internal static extern bool ResetEvent(IntPtr hEvent);

        [DllImport("kernel32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool CancelIo(IntPtr hFile);

        [DllImport("kernel32.dll")]
        internal static extern bool SetEvent(IntPtr hEvent);
    }

    #endregion
}
