Stop-Process -name PlantronicsStatusIndicator -Force
msiexec /x "{58352D23-EA25-4203-95A1-8BD51CE311FD}" /quiet
Remove-Item 'C:\Program Files (x86)\Plantronics\PlantronicsStatusIndicator' -Recurse -Force -ErrorAction silentlycontinue 

