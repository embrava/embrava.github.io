#include <QMessageBox>
#include <QThread>

#include "../EmbravaApi/hidapi.h"
#include "../EmbravaApi/embravaapi.h"

#include "mainwindow.h"
#include "ui_mainwindow.h"

extern SDeviceInfo aosDeviceInfo[MAX_DEVICES_SUPPORTED];

int nNumberOfBlyncDevices = 0;
int nSelectedDeviceIndex = 0;

char *arrMusicListForBlyncUSB30S[10] = {"Music 1", "Music 2", "Music 3", "Music 4", "Music 5",
                                        "Music 6", "Music 7", "Music 8", "Music 9", "Music 10"
                                       };

char *arrMusicListForBlyncMiniWireless[14] = {"Music 1", "Music 2", "Music 3", "Music 4", "Music 5",
                                              "Music 6", "Music 7", "Music 8", "Music 9", "Music 10",
                                              "Music 11", "Music 12", "Music 13", "Music 14"
                                             };

byte bySelectedMusic = 1;
byte bySelectedFlashSpeed = 1;
byte byVolumeLevel = 5;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setFixedSize(width(), height());

    SearchAndListBlyncDevices();

    ui->groupBoxBl1020->setStyleSheet("QGroupBox {  border: 1px solid gray;}");
    ui->groupBoxBl3040->setStyleSheet("QGroupBox {  border: 1px solid gray;}");
    ui->groupBoxDl->setStyleSheet("QGroupBox {  border: 1px solid gray;}");
    ui->groupBoxBl3040_Light->setStyleSheet("QGroupBox {  border: 1px solid gray;}");
    ui->groupBoxBl3040_Music->setStyleSheet("QGroupBox {  border: 1px solid gray;}");
}

MainWindow::~MainWindow()
{
    if (nNumberOfBlyncDevices > 0)
    {
        for (int i = 0; i < nNumberOfBlyncDevices; i++)
        {
            ResetLight(i);

            byte byDetectedDeviceType = aosDeviceInfo[i].byDeviceType;

            // Clear Music
            if (byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    byDetectedDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
            {
                StopMusicPlay(i);
                ClearMusicRepeat(i);
                SetVolumeMute(i);
            }

            // Clear light
            if (byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220 ||
                    byDetectedDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20)
            {
                StopLightFlash(i);
                ClearLightDim(i);
                ResetLight(i);
            }
        }

        CleanUp();
    }

    delete ui;
}



void MainWindow::on_cbDeviceList_activated(int index)
{
    nSelectedDeviceIndex = index;
}

void MainWindow::SearchAndListBlyncDevices()
{
    int i = 0;


    // If there is already a list of devices, free the list of device and resources allocated
    ui->cbDeviceList->clear();

    // Look for the Blync devices connected to the System
    // the nNumberOfBlyncDevices will be equal to the number
    // of Blync devices connected to the System USB Ports

    //CleanUp();

    InitBlyncDevices(&nNumberOfBlyncDevices, aosDeviceInfo);

    if (nNumberOfBlyncDevices > 0)
    {
        // Add the Blync devices detected to the combobox
        for (i = 0; i < nNumberOfBlyncDevices; i++)
        {
            ui->cbDeviceList->insertItem(i, aosDeviceInfo[i].pchDeviceName);
        }

        ui->cbDeviceList->setCurrentIndex(0);
        nSelectedDeviceIndex = 0;
    }
    else
    {
        QMessageBox::information(this,"Embrava Test App", "No Embrava Devices connected");

        // If device is not present disable all UI components
        DisableUIComponentsForBlyncUsb1020Devices();
        DisableUIComponentsForBlyncUsbDevices();
    }
}

void MainWindow::EnableUIComponentsForBlyncUsb1020Devices()
{
    ui->groupBoxBl1020->setEnabled(true);
}

void MainWindow::DisableUIComponentsForBlyncUsb1020Devices()
{
    ui->groupBoxBl1020->setEnabled(false);
}

void MainWindow::EnableUIComponentsForBlyncUsbDevices()
{
    if (aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
    {
        ui->groupBoxBl3040_Light->setEnabled(true);
        ui->groupBoxBl3040_Music->setEnabled(true);
    }
    else if (aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
             aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
             aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
    {
        ui->groupBoxBl3040_Light->setEnabled(true);
        ui->groupBoxBl3040_Music->setEnabled(false);
    }

    if (aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S
            )
    {
        ui->pbGetUid->setEnabled(true);
    }
    else
    {
        ui->pbGetUid->setEnabled(false);
    }
}

void MainWindow::DisableUIComponentsForBlyncUsbDevices()
{
    ui->groupBoxBl3040_Light->setEnabled(false);
    ui->groupBoxBl3040_Music->setEnabled(false);
    ui->pbGetUid->setEnabled(false);
}

void MainWindow::CleanUp()
{
    if (nNumberOfBlyncDevices > 0)
    {
        CloseDevices(nNumberOfBlyncDevices);
    }
}

void MainWindow::on_pbUpdateDeviceList_clicked()
{
    SearchAndListBlyncDevices();
}

void MainWindow::on_pbRed_clicked()
{
    TurnOnRedLight(nSelectedDeviceIndex);
}

void MainWindow::on_pbGreen_clicked()
{
    TurnOnGreenLight(nSelectedDeviceIndex);
}

void MainWindow::on_pbBlue_clicked()
{
    TurnOnBlueLight(nSelectedDeviceIndex);
}

void MainWindow::on_pbMagenta_clicked()
{
    TurnOnMagentaLight(nSelectedDeviceIndex);
}

void MainWindow::on_pbCyan_clicked()
{
    TurnOnCyanLight(nSelectedDeviceIndex);
}

void MainWindow::on_pbYellow_clicked()
{
    TurnOnYellowLight(nSelectedDeviceIndex);
}

void MainWindow::on_pbWhite_clicked()
{
    TurnOnWhiteLight(nSelectedDeviceIndex);
}

void MainWindow::on_pbReset_clicked()
{
    ResetLight(nSelectedDeviceIndex);
}

void MainWindow::on_cbDeviceList_currentIndexChanged(int index)
{
    int j = 0;
    nSelectedDeviceIndex = index;

    if (nSelectedDeviceIndex >= 0)
    {
        if (aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_TENX_10 ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_TENX_20)
        {
            EnableUIComponentsForBlyncUsb1020Devices();
            DisableUIComponentsForBlyncUsbDevices();
        }
        else if (aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
            aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220 ||
             aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                 aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                 aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
             aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
             aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
             aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
             aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
             aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
        {
            EnableUIComponentsForBlyncUsbDevices();
            DisableUIComponentsForBlyncUsb1020Devices();

            if (aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                    aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                    aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                    aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20)
            {
                if (ui->cbMusicList->count() > 0)
                {
                    ui->cbMusicList->clear();
                }

                for (j = 0; j < 10; j++)
                {
                    ui->cbMusicList->insertItem(j, arrMusicListForBlyncUSB30S[j]);
                }

                ui->cbMusicList->setCurrentIndex(0);
            }
            else if (aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                     aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                     aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                     aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                     aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
            {
                if (ui->cbMusicList->count() > 0)
                {
                    ui->cbMusicList->clear();
                }

                for (int j = 0; j < 14; j++)
                {
                    ui->cbMusicList->insertItem(j, arrMusicListForBlyncMiniWireless[j]);
                }

                ui->cbMusicList->setCurrentIndex(0);
            }
        }
    }
}

void MainWindow::on_checkBoxDisplayLight_stateChanged(int arg1)
{
    bool bDisplayLight = false;
    bool bResult = false;

    bDisplayLight = ui->checkBoxDisplayLight->isChecked();

    // Select turn on or off light based on check box value
    if (bDisplayLight == true)
    {
        // Send the RGB color values
        SetRgbValues();
    }
    else
    {
        bResult = ResetLight(nSelectedDeviceIndex);
        if (bResult == false)
        {
            QMessageBox::warning(this, "Embrava Test App", "TurnOffLight failed");
        }
    }
}

void MainWindow::on_pbSetColors_clicked()
{
    if (ui->checkBoxDisplayLight->isChecked() == true)
    {
        SetRgbValues();
    }
}

void MainWindow::on_checkBoxDimLight_stateChanged(int arg1)
{
    bool bDimLight = ui->checkBoxDimLight->isChecked();
    bool bResult = false;

    if (bDimLight == true)
    {
        bResult = SetLightDim(nSelectedDeviceIndex);

        if (bResult == false)
        {
            QMessageBox::warning(this, "Embrava Test App", "SetLightDim failed");
        }
    }
    else
    {
        bResult = ClearLightDim(nSelectedDeviceIndex);
        if (bResult == false)
        {
            QMessageBox::warning(this, "Embrava Test App", "ClearLightDim failed");
        }
    }
}

void MainWindow::on_checkBoxFlashLight_stateChanged(int arg1)
{
    bool bFlashLight = ui->checkBoxFlashLight->isChecked();
    bool bResult = false;

    if (bFlashLight == true)
    {
        bResult = StartLightFlash(nSelectedDeviceIndex);

        if (bResult == false)
        {
            QMessageBox::warning(this, "Embrava Test App", "StartLightFlash failed");
        }

        bResult = SelectLightFlashSpeed(nSelectedDeviceIndex, bySelectedFlashSpeed);

        if (bResult == false)
        {
            QMessageBox::warning(this, "Embrava Test App", "SelectLightFlashSpeed failed");
        }
    }
    else
    {
        bResult = StopLightFlash(nSelectedDeviceIndex);
        if (bResult == false)
        {
            QMessageBox::warning(this, "Embrava Test App", "StartLightFlash failed");
        }
    }
}


void MainWindow::on_checkBoxPlayMusic_stateChanged(int arg1)
{
    bool bPlayMusic = ui->checkBoxPlayMusic->isChecked();
    bool bResult = false;
    byVolumeLevel = (Byte)ui->hsVolume->value();

    bResult = StopMusicPlay(nSelectedDeviceIndex);

    bResult = SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);

    bResult = SetMusicVolume(nSelectedDeviceIndex, byVolumeLevel);

    if (bPlayMusic == true)
    {
        if (ui->checkBoxRptMusic->isChecked() == true)
        {
            bResult = SetMusicRepeat(nSelectedDeviceIndex);
        }
        else
        {
            bResult = ClearMusicRepeat(nSelectedDeviceIndex);
        }

        QThread::msleep(300);

        bResult = StartMusicPlay(nSelectedDeviceIndex);
        if (bResult == false)
        {
            QMessageBox::warning(this, "Embrava Test App", "StartMusicPlay failed");
        }
    }
    else
    {
        bResult = StopMusicPlay(nSelectedDeviceIndex);
        if (bResult == false)
        {
            QMessageBox::warning(this, "Embrava Test App", "StopMusicPlay failed");
        }
    }
}

void MainWindow::on_cbMusicList_currentIndexChanged(int index)
{
    bySelectedMusic = (Byte)index + 1;

    if (aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
           aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
        aosDeviceInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20)
    {
        if (ui->checkBoxPlayMusic->isChecked() == true)
        {
            bool bResult = StopMusicPlay(nSelectedDeviceIndex);
            bResult = SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);

            if (ui->checkBoxRptMusic->isChecked() == true)
            {
                bResult = SetMusicRepeat(nSelectedDeviceIndex);
            }
            else
            {
                bResult = ClearMusicRepeat(nSelectedDeviceIndex);
            }

            QThread::msleep(500);

            bResult = StartMusicPlay(nSelectedDeviceIndex);
        }
    }


}

void MainWindow::on_cbFlashSpeed_currentIndexChanged(int index)
{
    bySelectedFlashSpeed = index + 1;

    bool bResult = SelectLightFlashSpeed(nSelectedDeviceIndex, bySelectedFlashSpeed);

    if (bResult == false)
    {
        QMessageBox::warning(this, "Embrava Test App", "SelectLightFlashSpeed failed");
    }
}

void MainWindow::on_hsVolume_sliderMoved(int position)
{

}

void MainWindow::on_checkBoxRptMusic_stateChanged(int arg1)
{
    bool bRepeatMusic = ui->checkBoxRptMusic->isChecked();
    bool bResult = false;

    if (bRepeatMusic == true)
    {
        if (ui->checkBoxPlayMusic->isChecked() == true)
        {
            bResult = StopMusicPlay(nSelectedDeviceIndex);
            bResult = SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);
            bResult = SetMusicVolume(nSelectedDeviceIndex, byVolumeLevel);
            bResult = SetMusicRepeat(nSelectedDeviceIndex);
            QThread::msleep(300);
            bResult = StartMusicPlay(nSelectedDeviceIndex);
        }
    }
    else
    {
        bResult = StopMusicPlay(nSelectedDeviceIndex);
        bResult = ClearMusicRepeat(nSelectedDeviceIndex);
        QThread::msleep(300);
        bResult = StartMusicPlay(nSelectedDeviceIndex);
        bResult = StopMusicPlay(nSelectedDeviceIndex);
    }
}

void MainWindow::on_pbGetUid_clicked()
{
    int nUid = GetDeviceUniqueId(nSelectedDeviceIndex);

    QString uidMessage = QStringLiteral("Device Unique ID: %1").arg(nUid);


    QMessageBox::information(this, "Embrava Test App", uidMessage);
}

void MainWindow::SetRgbValues()
{
    bool bResult = false;

    Byte byRedLevel = 255;
    Byte byGreenLevel = 255;
    Byte byBlueLevel = 255;

    byRedLevel = ui->redValue->text().toInt();
    byGreenLevel = ui->greenValue->text().toInt();
    byBlueLevel = ui->blueValue->text().toInt();

    bResult = TurnOnRGBLights(nSelectedDeviceIndex, byRedLevel, byGreenLevel, byBlueLevel);

    if (bResult == false)
    {
        QMessageBox::warning(this, "Embrava Test App", "TurnOnRGBLights failed");

    }
}

void MainWindow::on_hsVolume_valueChanged(int value)
{
    byVolumeLevel = (Byte)ui->hsVolume->value();
    bool bResult = false;

    bySelectedMusic = (Byte)(ui->cbMusicList->currentIndex() + 1);

    if (ui->checkBoxPlayMusic->isChecked() == true)
    {
        bResult = StopMusicPlay(nSelectedDeviceIndex);
        bResult = SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);
        bResult = SetMusicVolume(nSelectedDeviceIndex, byVolumeLevel);

        if (ui->checkBoxRptMusic->isChecked() == true)
        {
            bResult = SetMusicRepeat(nSelectedDeviceIndex);
        }
        else
        {
            bResult = ClearMusicRepeat(nSelectedDeviceIndex);
        }

        QThread::msleep(500);

        bResult = StartMusicPlay(nSelectedDeviceIndex);
    }
}
