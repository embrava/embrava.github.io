Installation of Embrava Connect Software:
------------------------------------------

EmbravaConnect_Setup.exe:
-------------------------

Use this exe file if you want to display the installer's user interface in your PC's user interface language. Right now this support has been added for French language. EmbravaConnect_Setup.exe doesn't support msiexec flags.

EmbravaConnect.msi:
--------------------
EmbravaConnect.msi displays the installer's user interface in English only.
If you are using EmbravaConnect.msi to install Embrava Connect software, you have optional command line parameters and msiexec flags for certain customizations during installation.

Default installation:
----------------------

Install the software by running the MSI installer EmbravaConnect.msi, it will install the Embrava Connect with default settings. After installation of the software, 
the user will be prompted for selecting the necessary Connections such as Skype for Business, Microsoft Teams, Microsoft Teams (client-side), Cisco WebEx Teams, Slack, Zoom, CX Cloud, Cisco Jabber, RingCentral, Skype for Business (Server Side), 
CounterPath Bria, BroadView OfficeSuite Softphone, Broadsoft, Genesys Premium, Genesys PureConnect, Plantronics Hub, Intel Unite, Desk Sign and Manual mode. The user can select the connections they require and apply the settings accordingly.

Command line usage and parameters:
----------------------------------

Example:

msiexec /i EmbravaConnect.msi /qn Connections=SFB ConnectionsSelected=SFB SilentConnectionSettings=Yes StartApp=Yes

1. All the msiexec specific flags or parameters are applicable.

2. User specific parameters:

1. Connections
---------------

Use this parameter to add only user specific Connections to the Embrava Conenct Connections list, so that the unwanted connections will not be listed on the Available Connections list
in the Manage Connections dialog of the Embrava Connect software. By default, i.e. without using this parameter, after installation and running the Embrava Connect application, 
all the connections will be added to the Embrava Connect application.

usage:
Connections=SFB,TEAMS,SLACK,ZOOM,CXCLOUD,CJAB,WEBEXTEAMS,RNG,SFBSERVER,BRIA,BROADVIEW,MANUAL,BROADSOFT,GENPREMIUM,PURECONNECT,PHUB,UNITE,DESKSIGN,TEAMSSERVER,IVES

The above will add Skype for Business, Microsoft Teams, Slack, Zoom, CX Cloud, Cisco Jabber, Cisco WebEx Teams, RingCentral, Skype for Business Server Side, CounterPath Bria, BroadView OfficeSuite Softphone,  
Broadsoft, Genesys Premium, Genesys PureConnect, Plantronics Hub, Intel Unite, Desk Sign, Microsoft Teams (server-side) and Manual connections to the Embrava Connect Application's connection list.  
In multiple connection environment, the connections priority will be based on the order in which the connections are entered in the "Connections" parameter. 

For example in the above, the higher priority connection will be Skype for Business, then Microsoft Teams, then Slack and so on.

Adding only one connection:

Connections=SFB

The above will add only Skype for Business to the Embrava Connect Application's connection list.

Parameter details:

SFB - Skype for Business
TEAMS - Microsoft Teams (client-side)
TEAMSSERVER - Microsoft Teams
SLACK - Slack
ZOOM -  Zoom
CXCLOUD - CX Cloud
CJAB - Cisco Jabber
WEBEXTEAMS - Cisco WebEx Teams
RNG - RingCentral
SFBSERVER - Skype for Business Server Side
BRIA - CounterPath Bria
BROADVIEW - BroadView OfficeSuite Softphone
MANUAL - Manual
BROADSOFT - Broadsoft UC Communicator
GENPREMIUM - Genesys Premium 
PURECONNECT - Genesys PureConnect
PHUB - Plantronics Hub
UNITE - Intel Unite
DESKSIGN - Desk Sign
IVES  - SRV Canada VRS

2. ConnectionsSelected
-----------------------

It is used to select the connections in the connections list. So the user is not required to check in the connections list in the Manage connections dialog of Embrava Connect
application.

usage:
ConnectionsSelected=SFB

For example, if Connections=SFB and ConnectionsSelected=SFB, then on the Manage Connections dialog of the Embrava Connect application, the user will see the Skype for Business 
connection selected by default.

This parameter "ConnectionsSelected" will be applicable only when the parameter "Connections" is entered in the command line.

3. SilentConnectionSettings
----------------------------

This parameter is used to avoid user intervention in selecting the connections in the Manage Connections dialog. 

usage:

SilentConnectionSettings=Yes

For example if Connections=SFB and ConnectionsSelected=SFB and SilentConnectionSettings=Yes - as entered on the command line during installation, then once the Embrava Connect 
application is executed after installation the user is not required to make any configuration changes and the device will begin syncing with Skype for Business immediately.

This parameter "SilentConnectionSettings" will be applicable only when the parameters "Connections" and "ConnectionsSelected" is entered in the command line.

4. StartApp
------------

This parameter is used to automatically start the Embrava Connect application once the installation finishes through commandline.

usage:

StartApp=Yes

If its not intended to automatically start the application please don't add this parameter in the commandline.

5. AutoUpdateDisabled
----------------------

This parameter is used to disable the Automatic update feature of the Embrava Connect. 

usage:

AutoUpdateDisabled=Yes

If you don't want to disable the Automatic update feature, don't add this parameter in the commandline.

6. ManualUpdateDisabled
-------------------------

This parameter is used to disable the Manual update feature of the Embrava Connect. 

usage:

ManualUpdateDisabled=Yes

If you don't want to disable the manual update feature, don't add this parameter in the commandline.

7. PreserveSettings
--------------------

This parameter is used to preserve the current configuration settings or not, when msiexec is executed in silent mode during installation or uninstallation. In Gui mode this parameter is ignored.

usage:

PreserveSettings=No

By default the settings won't be removed. If you want to remove the settings use this parameter, PreserveSettings=No

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

SCCM Deployment of Embrava Connect Software - starting installation with EmbravaConnect.msi:

You can use EmbravaConnect.msi file for sccm deployment.

Command line usage:

Installation of Embrava Connect software using the msiexec deployment command
--------------------------------------------------------------------------------

msiexec /i EmbravaConnect.msi /qn

You can deploy the software through msi deployment and the user specific parameters are applicable in the command line.

If you are updating the software from the older version to the new version through msi command line deployment, with any of these custom switches say - Connections or ConnectionsSelected or SilentConnectionSettings or AutoUpdateDisabled or ManualUpdateDisabled and with no change in the custom switches or their values, then you can use the previous deployment command as is.

For example, if you have already deployed Embrava Connect v5.2.65 with the following deployment command,

msiexec /i EmbravaConnect.msi /qn Connections=WEBEXTEAMS,TEAMS ConnectionsSelected=WEBEXTEAMS,TEAMS SilentConnectionSettings=Yes StartApp=Yes AutoUpdateDisabled=Yes ManualUpdateDisabled=Yes

Now if you are going to deploy the Embrava Connect v5.2.69 with no change in the switches or their values then just use the previous deployment command as it is, i.e just like the command mentioned above.

In case you are updating the software from the older version to the new version through msi command line deployment, with any of the custom switches say - Connections or ConnectionsSelected or SilentConnectionSettings or AutoUpdateDisabled or ManualUpdateDisabled, if you change the value of any of these switches or if you remove or add a custom switch from the previous deployment command, then you should add this PreserveSettings=No switch along with other switches to clear out the current configuration settings. 

For example, if you have already deployed Embrava Connect v5.2.65 with the following deployment command,

msiexec /i EmbravaConnect.msi /qn Connections=WEBEXTEAMS,TEAMS ConnectionsSelected=WEBEXTEAMS,TEAMS SilentConnectionSettings=Yes StartApp=Yes AutoUpdateDisabled=Yes ManualUpdateDisabled=Yes

Now you are going to deploy the Embrava Connect v5.2.69, but you want to add Zoom connection to the connections list, you should add the switch PreserveSettings=No to the deployment command and it should be like the following,:

msiexec /i EmbravaConnect.msi /qn Connections=WEBEXTEAMS,TEAMS,ZOOM ConnectionsSelected=WEBEXTEAMS,TEAMS,ZOOM SilentConnectionSettings=Yes StartApp=Yes AutoUpdateDisabled=Yes ManualUpdateDisabled=Yes PreserveSettings=No

Once you do exectue this command, then the changes would be refelected in the Embrava Connect application as you expect, if you don't provide the PreserveSettings=No in the deployment command, then the connections list what you expect won't reflect 
in the Embrava Connect application.


Uninstallation of Embrava Connect software using the msiexec deployment command
--------------------------------------------------------------------------------

If you want to uninstall the Embrava Connect software use the following deployment command

To uninstall Embrava Connect v5.2.55
msiexec /x "{55FCECAC-DF90-4109-A253-3249C2CB30FE}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.61
msiexec /x "{91FCECAC-7291-5271-B753-1599671B3999}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.65
msiexec /x "{AEE70D9D-3B1F-4BC6-9C45-281305B623BA}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.69
msiexec /x "{B8A6034A-8563-44B3-9259-9073C234A369}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.70
msiexec /x "{ADD31837-D6C6-4500-8353-4EF0767E9F2A}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.74
msiexec /x "{1F54FCCF-DE3C-400D-90F1-745C4D3C8699}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.91
msiexec /x "{6B971E57-99E3-49DE-BFF1-D334AF9FC1DE}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.92
msiexec /x "{9486E798-B858-46F9-8ED5-5A24CCC8B43D}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.93
msiexec /x "{B4AB27CC-F6B1-49CC-B0C9-541178373D2B}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.94
msiexec /x "{3EF78DDF-30AB-4901-8515-970CFFE48C8F}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.95
msiexec /x "{31AC5A3F-CA81-451E-937B-694DFA1ECE36}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.96
msiexec /x "{678EC9F0-D163-425F-813F-07930477B61D}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.97
msiexec /x "{C4FE00D8-4201-43E7-87C5-704D4C5C0D3E}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.98
msiexec /x "{D6FE01D8-5302-46E7-97D1-215D9C5C1E4F}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.2.99
msiexec /x "{5B25A47F-B938-4A0B-8D56-CDC2B1650253}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.3.0
msiexec /x "{23E1CD2A-624D-45E2-BB7F-9D7A4359D46D}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.3.2 (beta)
msiexec /x "{A408AB0C-CD16-4031-BBE1-6EE0ED87006A}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.3.3 (beta)
msiexec /x "{3A50B615-3F7E-4989-A92A-3A802A6823C9}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.3.4 (beta)
msiexec /x "{C4A8DB42-1BE7-4ABB-B02E-084F7AE4C3C4}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.3.5 (beta)
msiexec /x "{59FD89C6-9D75-40B0-8D4B-AAF525D8F0D1}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.3.6 (beta)
msiexec /x "{BCB587F0-B9E2-42C0-BF68-7E73CF50512E}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.3.7 (beta)
msiexec /x "{3E32C573-FE73-459E-B19D-15E12D9C272A}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.3.8 (beta)
msiexec /x "{581E3DE9-D095-4E15-A0DA-D0C2595B5C83}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.3.9 (beta)
msiexec /x "{1663053E-500E-4199-B159-38B3D7EF927C}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.4.0 (beta)
msiexec /x "{179856B3-F0C7-4BC4-A042-AF372FBD5E8D}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.4.1 (beta)
msiexec /x "{EFA4253E-9BB6-48E4-A0F8-865834E7C59F}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.4.2 (beta)
msiexec /x "{DA02694C-E065-43D6-8C8D-404288C4CFE3}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.4.3
msiexec /x "{E74A34B4-8755-403D-8243-4C7C5150E7EF}" /qn PreserveSettings=No

To uninstall Embrava Connect v5.4.4
msiexec /x "{6FC03C98-BC06-449E-9C43-307464064707}" /qn PreserveSettings=No

This uninstallation command would be helpful, in case if you want to install the latest version of Embrava Connect fresh with custom switches. i.e. First uninstall the version using this deployment command, that is already installed , 
after this you may use the installation deployment command with custom switches that you need.