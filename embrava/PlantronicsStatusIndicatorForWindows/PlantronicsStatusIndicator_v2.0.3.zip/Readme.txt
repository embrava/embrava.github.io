Installation of Plantronics Status Indicator Software:
-------------------------------------------------------

PlantronicsStatusIndicator_Setup.exe:
--------------------------------------

Use this exe file if you want to display the installer's user interface in your PC's user interface language. Right now this support has been added for French language. PlantronicsStatusIndicator_Setup.exe doesn't support msiexec flags.

PlantronicsStatusIndicator.msi:
--------------------------------
PlantronicsStatusIndicator.msi displays the installer's user interface in English only.
If you are using PlantronicsStatusIndicator.msi to install Plantronics Status Indicator software, you have optional command line parameters and msiexec flags for certain customizations during installation.

Default installation:
----------------------

Install the software by running the MSI installer PlantronicsStatusIndicator.msi, it will install the Plantronics Status Indicator with default settings. After installation of the software, 
the user will be prompted for selecting the necessary Connections such as Skype for Business, Microsoft Teams, Microsoft Teams (client-side), Cisco WebEx, Slack, Zoom, CX Cloud, Cisco Jabber, RingCentral, Skype for Business (Server Side), 
CounterPath Bria, BroadView OfficeSuite Softphone, Broadsoft, Genesys PureConnect, Plantronics Hub, Intel Unite, IVES SRV Canada VRS App and Manual mode. The user can select the connections they require and apply the settings accordingly.

Command line usage and parameters:
----------------------------------

Example:

msiexec /i PlantronicsStatusIndicator.msi /qn Connections=SFB ConnectionsSelected=SFB SilentConnectionSettings=Yes StartApp=Yes

1. All the msiexec specific flags or parameters are applicable.

2. User specific parameters:

1. Connections
---------------

Use this parameter to add only user specific Connections to the Plantronics Status Indicator Connections list, so that the unwanted connections will not be listed on the Available Connections list
in the Manage Connections dialog of the Plantronics Status Indicator software. By default, i.e. without using this parameter, after installation and running the Plantronics Status Indicator application, 
all the connections will be added to the Plantronics Status Indicator application.

usage:
Connections=SFB,TEAMS,SLACK,ZOOM,CXCLOUD,CJAB,WEBEXTEAMS,RNG,SFBSERVER,BRIA,BROADVIEW,MANUAL,BROADSOFT,PURECONNECT,PHUB,UNITE,TEAMSSERVER,IVES

The above will add Skype for Business, Microsoft Teams (Client-Side), Slack, Zoom, CX Cloud, Cisco Jabber, Cisco WebEx Teams, RingCentral, Skype for Business Server Side, CounterPath Bria, BroadView OfficeSuite Softphone,  
Broadsoft, Genesys PureConnect, Plantronics Hub, Intel Unite, Microsoft Teams (server-side) and Manual connections to the Plantronics Status Indicator Companion Application's connections list.  
In multiple connection environment, the connections priority will be based on the order in which the connections are entered in the "Connections" parameter. 

For example in the above, the higher priority connection will be Skype for Business, and the remaining are low priority connections.

Adding only one connection:

Connections=SFB

The above will add only Skype for Business to the Plantronics Status Indicator Companion Application's connection list.

Parameter details:

SFB - Skype for Business
TEAMS - Microsoft Teams (client-side)
TEAMSSERVER - Microsoft Teams
SLACK - Slack
ZOOM -  Zoom
CXCLOUD - CX Cloud
CJAB - Cisco Jabber
WEBEXTEAMS - Cisco WebEx Teams
RNG - RingCentral
SFBSERVER - Skype for Business Server Side
BRIA - CounterPath Bria
BROADVIEW - BroadView OfficeSuite Softphone
MANUAL - Manual
BROADSOFT - Broadsoft UC Communicator
PURECONNECT - Genesys PureConnect
PHUB - Plantronics Hub
UNITE - Intel Unite
IVES  - SRV Canada VRS


2. ConnectionsSelected
-----------------------

It is used to select the connections in the connections list. So the user is not required to check in the connections list in the Manage connections dialog of Plantronics Status Indicator
application.

usage:
ConnectionsSelected=SFB

For example, if Connections=SFB and ConnectionsSelected=SFB, then on the Manage Connections dialog of the Plantronics Status Indicator application, the user will see the Skype for Business 
connection selected by default.

This parameter "ConnectionsSelected" will be applicable only when the parameter "Connections" is entered in the command line.

3. SilentConnectionSettings
----------------------------

This parameter is used to avoid user intervention in selecting the connections in the Manage Connections dialog. 

usage:

SilentConnectionSettings=Yes

For example if Connections=SFB and ConnectionsSelected=SFB and SilentConnectionSettings=Yes - as entered on the command line during installation, then once the Plantronics Status Indicator 
application is executed after installation the user is not required to make any configuration changes and the device will begin syncing with Skype for Business immediately.

This parameter "SilentConnectionSettings" will be applicable only when the parameters "Connections" and "ConnectionsSelected" is entered in the command line.

4. StartApp
------------

This parameter is used to automatically start the Plantronics Status Indicator application once the installation finishes through commandline.

usage:

StartApp=Yes

If its not intended to automatically start the application please don't add this parameter in the commandline.

5. PreserveSettings
--------------------

This parameter is used to preserve the current configuration settings or not, when msiexec is executed in silent mode during installation or uninstallation. In Gui mode this parameter is ignored.

usage:

PreserveSettings=No

By default the settings won't be removed. If you want to remove the settings use this parameter, PreserveSettings=No

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

SCCM Deployment of Plantronics Status Indicator Software - starting installation with PlantronicsStatusIndicator.msi:

You can use PlantronicsStatusIndicator.msi file for sccm deployment.

Command line usage:

msiexec /i PlantronicsStatusIndicator.msi /qn

You can deploy the software through msi deployment and the user specific parameters are applicable in the command line.
