//
//  main.m
//  embravasdk
//
//  Created by Senthilnathan T on 28/08/17.
//  Copyright © 2017 Embrava. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
