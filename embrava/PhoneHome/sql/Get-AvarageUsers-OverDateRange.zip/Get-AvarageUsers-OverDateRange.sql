/****** Script for SelectTopNRows command from SSMS  ******/
DECLARE @StartDate DATE, @EndDate DATE, @AverageByDays INT
SET @StartDate = '2023-02-15'
SET @EndDate = '2023-02-17'
SET @AverageByDays = '3'
DECLARE @result_table TABLE (DateValue DATETIME, UID VARCHAR(40), Activity VARCHAR(20));
INSERT INTO @result_table (DateValue, UID, Activity)
SELECT DISTINCT [Date],[UID],[Activity] FROM [dbo].[EmbravaConnect_Activity]
WHERE Activity = 'Running' AND Date BETWEEN @StartDate AND @EndDate;
DECLARE @row_count INT;
SELECT @row_count = COUNT(*) FROM @result_table
SELECT  CONVERT(FLOAT,  @row_count) / @AverageByDays AS AverageUsersOverSpecifiedDays
