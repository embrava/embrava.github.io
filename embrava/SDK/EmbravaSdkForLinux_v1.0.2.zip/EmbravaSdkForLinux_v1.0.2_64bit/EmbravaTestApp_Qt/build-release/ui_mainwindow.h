/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGroupBox *groupBoxBl1020;
    QPushButton *pbRed;
    QPushButton *pbGreen;
    QPushButton *pbBlue;
    QPushButton *pbMagenta;
    QPushButton *pbCyan;
    QPushButton *pbYellow;
    QPushButton *pbWhite;
    QPushButton *pbReset;
    QGroupBox *groupBoxBl3040;
    QGroupBox *groupBoxBl3040_Light;
    QCheckBox *checkBoxDisplayLight;
    QLineEdit *redValue;
    QLabel *label;
    QLineEdit *greenValue;
    QLabel *label_2;
    QLineEdit *blueValue;
    QLabel *label_3;
    QPushButton *pbSetColors;
    QCheckBox *checkBoxDimLight;
    QCheckBox *checkBoxFlashLight;
    QComboBox *cbFlashSpeed;
    QLabel *label_4;
    QGroupBox *groupBoxBl3040_Music;
    QCheckBox *checkBoxPlayMusic;
    QComboBox *cbMusicList;
    QLabel *label_5;
    QSlider *hsVolume;
    QLabel *label_6;
    QCheckBox *checkBoxRptMusic;
    QPushButton *pbGetUid;
    QGroupBox *groupBoxDl;
    QComboBox *cbDeviceList;
    QPushButton *pbUpdateDeviceList;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(671, 603);
        QIcon icon;
        icon.addFile(QStringLiteral("embrava_icon.ico"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        groupBoxBl1020 = new QGroupBox(centralWidget);
        groupBoxBl1020->setObjectName(QStringLiteral("groupBoxBl1020"));
        groupBoxBl1020->setGeometry(QRect(20, 110, 171, 421));
        pbRed = new QPushButton(groupBoxBl1020);
        pbRed->setObjectName(QStringLiteral("pbRed"));
        pbRed->setGeometry(QRect(40, 40, 89, 25));
        pbGreen = new QPushButton(groupBoxBl1020);
        pbGreen->setObjectName(QStringLiteral("pbGreen"));
        pbGreen->setGeometry(QRect(40, 80, 89, 25));
        pbBlue = new QPushButton(groupBoxBl1020);
        pbBlue->setObjectName(QStringLiteral("pbBlue"));
        pbBlue->setGeometry(QRect(40, 120, 89, 25));
        pbMagenta = new QPushButton(groupBoxBl1020);
        pbMagenta->setObjectName(QStringLiteral("pbMagenta"));
        pbMagenta->setGeometry(QRect(40, 160, 89, 25));
        pbCyan = new QPushButton(groupBoxBl1020);
        pbCyan->setObjectName(QStringLiteral("pbCyan"));
        pbCyan->setGeometry(QRect(40, 200, 89, 25));
        pbYellow = new QPushButton(groupBoxBl1020);
        pbYellow->setObjectName(QStringLiteral("pbYellow"));
        pbYellow->setGeometry(QRect(40, 240, 89, 25));
        pbWhite = new QPushButton(groupBoxBl1020);
        pbWhite->setObjectName(QStringLiteral("pbWhite"));
        pbWhite->setGeometry(QRect(40, 280, 89, 25));
        pbReset = new QPushButton(groupBoxBl1020);
        pbReset->setObjectName(QStringLiteral("pbReset"));
        pbReset->setGeometry(QRect(40, 320, 89, 25));
        groupBoxBl3040 = new QGroupBox(centralWidget);
        groupBoxBl3040->setObjectName(QStringLiteral("groupBoxBl3040"));
        groupBoxBl3040->setGeometry(QRect(220, 110, 431, 421));
        groupBoxBl3040_Light = new QGroupBox(groupBoxBl3040);
        groupBoxBl3040_Light->setObjectName(QStringLiteral("groupBoxBl3040_Light"));
        groupBoxBl3040_Light->setGeometry(QRect(20, 40, 391, 161));
        checkBoxDisplayLight = new QCheckBox(groupBoxBl3040_Light);
        checkBoxDisplayLight->setObjectName(QStringLiteral("checkBoxDisplayLight"));
        checkBoxDisplayLight->setGeometry(QRect(10, 30, 121, 23));
        redValue = new QLineEdit(groupBoxBl3040_Light);
        redValue->setObjectName(QStringLiteral("redValue"));
        redValue->setGeometry(QRect(10, 80, 61, 25));
        label = new QLabel(groupBoxBl3040_Light);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 60, 67, 17));
        greenValue = new QLineEdit(groupBoxBl3040_Light);
        greenValue->setObjectName(QStringLiteral("greenValue"));
        greenValue->setGeometry(QRect(90, 80, 61, 25));
        label_2 = new QLabel(groupBoxBl3040_Light);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(90, 60, 67, 17));
        blueValue = new QLineEdit(groupBoxBl3040_Light);
        blueValue->setObjectName(QStringLiteral("blueValue"));
        blueValue->setGeometry(QRect(170, 80, 61, 25));
        label_3 = new QLabel(groupBoxBl3040_Light);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(170, 60, 67, 17));
        pbSetColors = new QPushButton(groupBoxBl3040_Light);
        pbSetColors->setObjectName(QStringLiteral("pbSetColors"));
        pbSetColors->setGeometry(QRect(290, 80, 91, 25));
        checkBoxDimLight = new QCheckBox(groupBoxBl3040_Light);
        checkBoxDimLight->setObjectName(QStringLiteral("checkBoxDimLight"));
        checkBoxDimLight->setGeometry(QRect(10, 120, 91, 23));
        checkBoxFlashLight = new QCheckBox(groupBoxBl3040_Light);
        checkBoxFlashLight->setObjectName(QStringLiteral("checkBoxFlashLight"));
        checkBoxFlashLight->setGeometry(QRect(110, 120, 101, 23));
        cbFlashSpeed = new QComboBox(groupBoxBl3040_Light);
        cbFlashSpeed->setObjectName(QStringLiteral("cbFlashSpeed"));
        cbFlashSpeed->setGeometry(QRect(290, 120, 91, 25));
        label_4 = new QLabel(groupBoxBl3040_Light);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(240, 120, 41, 21));
        groupBoxBl3040_Music = new QGroupBox(groupBoxBl3040);
        groupBoxBl3040_Music->setObjectName(QStringLiteral("groupBoxBl3040_Music"));
        groupBoxBl3040_Music->setGeometry(QRect(20, 200, 391, 161));
        checkBoxPlayMusic = new QCheckBox(groupBoxBl3040_Music);
        checkBoxPlayMusic->setObjectName(QStringLiteral("checkBoxPlayMusic"));
        checkBoxPlayMusic->setGeometry(QRect(10, 30, 121, 23));
        cbMusicList = new QComboBox(groupBoxBl3040_Music);
        cbMusicList->setObjectName(QStringLiteral("cbMusicList"));
        cbMusicList->setGeometry(QRect(10, 80, 131, 25));
        label_5 = new QLabel(groupBoxBl3040_Music);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(10, 60, 41, 21));
        hsVolume = new QSlider(groupBoxBl3040_Music);
        hsVolume->setObjectName(QStringLiteral("hsVolume"));
        hsVolume->setGeometry(QRect(200, 80, 160, 16));
        hsVolume->setMinimum(1);
        hsVolume->setMaximum(10);
        hsVolume->setPageStep(2);
        hsVolume->setValue(5);
        hsVolume->setOrientation(Qt::Horizontal);
        label_6 = new QLabel(groupBoxBl3040_Music);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(200, 60, 51, 21));
        checkBoxRptMusic = new QCheckBox(groupBoxBl3040_Music);
        checkBoxRptMusic->setObjectName(QStringLiteral("checkBoxRptMusic"));
        checkBoxRptMusic->setGeometry(QRect(10, 120, 121, 23));
        pbGetUid = new QPushButton(groupBoxBl3040);
        pbGetUid->setObjectName(QStringLiteral("pbGetUid"));
        pbGetUid->setGeometry(QRect(320, 380, 89, 25));
        groupBoxDl = new QGroupBox(centralWidget);
        groupBoxDl->setObjectName(QStringLiteral("groupBoxDl"));
        groupBoxDl->setGeometry(QRect(20, 20, 631, 81));
        groupBoxDl->setAutoFillBackground(true);
        cbDeviceList = new QComboBox(groupBoxDl);
        cbDeviceList->setObjectName(QStringLiteral("cbDeviceList"));
        cbDeviceList->setGeometry(QRect(20, 40, 481, 25));
        pbUpdateDeviceList = new QPushButton(groupBoxDl);
        pbUpdateDeviceList->setObjectName(QStringLiteral("pbUpdateDeviceList"));
        pbUpdateDeviceList->setGeometry(QRect(520, 40, 89, 25));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 671, 22));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Embrava Test App", Q_NULLPTR));
        groupBoxBl1020->setTitle(QApplication::translate("MainWindow", "Blync v10 v20 devices", Q_NULLPTR));
        pbRed->setText(QApplication::translate("MainWindow", "Red", Q_NULLPTR));
        pbGreen->setText(QApplication::translate("MainWindow", "Green", Q_NULLPTR));
        pbBlue->setText(QApplication::translate("MainWindow", "Blue", Q_NULLPTR));
        pbMagenta->setText(QApplication::translate("MainWindow", "Magenta", Q_NULLPTR));
        pbCyan->setText(QApplication::translate("MainWindow", "Cyan", Q_NULLPTR));
        pbYellow->setText(QApplication::translate("MainWindow", "Yellow", Q_NULLPTR));
        pbWhite->setText(QApplication::translate("MainWindow", "White", Q_NULLPTR));
        pbReset->setText(QApplication::translate("MainWindow", "Reset", Q_NULLPTR));
        groupBoxBl3040->setTitle(QApplication::translate("MainWindow", "Blync v30 v40 devices", Q_NULLPTR));
        groupBoxBl3040_Light->setTitle(QString());
        checkBoxDisplayLight->setText(QApplication::translate("MainWindow", "Display Light", Q_NULLPTR));
        redValue->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "Red", Q_NULLPTR));
        greenValue->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Green", Q_NULLPTR));
        blueValue->setText(QApplication::translate("MainWindow", "255", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Blue", Q_NULLPTR));
        pbSetColors->setText(QApplication::translate("MainWindow", "Set", Q_NULLPTR));
        checkBoxDimLight->setText(QApplication::translate("MainWindow", "Dim Light", Q_NULLPTR));
        checkBoxFlashLight->setText(QApplication::translate("MainWindow", "Flash Light", Q_NULLPTR));
        cbFlashSpeed->clear();
        cbFlashSpeed->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Slow", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Medium", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Fast", Q_NULLPTR)
        );
        label_4->setText(QApplication::translate("MainWindow", "Speed", Q_NULLPTR));
        groupBoxBl3040_Music->setTitle(QString());
        checkBoxPlayMusic->setText(QApplication::translate("MainWindow", "Play Music", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Music", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "Volume", Q_NULLPTR));
        checkBoxRptMusic->setText(QApplication::translate("MainWindow", "Repeat Music", Q_NULLPTR));
        pbGetUid->setText(QApplication::translate("MainWindow", "Get Uid", Q_NULLPTR));
        groupBoxDl->setTitle(QApplication::translate("MainWindow", "Select Device", Q_NULLPTR));
        pbUpdateDeviceList->setText(QApplication::translate("MainWindow", "Update List", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
