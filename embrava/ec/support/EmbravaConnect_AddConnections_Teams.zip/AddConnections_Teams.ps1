Stop-Process -name EmbravaConnect -Force
$users = Get-ChildItem C:\Users
foreach ($user in $users) {
    $folder = "$($user.fullname)\AppData\Local\Embrava_Pty_Ltd"
    If (Test-Path $folder) {
        Remove-Item $folder -Recurse -Force -ErrorAction silentlycontinue 
    } 
}
Push-Location $PSScriptRoot
Write-Host CurrentDirectory $CurDir
regedit /s .\AddConnections_Teams.reg
Pop-Location


