#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_cbDeviceList_activated(int index);

    void SearchAndListBlyncDevices();

    void CleanUp();

    void EnableUIComponentsForBlyncUsbDevices();
    void DisableUIComponentsForBlyncUsbDevices();

    void EnableUIComponentsForBlyncUsb1020Devices();
    void DisableUIComponentsForBlyncUsb1020Devices();

    void on_pbUpdateDeviceList_clicked();

    void on_pbRed_clicked();

    void on_pbGreen_clicked();

    void on_pbBlue_clicked();

    void on_pbMagenta_clicked();

    void on_pbCyan_clicked();

    void on_pbYellow_clicked();

    void on_pbWhite_clicked();

    void on_pbReset_clicked();

    void on_checkBoxDisplayLight_stateChanged(int arg1);

    void on_cbDeviceList_currentIndexChanged(int index);

    void on_pbSetColors_clicked();

    void on_checkBoxDimLight_stateChanged(int arg1);

    void on_checkBoxFlashLight_stateChanged(int arg1);

    void on_checkBoxPlayMusic_stateChanged(int arg1);

    void on_cbMusicList_currentIndexChanged(int index);

    void on_cbFlashSpeed_currentIndexChanged(int index);

    void on_hsVolume_sliderMoved(int position);

    void on_checkBoxRptMusic_stateChanged(int arg1);

    void on_pbGetUid_clicked();

    void SetRgbValues();

    void on_hsVolume_valueChanged(int value);

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
