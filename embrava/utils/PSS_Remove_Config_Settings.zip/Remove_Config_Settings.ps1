Stop-Process -name EmbravaConnect -Force
# Define the target folder
$targetFolder = Join-Path $env:LOCALAPPDATA "Embrava_Pty_Ltd"

# Check if the folder exists
if (Test-Path -Path $targetFolder) {
    # Get all items in the folder and delete them
    Get-ChildItem -Path $targetFolder -Recurse | Remove-Item -Force -Recurse
    Write-Host "Contents of $targetFolder have been deleted."
} else {
    Write-Host "Folder not found: $targetFolder"
}
