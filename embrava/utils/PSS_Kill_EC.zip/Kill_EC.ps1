# Get all processes with the name 'EmbravaConnect' (without '.exe')
$processes = Get-Process | Where-Object { $_.Name -eq "EmbravaConnect" }

# Loop through the processes and terminate them
foreach ($process in $processes) {
    # Outputting the process ID that will be stopped
    Write-Host "Stopping process: $($process.Id)"
    Stop-Process -Id $process.Id -Force
}

Write-Host "All instances of EmbravaConnect.exe have been terminated."
