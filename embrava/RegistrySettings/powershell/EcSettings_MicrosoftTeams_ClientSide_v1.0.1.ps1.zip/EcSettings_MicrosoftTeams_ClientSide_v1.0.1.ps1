
# Embrava Connect - Microsoft Teams Client-Side Settings Deployment Script
# Deploy via Intune with 'Run this script using the logged on credentials' = Yes

# Applicable values for each device function is given below:

# Default values for each setting is provided in this file. You may leave the default values as they are or edit it as per your needs.

# Enabled: "Yes", "No"
# Light: "Red", "Orange", "Yellow", "Green", "Blue", "Purple", "No Color"
# Flash: "High", "Medium", "Low", "No Flash"
# Brightness: "Full", "Dim", "No Brightness"
# Ringtone (Sound): "Standard", "Ringading", "Invader", "Crystal", "Millepede", "Azure", "Cogi", "Techzor", "Freedom", "Circuit", "No Tone"
# Volume: "0 %", "25 %", "50 %", "75 %", "100 %"
# RingMode:  "Play Once", "Repeat", "Off" 

# "DisableClientConfig"="True", this means the user will not be able to edit the configuration settings on the Embrava Connect connection tabs

$baseKey = "HKCU:\Software\Embrava\Configuration\Teams"

# Ensure parent registry path exists
New-Item -Path "HKCU:\Software\Embrava\Configuration" -Force | Out-Null
New-Item -Path $baseKey -Force | Out-Null

# ;;;;;;;;;;;;Device Functions Start;;;;;;;;;;;;

# Incoming IM
Set-ItemProperty -Path $baseKey -Name "InComingIMEnabled"     -Value "Yes"
Set-ItemProperty -Path $baseKey -Name "InComingIMLight"       -Value "Red"
Set-ItemProperty -Path $baseKey -Name "InComingIMBrightness"  -Value "Full"
Set-ItemProperty -Path $baseKey -Name "InComingIMFlashSpeed"  -Value "Medium"
Set-ItemProperty -Path $baseKey -Name "InComingIMSound"       -Value "Cogi"
Set-ItemProperty -Path $baseKey -Name "InComingIMVolume"      -Value "25 %"
Set-ItemProperty -Path $baseKey -Name "InComingIMRingMode"    -Value "Play Once"

# Incoming Call
Set-ItemProperty -Path $baseKey -Name "InComingCallEnabled"   -Value "Yes"
Set-ItemProperty -Path $baseKey -Name "InComingCallLight"     -Value "Red"
Set-ItemProperty -Path $baseKey -Name "InComingCallBrightness" -Value "Full"
Set-ItemProperty -Path $baseKey -Name "InComingCallFlashSpeed" -Value "Medium"
Set-ItemProperty -Path $baseKey -Name "InComingCallSound"     -Value "Standard"
Set-ItemProperty -Path $baseKey -Name "InComingCallVolume"    -Value "25 %"
Set-ItemProperty -Path $baseKey -Name "InComingCallRingMode"  -Value "Repeat"

# On Call
Set-ItemProperty -Path $baseKey -Name "OnCallEnabled"         -Value "Yes"
Set-ItemProperty -Path $baseKey -Name "OnCallLight"           -Value "Red"
Set-ItemProperty -Path $baseKey -Name "OnCallBrightness"      -Value "Full"
Set-ItemProperty -Path $baseKey -Name "OnCallFlashSpeed"      -Value "Low"
Set-ItemProperty -Path $baseKey -Name "OnCallSound"           -Value "No Tone"
Set-ItemProperty -Path $baseKey -Name "OnCallVolume"          -Value "0 %"
Set-ItemProperty -Path $baseKey -Name "OnCallRingMode"        -Value "Off"

# Available
Set-ItemProperty -Path $baseKey -Name "AvailableEnabled"      -Value "Yes"
Set-ItemProperty -Path $baseKey -Name "AvailableLight"        -Value "Green"
Set-ItemProperty -Path $baseKey -Name "AvailableBrightness"   -Value "Full"
Set-ItemProperty -Path $baseKey -Name "AvailableFlashSpeed"   -Value "No Flash"
Set-ItemProperty -Path $baseKey -Name "AvailableSound"        -Value "No Tone"
Set-ItemProperty -Path $baseKey -Name "AvailableVolume"       -Value "0 %"
Set-ItemProperty -Path $baseKey -Name "AvailableRingMode"     -Value "Off"

# Away
Set-ItemProperty -Path $baseKey -Name "AwayEnabled"           -Value "Yes"
Set-ItemProperty -Path $baseKey -Name "AwayLight"             -Value "Yellow"
Set-ItemProperty -Path $baseKey -Name "AwayBrightness"        -Value "Full"
Set-ItemProperty -Path $baseKey -Name "AwayFlashSpeed"        -Value "No Flash"
Set-ItemProperty -Path $baseKey -Name "AwaySound"             -Value "No Tone"
Set-ItemProperty -Path $baseKey -Name "AwayVolume"            -Value "0 %"
Set-ItemProperty -Path $baseKey -Name "AwayRingMode"          -Value "Off"

# Busy
Set-ItemProperty -Path $baseKey -Name "BusyEnabled"           -Value "Yes"
Set-ItemProperty -Path $baseKey -Name "BusyLight"             -Value "Red"
Set-ItemProperty -Path $baseKey -Name "BusyBrightness"        -Value "Full"
Set-ItemProperty -Path $baseKey -Name "BusyFlashSpeed"        -Value "No Flash"
Set-ItemProperty -Path $baseKey -Name "BusySound"             -Value "No Tone"
Set-ItemProperty -Path $baseKey -Name "BusyVolume"            -Value "0 %"
Set-ItemProperty -Path $baseKey -Name "BusyRingMode"          -Value "Off"

# Do Not Disturb (DND)
Set-ItemProperty -Path $baseKey -Name "DNDEnabled"            -Value "Yes"
Set-ItemProperty -Path $baseKey -Name "DNDLight"              -Value "Purple"
Set-ItemProperty -Path $baseKey -Name "DNDBrightness"         -Value "Full"
Set-ItemProperty -Path $baseKey -Name "DNDFlashSpeed"         -Value "No Flash"
Set-ItemProperty -Path $baseKey -Name "DNDSound"              -Value "No Tone"
Set-ItemProperty -Path $baseKey -Name "DNDVolume"             -Value "0 %"
Set-ItemProperty -Path $baseKey -Name "DNDRingMode"           -Value "Off"

# Lock Configuration (prevent user changes in UI)
Set-ItemProperty -Path $baseKey -Name "DisableClientConfig"   -Value "True"

# ;;;;;;;;;;;;Device Functions End;;;;;;;;;;;;
