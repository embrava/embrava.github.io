﻿namespace BlyncLightTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonUpdateDevList = new System.Windows.Forms.Button();
            this.comboBoxDeviceList = new System.Windows.Forms.ComboBox();
            this.checkBoxRepeatMusic = new System.Windows.Forms.CheckBox();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxMusicList = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBoxPlayMusic = new System.Windows.Forms.CheckBox();
            this.groupBoxNewDeviceControls = new System.Windows.Forms.GroupBox();
            this.groupBoxUID = new System.Windows.Forms.GroupBox();
            this.buttonIncUID = new System.Windows.Forms.Button();
            this.buttonDecUID = new System.Windows.Forms.Button();
            this.buttonWriteUid = new System.Windows.Forms.Button();
            this.textBoxUid = new System.Windows.Forms.TextBox();
            this.buttonGetUid = new System.Windows.Forms.Button();
            this.groupBoxMusicControls = new System.Windows.Forms.GroupBox();
            this.checkBoxMute = new System.Windows.Forms.CheckBox();
            this.groupBoxLightControls = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonOrange = new System.Windows.Forms.Button();
            this.buttonYellow1 = new System.Windows.Forms.Button();
            this.buttonPurple = new System.Windows.Forms.Button();
            this.buttonRed1 = new System.Windows.Forms.Button();
            this.buttonBlue1 = new System.Windows.Forms.Button();
            this.buttonWhite1 = new System.Windows.Forms.Button();
            this.buttonGreen1 = new System.Windows.Forms.Button();
            this.buttonSetRgbValues = new System.Windows.Forms.Button();
            this.comboBoxFlashSpeedList = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBoxFlashLight = new System.Windows.Forms.CheckBox();
            this.checkBoxDimLight = new System.Windows.Forms.CheckBox();
            this.labelBlue = new System.Windows.Forms.Label();
            this.labelGreen = new System.Windows.Forms.Label();
            this.labelRed = new System.Windows.Forms.Label();
            this.textBoxBlue = new System.Windows.Forms.TextBox();
            this.vScrollBarBlue = new System.Windows.Forms.VScrollBar();
            this.textBoxGreen = new System.Windows.Forms.TextBox();
            this.vScrollBarGreen = new System.Windows.Forms.VScrollBar();
            this.checkBoxDisplayLight = new System.Windows.Forms.CheckBox();
            this.textBoxRed = new System.Windows.Forms.TextBox();
            this.vScrollBarRed = new System.Windows.Forms.VScrollBar();
            this.groupBoxNameDisplayLcd = new System.Windows.Forms.GroupBox();
            this.buttonIncUIDNp = new System.Windows.Forms.Button();
            this.buttonDecUIDNp = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonGetNdUID = new System.Windows.Forms.Button();
            this.buttonDisplayTextPxL1L2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxFontsL2 = new System.Windows.Forms.ComboBox();
            this.textBoxNameStringL2 = new System.Windows.Forms.TextBox();
            this.textBoxNdUid = new System.Windows.Forms.TextBox();
            this.buttonDisplayTextPxL1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonDisplayTextDefault = new System.Windows.Forms.Button();
            this.comboBoxFontsL1 = new System.Windows.Forms.ComboBox();
            this.buttonTurnOnPixels = new System.Windows.Forms.Button();
            this.buttonWriteNdUID = new System.Windows.Forms.Button();
            this.buttonResetNameDisplay = new System.Windows.Forms.Button();
            this.buttonClearText = new System.Windows.Forms.Button();
            this.textBoxNameStringL1 = new System.Windows.Forms.TextBox();
            this.Log = new System.Windows.Forms.GroupBox();
            this.buttonClearLog = new System.Windows.Forms.Button();
            this.textBoxLog = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.checkBoxPulsate = new System.Windows.Forms.CheckBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.groupBoxNewDeviceControls.SuspendLayout();
            this.groupBoxUID.SuspendLayout();
            this.groupBoxMusicControls.SuspendLayout();
            this.groupBoxLightControls.SuspendLayout();
            this.groupBoxNameDisplayLcd.SuspendLayout();
            this.Log.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonUpdateDevList);
            this.groupBox2.Controls.Add(this.comboBoxDeviceList);
            this.groupBox2.Location = new System.Drawing.Point(16, 2);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(635, 60);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Select Device";
            // 
            // buttonUpdateDevList
            // 
            this.buttonUpdateDevList.Location = new System.Drawing.Point(507, 18);
            this.buttonUpdateDevList.Margin = new System.Windows.Forms.Padding(4);
            this.buttonUpdateDevList.Name = "buttonUpdateDevList";
            this.buttonUpdateDevList.Size = new System.Drawing.Size(113, 28);
            this.buttonUpdateDevList.TabIndex = 1;
            this.buttonUpdateDevList.Text = "Update";
            this.buttonUpdateDevList.UseVisualStyleBackColor = true;
            this.buttonUpdateDevList.Click += new System.EventHandler(this.buttonUpdateDevList_Click);
            // 
            // comboBoxDeviceList
            // 
            this.comboBoxDeviceList.AllowDrop = true;
            this.comboBoxDeviceList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDeviceList.FormattingEnabled = true;
            this.comboBoxDeviceList.Location = new System.Drawing.Point(8, 21);
            this.comboBoxDeviceList.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxDeviceList.Name = "comboBoxDeviceList";
            this.comboBoxDeviceList.Size = new System.Drawing.Size(477, 24);
            this.comboBoxDeviceList.TabIndex = 0;
            this.comboBoxDeviceList.SelectedIndexChanged += new System.EventHandler(this.comboBoxDeviceList_SelectedIndexChanged);
            // 
            // checkBoxRepeatMusic
            // 
            this.checkBoxRepeatMusic.AutoSize = true;
            this.checkBoxRepeatMusic.Location = new System.Drawing.Point(11, 105);
            this.checkBoxRepeatMusic.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxRepeatMusic.Name = "checkBoxRepeatMusic";
            this.checkBoxRepeatMusic.Size = new System.Drawing.Size(116, 21);
            this.checkBoxRepeatMusic.TabIndex = 24;
            this.checkBoxRepeatMusic.Text = "Repeat Music";
            this.checkBoxRepeatMusic.UseVisualStyleBackColor = true;
            this.checkBoxRepeatMusic.CheckedChanged += new System.EventHandler(this.checkBoxRepeatMusic_CheckedChanged);
            // 
            // trackBar1
            // 
            this.trackBar1.LargeChange = 3;
            this.trackBar1.Location = new System.Drawing.Point(431, 60);
            this.trackBar1.Margin = new System.Windows.Forms.Padding(4);
            this.trackBar1.Minimum = 1;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(175, 56);
            this.trackBar1.TabIndex = 23;
            this.trackBar1.Value = 5;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(440, 39);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 17);
            this.label3.TabIndex = 29;
            this.label3.Text = "Volume";
            // 
            // comboBoxMusicList
            // 
            this.comboBoxMusicList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMusicList.FormattingEnabled = true;
            this.comboBoxMusicList.Location = new System.Drawing.Point(11, 60);
            this.comboBoxMusicList.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxMusicList.Name = "comboBoxMusicList";
            this.comboBoxMusicList.Size = new System.Drawing.Size(173, 24);
            this.comboBoxMusicList.TabIndex = 22;
            this.comboBoxMusicList.SelectedIndexChanged += new System.EventHandler(this.comboBoxMusicList_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 17);
            this.label1.TabIndex = 25;
            this.label1.Text = "Music";
            // 
            // checkBoxPlayMusic
            // 
            this.checkBoxPlayMusic.AutoSize = true;
            this.checkBoxPlayMusic.Location = new System.Drawing.Point(11, 10);
            this.checkBoxPlayMusic.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxPlayMusic.Name = "checkBoxPlayMusic";
            this.checkBoxPlayMusic.Size = new System.Drawing.Size(97, 21);
            this.checkBoxPlayMusic.TabIndex = 21;
            this.checkBoxPlayMusic.Text = "Play Music";
            this.checkBoxPlayMusic.UseVisualStyleBackColor = true;
            this.checkBoxPlayMusic.CheckedChanged += new System.EventHandler(this.checkBoxPlayMusic_CheckedChanged);
            // 
            // groupBoxNewDeviceControls
            // 
            this.groupBoxNewDeviceControls.Controls.Add(this.groupBoxUID);
            this.groupBoxNewDeviceControls.Controls.Add(this.groupBoxMusicControls);
            this.groupBoxNewDeviceControls.Controls.Add(this.groupBoxLightControls);
            this.groupBoxNewDeviceControls.Location = new System.Drawing.Point(16, 66);
            this.groupBoxNewDeviceControls.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxNewDeviceControls.Name = "groupBoxNewDeviceControls";
            this.groupBoxNewDeviceControls.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxNewDeviceControls.Size = new System.Drawing.Size(635, 445);
            this.groupBoxNewDeviceControls.TabIndex = 32;
            this.groupBoxNewDeviceControls.TabStop = false;
            this.groupBoxNewDeviceControls.Text = "Blynclight Std, Plus, Mini, Wireless, Headsets";
            // 
            // groupBoxUID
            // 
            this.groupBoxUID.Controls.Add(this.buttonIncUID);
            this.groupBoxUID.Controls.Add(this.buttonDecUID);
            this.groupBoxUID.Controls.Add(this.buttonWriteUid);
            this.groupBoxUID.Controls.Add(this.textBoxUid);
            this.groupBoxUID.Controls.Add(this.buttonGetUid);
            this.groupBoxUID.Location = new System.Drawing.Point(13, 343);
            this.groupBoxUID.Name = "groupBoxUID";
            this.groupBoxUID.Size = new System.Drawing.Size(615, 95);
            this.groupBoxUID.TabIndex = 34;
            this.groupBoxUID.TabStop = false;
            this.groupBoxUID.Text = "UID";
            // 
            // buttonIncUID
            // 
            this.buttonIncUID.Location = new System.Drawing.Point(457, 22);
            this.buttonIncUID.Margin = new System.Windows.Forms.Padding(4);
            this.buttonIncUID.Name = "buttonIncUID";
            this.buttonIncUID.Size = new System.Drawing.Size(35, 28);
            this.buttonIncUID.TabIndex = 50;
            this.buttonIncUID.Text = "+";
            this.buttonIncUID.UseVisualStyleBackColor = true;
            this.buttonIncUID.Click += new System.EventHandler(this.buttonIncUID_Click);
            // 
            // buttonDecUID
            // 
            this.buttonDecUID.Location = new System.Drawing.Point(16, 22);
            this.buttonDecUID.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDecUID.Name = "buttonDecUID";
            this.buttonDecUID.Size = new System.Drawing.Size(35, 28);
            this.buttonDecUID.TabIndex = 51;
            this.buttonDecUID.Text = "-";
            this.buttonDecUID.UseVisualStyleBackColor = true;
            this.buttonDecUID.Click += new System.EventHandler(this.buttonDecUID_Click);
            // 
            // buttonWriteUid
            // 
            this.buttonWriteUid.Location = new System.Drawing.Point(515, 19);
            this.buttonWriteUid.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWriteUid.Name = "buttonWriteUid";
            this.buttonWriteUid.Size = new System.Drawing.Size(91, 28);
            this.buttonWriteUid.TabIndex = 49;
            this.buttonWriteUid.Text = "Write UID";
            this.buttonWriteUid.UseVisualStyleBackColor = true;
            this.buttonWriteUid.Click += new System.EventHandler(this.buttonWriteUid_Click);
            // 
            // textBoxUid
            // 
            this.textBoxUid.Location = new System.Drawing.Point(61, 25);
            this.textBoxUid.Name = "textBoxUid";
            this.textBoxUid.Size = new System.Drawing.Size(385, 22);
            this.textBoxUid.TabIndex = 48;
            // 
            // buttonGetUid
            // 
            this.buttonGetUid.Enabled = false;
            this.buttonGetUid.Location = new System.Drawing.Point(514, 55);
            this.buttonGetUid.Margin = new System.Windows.Forms.Padding(4);
            this.buttonGetUid.Name = "buttonGetUid";
            this.buttonGetUid.Size = new System.Drawing.Size(92, 28);
            this.buttonGetUid.TabIndex = 47;
            this.buttonGetUid.Text = "Get UID";
            this.buttonGetUid.UseVisualStyleBackColor = true;
            this.buttonGetUid.Click += new System.EventHandler(this.buttonGetUid_Click);
            // 
            // groupBoxMusicControls
            // 
            this.groupBoxMusicControls.Controls.Add(this.checkBoxMute);
            this.groupBoxMusicControls.Controls.Add(this.checkBoxPlayMusic);
            this.groupBoxMusicControls.Controls.Add(this.checkBoxRepeatMusic);
            this.groupBoxMusicControls.Controls.Add(this.trackBar1);
            this.groupBoxMusicControls.Controls.Add(this.comboBoxMusicList);
            this.groupBoxMusicControls.Controls.Add(this.label1);
            this.groupBoxMusicControls.Controls.Add(this.label3);
            this.groupBoxMusicControls.Location = new System.Drawing.Point(13, 196);
            this.groupBoxMusicControls.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxMusicControls.Name = "groupBoxMusicControls";
            this.groupBoxMusicControls.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxMusicControls.Size = new System.Drawing.Size(614, 145);
            this.groupBoxMusicControls.TabIndex = 33;
            this.groupBoxMusicControls.TabStop = false;
            // 
            // checkBoxMute
            // 
            this.checkBoxMute.AutoSize = true;
            this.checkBoxMute.Location = new System.Drawing.Point(443, 105);
            this.checkBoxMute.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxMute.Name = "checkBoxMute";
            this.checkBoxMute.Size = new System.Drawing.Size(61, 21);
            this.checkBoxMute.TabIndex = 30;
            this.checkBoxMute.Text = "Mute";
            this.checkBoxMute.UseVisualStyleBackColor = true;
            this.checkBoxMute.CheckedChanged += new System.EventHandler(this.checkBoxMute_CheckedChanged);
            // 
            // groupBoxLightControls
            // 
            this.groupBoxLightControls.Controls.Add(this.checkBoxPulsate);
            this.groupBoxLightControls.Controls.Add(this.button1);
            this.groupBoxLightControls.Controls.Add(this.buttonOrange);
            this.groupBoxLightControls.Controls.Add(this.buttonYellow1);
            this.groupBoxLightControls.Controls.Add(this.buttonPurple);
            this.groupBoxLightControls.Controls.Add(this.buttonRed1);
            this.groupBoxLightControls.Controls.Add(this.buttonBlue1);
            this.groupBoxLightControls.Controls.Add(this.buttonWhite1);
            this.groupBoxLightControls.Controls.Add(this.buttonGreen1);
            this.groupBoxLightControls.Controls.Add(this.buttonSetRgbValues);
            this.groupBoxLightControls.Controls.Add(this.comboBoxFlashSpeedList);
            this.groupBoxLightControls.Controls.Add(this.label2);
            this.groupBoxLightControls.Controls.Add(this.checkBoxFlashLight);
            this.groupBoxLightControls.Controls.Add(this.checkBoxDimLight);
            this.groupBoxLightControls.Controls.Add(this.labelBlue);
            this.groupBoxLightControls.Controls.Add(this.labelGreen);
            this.groupBoxLightControls.Controls.Add(this.labelRed);
            this.groupBoxLightControls.Controls.Add(this.textBoxBlue);
            this.groupBoxLightControls.Controls.Add(this.vScrollBarBlue);
            this.groupBoxLightControls.Controls.Add(this.textBoxGreen);
            this.groupBoxLightControls.Controls.Add(this.vScrollBarGreen);
            this.groupBoxLightControls.Controls.Add(this.checkBoxDisplayLight);
            this.groupBoxLightControls.Controls.Add(this.textBoxRed);
            this.groupBoxLightControls.Controls.Add(this.vScrollBarRed);
            this.groupBoxLightControls.Location = new System.Drawing.Point(12, 17);
            this.groupBoxLightControls.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxLightControls.Name = "groupBoxLightControls";
            this.groupBoxLightControls.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxLightControls.Size = new System.Drawing.Size(615, 181);
            this.groupBoxLightControls.TabIndex = 22;
            this.groupBoxLightControls.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(539, 46);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(68, 28);
            this.button1.TabIndex = 36;
            this.button1.Text = "ST";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // buttonOrange
            // 
            this.buttonOrange.Location = new System.Drawing.Point(387, 10);
            this.buttonOrange.Margin = new System.Windows.Forms.Padding(4);
            this.buttonOrange.Name = "buttonOrange";
            this.buttonOrange.Size = new System.Drawing.Size(68, 28);
            this.buttonOrange.TabIndex = 35;
            this.buttonOrange.Text = "Orange";
            this.buttonOrange.UseVisualStyleBackColor = true;
            this.buttonOrange.Click += new System.EventHandler(this.buttonOrange_Click);
            // 
            // buttonYellow1
            // 
            this.buttonYellow1.Location = new System.Drawing.Point(463, 10);
            this.buttonYellow1.Margin = new System.Windows.Forms.Padding(4);
            this.buttonYellow1.Name = "buttonYellow1";
            this.buttonYellow1.Size = new System.Drawing.Size(68, 28);
            this.buttonYellow1.TabIndex = 34;
            this.buttonYellow1.Text = "Yellow";
            this.buttonYellow1.UseVisualStyleBackColor = true;
            this.buttonYellow1.Click += new System.EventHandler(this.buttonYellow1_Click);
            // 
            // buttonPurple
            // 
            this.buttonPurple.Location = new System.Drawing.Point(539, 10);
            this.buttonPurple.Margin = new System.Windows.Forms.Padding(4);
            this.buttonPurple.Name = "buttonPurple";
            this.buttonPurple.Size = new System.Drawing.Size(68, 28);
            this.buttonPurple.TabIndex = 33;
            this.buttonPurple.Text = "Purple";
            this.buttonPurple.UseVisualStyleBackColor = true;
            this.buttonPurple.Click += new System.EventHandler(this.buttonPurple_Click);
            // 
            // buttonRed1
            // 
            this.buttonRed1.Location = new System.Drawing.Point(159, 10);
            this.buttonRed1.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRed1.Name = "buttonRed1";
            this.buttonRed1.Size = new System.Drawing.Size(68, 28);
            this.buttonRed1.TabIndex = 30;
            this.buttonRed1.Text = "Red";
            this.buttonRed1.UseVisualStyleBackColor = true;
            this.buttonRed1.Click += new System.EventHandler(this.buttonRed1_Click);
            // 
            // buttonBlue1
            // 
            this.buttonBlue1.Location = new System.Drawing.Point(311, 10);
            this.buttonBlue1.Margin = new System.Windows.Forms.Padding(4);
            this.buttonBlue1.Name = "buttonBlue1";
            this.buttonBlue1.Size = new System.Drawing.Size(68, 28);
            this.buttonBlue1.TabIndex = 29;
            this.buttonBlue1.Text = "Blue";
            this.buttonBlue1.UseVisualStyleBackColor = true;
            this.buttonBlue1.Click += new System.EventHandler(this.buttonBlue1_Click);
            // 
            // buttonWhite1
            // 
            this.buttonWhite1.Location = new System.Drawing.Point(159, 46);
            this.buttonWhite1.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWhite1.Name = "buttonWhite1";
            this.buttonWhite1.Size = new System.Drawing.Size(68, 28);
            this.buttonWhite1.TabIndex = 28;
            this.buttonWhite1.Text = "White";
            this.buttonWhite1.UseVisualStyleBackColor = true;
            this.buttonWhite1.Click += new System.EventHandler(this.buttonWhite1_Click);
            // 
            // buttonGreen1
            // 
            this.buttonGreen1.Location = new System.Drawing.Point(235, 10);
            this.buttonGreen1.Margin = new System.Windows.Forms.Padding(4);
            this.buttonGreen1.Name = "buttonGreen1";
            this.buttonGreen1.Size = new System.Drawing.Size(68, 28);
            this.buttonGreen1.TabIndex = 27;
            this.buttonGreen1.Text = "Green";
            this.buttonGreen1.UseVisualStyleBackColor = true;
            this.buttonGreen1.Click += new System.EventHandler(this.buttonGreen1_Click);
            // 
            // buttonSetRgbValues
            // 
            this.buttonSetRgbValues.Location = new System.Drawing.Point(287, 106);
            this.buttonSetRgbValues.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSetRgbValues.Name = "buttonSetRgbValues";
            this.buttonSetRgbValues.Size = new System.Drawing.Size(103, 28);
            this.buttonSetRgbValues.TabIndex = 17;
            this.buttonSetRgbValues.Text = "Set";
            this.buttonSetRgbValues.UseVisualStyleBackColor = true;
            this.buttonSetRgbValues.Click += new System.EventHandler(this.buttonSetRgbValues_Click);
            // 
            // comboBoxFlashSpeedList
            // 
            this.comboBoxFlashSpeedList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFlashSpeedList.FormattingEnabled = true;
            this.comboBoxFlashSpeedList.Items.AddRange(new object[] {
            "Slow",
            "Med",
            "Fast",
            "Pulsating"});
            this.comboBoxFlashSpeedList.Location = new System.Drawing.Point(287, 151);
            this.comboBoxFlashSpeedList.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxFlashSpeedList.Name = "comboBoxFlashSpeedList";
            this.comboBoxFlashSpeedList.Size = new System.Drawing.Size(103, 24);
            this.comboBoxFlashSpeedList.TabIndex = 20;
            this.comboBoxFlashSpeedList.SelectedIndexChanged += new System.EventHandler(this.comboBoxFlashSpeedList_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(232, 153);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 17);
            this.label2.TabIndex = 26;
            this.label2.Text = "Speed";
            // 
            // checkBoxFlashLight
            // 
            this.checkBoxFlashLight.AutoSize = true;
            this.checkBoxFlashLight.Location = new System.Drawing.Point(105, 153);
            this.checkBoxFlashLight.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxFlashLight.Name = "checkBoxFlashLight";
            this.checkBoxFlashLight.Size = new System.Drawing.Size(99, 21);
            this.checkBoxFlashLight.TabIndex = 19;
            this.checkBoxFlashLight.Text = "Flash Light";
            this.checkBoxFlashLight.UseVisualStyleBackColor = true;
            this.checkBoxFlashLight.CheckedChanged += new System.EventHandler(this.checkBoxFlashLight_CheckedChanged);
            // 
            // checkBoxDimLight
            // 
            this.checkBoxDimLight.AutoSize = true;
            this.checkBoxDimLight.Location = new System.Drawing.Point(11, 153);
            this.checkBoxDimLight.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxDimLight.Name = "checkBoxDimLight";
            this.checkBoxDimLight.Size = new System.Drawing.Size(89, 21);
            this.checkBoxDimLight.TabIndex = 18;
            this.checkBoxDimLight.Text = "Dim Light";
            this.checkBoxDimLight.UseVisualStyleBackColor = true;
            this.checkBoxDimLight.CheckedChanged += new System.EventHandler(this.checkBoxDimLight_CheckedChanged);
            // 
            // labelBlue
            // 
            this.labelBlue.AutoSize = true;
            this.labelBlue.Location = new System.Drawing.Point(201, 89);
            this.labelBlue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelBlue.Name = "labelBlue";
            this.labelBlue.Size = new System.Drawing.Size(36, 17);
            this.labelBlue.TabIndex = 9;
            this.labelBlue.Text = "Blue";
            // 
            // labelGreen
            // 
            this.labelGreen.AutoSize = true;
            this.labelGreen.Location = new System.Drawing.Point(102, 88);
            this.labelGreen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelGreen.Name = "labelGreen";
            this.labelGreen.Size = new System.Drawing.Size(48, 17);
            this.labelGreen.TabIndex = 8;
            this.labelGreen.Text = "Green";
            // 
            // labelRed
            // 
            this.labelRed.AutoSize = true;
            this.labelRed.Location = new System.Drawing.Point(8, 89);
            this.labelRed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRed.Name = "labelRed";
            this.labelRed.Size = new System.Drawing.Size(34, 17);
            this.labelRed.TabIndex = 7;
            this.labelRed.Text = "Red";
            // 
            // textBoxBlue
            // 
            this.textBoxBlue.Location = new System.Drawing.Point(204, 111);
            this.textBoxBlue.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxBlue.Name = "textBoxBlue";
            this.textBoxBlue.Size = new System.Drawing.Size(52, 22);
            this.textBoxBlue.TabIndex = 15;
            this.textBoxBlue.Text = "255";
            // 
            // vScrollBarBlue
            // 
            this.vScrollBarBlue.Location = new System.Drawing.Point(261, 107);
            this.vScrollBarBlue.Maximum = 264;
            this.vScrollBarBlue.Name = "vScrollBarBlue";
            this.vScrollBarBlue.Size = new System.Drawing.Size(17, 30);
            this.vScrollBarBlue.TabIndex = 16;
            this.vScrollBarBlue.Value = 255;
            this.vScrollBarBlue.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrollBarBlue_Scroll);
            // 
            // textBoxGreen
            // 
            this.textBoxGreen.Location = new System.Drawing.Point(105, 109);
            this.textBoxGreen.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxGreen.Name = "textBoxGreen";
            this.textBoxGreen.Size = new System.Drawing.Size(52, 22);
            this.textBoxGreen.TabIndex = 13;
            this.textBoxGreen.Text = "255";
            // 
            // vScrollBarGreen
            // 
            this.vScrollBarGreen.Location = new System.Drawing.Point(163, 107);
            this.vScrollBarGreen.Maximum = 264;
            this.vScrollBarGreen.Name = "vScrollBarGreen";
            this.vScrollBarGreen.Size = new System.Drawing.Size(17, 30);
            this.vScrollBarGreen.TabIndex = 14;
            this.vScrollBarGreen.Value = 255;
            this.vScrollBarGreen.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrollBarGreen_Scroll);
            // 
            // checkBoxDisplayLight
            // 
            this.checkBoxDisplayLight.AutoSize = true;
            this.checkBoxDisplayLight.Location = new System.Drawing.Point(11, 10);
            this.checkBoxDisplayLight.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxDisplayLight.Name = "checkBoxDisplayLight";
            this.checkBoxDisplayLight.Size = new System.Drawing.Size(111, 21);
            this.checkBoxDisplayLight.TabIndex = 10;
            this.checkBoxDisplayLight.Text = "Display Light";
            this.checkBoxDisplayLight.UseVisualStyleBackColor = true;
            this.checkBoxDisplayLight.CheckedChanged += new System.EventHandler(this.checkBoxDisplayLight_CheckedChanged);
            // 
            // textBoxRed
            // 
            this.textBoxRed.Location = new System.Drawing.Point(11, 109);
            this.textBoxRed.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxRed.Name = "textBoxRed";
            this.textBoxRed.Size = new System.Drawing.Size(51, 22);
            this.textBoxRed.TabIndex = 11;
            this.textBoxRed.Text = "255";
            // 
            // vScrollBarRed
            // 
            this.vScrollBarRed.Location = new System.Drawing.Point(64, 106);
            this.vScrollBarRed.Maximum = 264;
            this.vScrollBarRed.Name = "vScrollBarRed";
            this.vScrollBarRed.Size = new System.Drawing.Size(17, 30);
            this.vScrollBarRed.TabIndex = 12;
            this.vScrollBarRed.Value = 255;
            this.vScrollBarRed.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrollBarRed_Scroll);
            // 
            // groupBoxNameDisplayLcd
            // 
            this.groupBoxNameDisplayLcd.Controls.Add(this.buttonIncUIDNp);
            this.groupBoxNameDisplayLcd.Controls.Add(this.buttonDecUIDNp);
            this.groupBoxNameDisplayLcd.Controls.Add(this.label4);
            this.groupBoxNameDisplayLcd.Controls.Add(this.buttonGetNdUID);
            this.groupBoxNameDisplayLcd.Controls.Add(this.buttonDisplayTextPxL1L2);
            this.groupBoxNameDisplayLcd.Controls.Add(this.label5);
            this.groupBoxNameDisplayLcd.Controls.Add(this.comboBoxFontsL2);
            this.groupBoxNameDisplayLcd.Controls.Add(this.textBoxNameStringL2);
            this.groupBoxNameDisplayLcd.Controls.Add(this.textBoxNdUid);
            this.groupBoxNameDisplayLcd.Controls.Add(this.buttonDisplayTextPxL1);
            this.groupBoxNameDisplayLcd.Controls.Add(this.label6);
            this.groupBoxNameDisplayLcd.Controls.Add(this.buttonDisplayTextDefault);
            this.groupBoxNameDisplayLcd.Controls.Add(this.comboBoxFontsL1);
            this.groupBoxNameDisplayLcd.Controls.Add(this.buttonTurnOnPixels);
            this.groupBoxNameDisplayLcd.Controls.Add(this.buttonWriteNdUID);
            this.groupBoxNameDisplayLcd.Controls.Add(this.buttonResetNameDisplay);
            this.groupBoxNameDisplayLcd.Controls.Add(this.buttonClearText);
            this.groupBoxNameDisplayLcd.Controls.Add(this.textBoxNameStringL1);
            this.groupBoxNameDisplayLcd.Location = new System.Drawing.Point(16, 518);
            this.groupBoxNameDisplayLcd.Name = "groupBoxNameDisplayLcd";
            this.groupBoxNameDisplayLcd.Size = new System.Drawing.Size(636, 322);
            this.groupBoxNameDisplayLcd.TabIndex = 40;
            this.groupBoxNameDisplayLcd.TabStop = false;
            this.groupBoxNameDisplayLcd.Text = "Nameplate Display";
            // 
            // buttonIncUIDNp
            // 
            this.buttonIncUIDNp.Location = new System.Drawing.Point(434, 239);
            this.buttonIncUIDNp.Margin = new System.Windows.Forms.Padding(4);
            this.buttonIncUIDNp.Name = "buttonIncUIDNp";
            this.buttonIncUIDNp.Size = new System.Drawing.Size(49, 39);
            this.buttonIncUIDNp.TabIndex = 53;
            this.buttonIncUIDNp.Text = "+";
            this.buttonIncUIDNp.UseVisualStyleBackColor = true;
            this.buttonIncUIDNp.Click += new System.EventHandler(this.buttonIncUIDNp_Click);
            // 
            // buttonDecUIDNp
            // 
            this.buttonDecUIDNp.Location = new System.Drawing.Point(8, 239);
            this.buttonDecUIDNp.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDecUIDNp.Name = "buttonDecUIDNp";
            this.buttonDecUIDNp.Size = new System.Drawing.Size(49, 39);
            this.buttonDecUIDNp.TabIndex = 52;
            this.buttonDecUIDNp.Text = "-";
            this.buttonDecUIDNp.UseVisualStyleBackColor = true;
            this.buttonDecUIDNp.Click += new System.EventHandler(this.buttonDecUIDNp_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 17);
            this.label4.TabIndex = 42;
            this.label4.Text = "UID";
            // 
            // buttonGetNdUID
            // 
            this.buttonGetNdUID.Enabled = false;
            this.buttonGetNdUID.Location = new System.Drawing.Point(491, 268);
            this.buttonGetNdUID.Margin = new System.Windows.Forms.Padding(4);
            this.buttonGetNdUID.Name = "buttonGetNdUID";
            this.buttonGetNdUID.Size = new System.Drawing.Size(136, 48);
            this.buttonGetNdUID.TabIndex = 51;
            this.buttonGetNdUID.Text = "Get UID";
            this.buttonGetNdUID.UseVisualStyleBackColor = true;
            this.buttonGetNdUID.Click += new System.EventHandler(this.buttonGetNdUID_Click);
            // 
            // buttonDisplayTextPxL1L2
            // 
            this.buttonDisplayTextPxL1L2.Location = new System.Drawing.Point(214, 181);
            this.buttonDisplayTextPxL1L2.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDisplayTextPxL1L2.Name = "buttonDisplayTextPxL1L2";
            this.buttonDisplayTextPxL1L2.Size = new System.Drawing.Size(106, 28);
            this.buttonDisplayTextPxL1L2.TabIndex = 32;
            this.buttonDisplayTextPxL1L2.Text = "Display L1L2";
            this.buttonDisplayTextPxL1L2.UseVisualStyleBackColor = true;
            this.buttonDisplayTextPxL1L2.Click += new System.EventHandler(this.buttonDisplayTextPxL1L2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 17);
            this.label5.TabIndex = 50;
            this.label5.Text = "Select Font (Line 2)";
            // 
            // comboBoxFontsL2
            // 
            this.comboBoxFontsL2.AllowDrop = true;
            this.comboBoxFontsL2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFontsL2.FormattingEnabled = true;
            this.comboBoxFontsL2.Items.AddRange(new object[] {
            "Calibri 8 Pt",
            "Calibri 9 Pt",
            "Calibri 10 Pt",
            "Calibri 12 Pt",
            "Calibri 16 Pt",
            "Calibri 18 Pt",
            "Calibri 20 Pt",
            "Calibri Bold 12 Pt",
            "Lucida Console 18 Pt",
            "Consolas 20 Pt",
            "Arial Narrow 20 Pt",
            "Times New Roman 6 Pt",
            "Times New Roman 8 Pt",
            "Times New Roman 16 Pt",
            "Times New Roman 18 Pt",
            "Times New Roman 20 Pt",
            "Century Gothic 8 Pt",
            "Century Gothic 18 Pt",
            "Century Gothic 20 Pt"});
            this.comboBoxFontsL2.Location = new System.Drawing.Point(6, 120);
            this.comboBoxFontsL2.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxFontsL2.Name = "comboBoxFontsL2";
            this.comboBoxFontsL2.Size = new System.Drawing.Size(621, 24);
            this.comboBoxFontsL2.TabIndex = 28;
            this.comboBoxFontsL2.SelectedIndexChanged += new System.EventHandler(this.comboBoxFontsL2_SelectedIndexChanged);
            // 
            // textBoxNameStringL2
            // 
            this.textBoxNameStringL2.Location = new System.Drawing.Point(6, 148);
            this.textBoxNameStringL2.Name = "textBoxNameStringL2";
            this.textBoxNameStringL2.Size = new System.Drawing.Size(621, 22);
            this.textBoxNameStringL2.TabIndex = 29;
            // 
            // textBoxNdUid
            // 
            this.textBoxNdUid.Location = new System.Drawing.Point(64, 248);
            this.textBoxNdUid.Name = "textBoxNdUid";
            this.textBoxNdUid.Size = new System.Drawing.Size(363, 22);
            this.textBoxNdUid.TabIndex = 34;
            // 
            // buttonDisplayTextPxL1
            // 
            this.buttonDisplayTextPxL1.Location = new System.Drawing.Point(113, 181);
            this.buttonDisplayTextPxL1.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDisplayTextPxL1.Name = "buttonDisplayTextPxL1";
            this.buttonDisplayTextPxL1.Size = new System.Drawing.Size(87, 28);
            this.buttonDisplayTextPxL1.TabIndex = 31;
            this.buttonDisplayTextPxL1.Text = "Display L1";
            this.buttonDisplayTextPxL1.UseVisualStyleBackColor = true;
            this.buttonDisplayTextPxL1.Click += new System.EventHandler(this.buttonDisplayTextPxL1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 17);
            this.label6.TabIndex = 47;
            this.label6.Text = "Select Font (Line 1)";
            // 
            // buttonDisplayTextDefault
            // 
            this.buttonDisplayTextDefault.Location = new System.Drawing.Point(7, 181);
            this.buttonDisplayTextDefault.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDisplayTextDefault.Name = "buttonDisplayTextDefault";
            this.buttonDisplayTextDefault.Size = new System.Drawing.Size(93, 28);
            this.buttonDisplayTextDefault.TabIndex = 30;
            this.buttonDisplayTextDefault.Text = "Display L1";
            this.buttonDisplayTextDefault.UseVisualStyleBackColor = true;
            this.buttonDisplayTextDefault.Click += new System.EventHandler(this.buttonDisplayTextDefault_Click);
            // 
            // comboBoxFontsL1
            // 
            this.comboBoxFontsL1.AllowDrop = true;
            this.comboBoxFontsL1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFontsL1.FormattingEnabled = true;
            this.comboBoxFontsL1.Items.AddRange(new object[] {
            "Calibri 8 Pt",
            "Calibri 9 Pt",
            "Calibri 10 Pt",
            "Calibri 12 Pt",
            "Calibri 16 Pt",
            "Calibri 18 Pt",
            "Calibri 20 Pt",
            "Calibri Bold 12 Pt",
            "Lucida Console 18 Pt",
            "Consolas 20 Pt",
            "Arial Narrow 20 Pt",
            "Times New Roman 6 Pt",
            "Times New Roman 8 Pt",
            "Times New Roman 16 Pt",
            "Times New Roman 18 Pt",
            "Times New Roman 20 Pt",
            "Century Gothic 8 Pt",
            "Century Gothic 18 Pt",
            "Century Gothic 20 Pt"});
            this.comboBoxFontsL1.Location = new System.Drawing.Point(6, 40);
            this.comboBoxFontsL1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxFontsL1.Name = "comboBoxFontsL1";
            this.comboBoxFontsL1.Size = new System.Drawing.Size(621, 24);
            this.comboBoxFontsL1.TabIndex = 26;
            this.comboBoxFontsL1.SelectedIndexChanged += new System.EventHandler(this.comboBoxFonts_SelectedIndexChanged);
            // 
            // buttonTurnOnPixels
            // 
            this.buttonTurnOnPixels.Location = new System.Drawing.Point(8, 287);
            this.buttonTurnOnPixels.Margin = new System.Windows.Forms.Padding(4);
            this.buttonTurnOnPixels.Name = "buttonTurnOnPixels";
            this.buttonTurnOnPixels.Size = new System.Drawing.Size(113, 28);
            this.buttonTurnOnPixels.TabIndex = 36;
            this.buttonTurnOnPixels.Text = "TurnOnPixels";
            this.buttonTurnOnPixels.UseVisualStyleBackColor = true;
            this.buttonTurnOnPixels.Click += new System.EventHandler(this.buttonTurnOnPixels_Click);
            // 
            // buttonWriteNdUID
            // 
            this.buttonWriteNdUID.Location = new System.Drawing.Point(491, 217);
            this.buttonWriteNdUID.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWriteNdUID.Name = "buttonWriteNdUID";
            this.buttonWriteNdUID.Size = new System.Drawing.Size(136, 48);
            this.buttonWriteNdUID.TabIndex = 35;
            this.buttonWriteNdUID.Text = "Write UID";
            this.buttonWriteNdUID.UseVisualStyleBackColor = true;
            this.buttonWriteNdUID.Click += new System.EventHandler(this.buttonWriteNdUID_Click);
            // 
            // buttonResetNameDisplay
            // 
            this.buttonResetNameDisplay.Location = new System.Drawing.Point(372, 286);
            this.buttonResetNameDisplay.Margin = new System.Windows.Forms.Padding(4);
            this.buttonResetNameDisplay.Name = "buttonResetNameDisplay";
            this.buttonResetNameDisplay.Size = new System.Drawing.Size(113, 28);
            this.buttonResetNameDisplay.TabIndex = 37;
            this.buttonResetNameDisplay.Text = "Reset";
            this.buttonResetNameDisplay.UseVisualStyleBackColor = true;
            this.buttonResetNameDisplay.Click += new System.EventHandler(this.buttonResetNameDisplay_Click);
            // 
            // buttonClearText
            // 
            this.buttonClearText.Location = new System.Drawing.Point(333, 181);
            this.buttonClearText.Margin = new System.Windows.Forms.Padding(4);
            this.buttonClearText.Name = "buttonClearText";
            this.buttonClearText.Size = new System.Drawing.Size(88, 28);
            this.buttonClearText.TabIndex = 33;
            this.buttonClearText.Text = "Clear";
            this.buttonClearText.UseVisualStyleBackColor = true;
            this.buttonClearText.Click += new System.EventHandler(this.buttonClearText_Click);
            // 
            // textBoxNameStringL1
            // 
            this.textBoxNameStringL1.Location = new System.Drawing.Point(6, 68);
            this.textBoxNameStringL1.Name = "textBoxNameStringL1";
            this.textBoxNameStringL1.Size = new System.Drawing.Size(621, 22);
            this.textBoxNameStringL1.TabIndex = 27;
            // 
            // Log
            // 
            this.Log.Controls.Add(this.buttonClearLog);
            this.Log.Controls.Add(this.textBoxLog);
            this.Log.Location = new System.Drawing.Point(659, 2);
            this.Log.Margin = new System.Windows.Forms.Padding(4);
            this.Log.Name = "Log";
            this.Log.Padding = new System.Windows.Forms.Padding(4);
            this.Log.Size = new System.Drawing.Size(505, 841);
            this.Log.TabIndex = 33;
            this.Log.TabStop = false;
            this.Log.Text = "Log (Device UID)";
            // 
            // buttonClearLog
            // 
            this.buttonClearLog.Location = new System.Drawing.Point(383, 789);
            this.buttonClearLog.Margin = new System.Windows.Forms.Padding(4);
            this.buttonClearLog.Name = "buttonClearLog";
            this.buttonClearLog.Size = new System.Drawing.Size(113, 28);
            this.buttonClearLog.TabIndex = 38;
            this.buttonClearLog.Text = "Clear Log";
            this.buttonClearLog.UseVisualStyleBackColor = true;
            this.buttonClearLog.Click += new System.EventHandler(this.buttonClearLog_Click);
            // 
            // textBoxLog
            // 
            this.textBoxLog.Location = new System.Drawing.Point(9, 18);
            this.textBoxLog.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxLog.Multiline = true;
            this.textBoxLog.Name = "textBoxLog";
            this.textBoxLog.ReadOnly = true;
            this.textBoxLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxLog.Size = new System.Drawing.Size(487, 675);
            this.textBoxLog.TabIndex = 0;
            // 
            // checkBoxPulsate
            // 
            this.checkBoxPulsate.AutoSize = true;
            this.checkBoxPulsate.Location = new System.Drawing.Point(406, 109);
            this.checkBoxPulsate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxPulsate.Name = "checkBoxPulsate";
            this.checkBoxPulsate.Size = new System.Drawing.Size(77, 21);
            this.checkBoxPulsate.TabIndex = 37;
            this.checkBoxPulsate.Text = "Pulsate";
            this.checkBoxPulsate.UseVisualStyleBackColor = true;
            this.checkBoxPulsate.CheckedChanged += new System.EventHandler(this.checkBoxPulsate_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1176, 850);
            this.Controls.Add(this.Log);
            this.Controls.Add(this.groupBoxNameDisplayLcd);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBoxNewDeviceControls);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Blync Light Test Software";
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.groupBoxNewDeviceControls.ResumeLayout(false);
            this.groupBoxUID.ResumeLayout(false);
            this.groupBoxUID.PerformLayout();
            this.groupBoxMusicControls.ResumeLayout(false);
            this.groupBoxMusicControls.PerformLayout();
            this.groupBoxLightControls.ResumeLayout(false);
            this.groupBoxLightControls.PerformLayout();
            this.groupBoxNameDisplayLcd.ResumeLayout(false);
            this.groupBoxNameDisplayLcd.PerformLayout();
            this.Log.ResumeLayout(false);
            this.Log.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonUpdateDevList;
        private System.Windows.Forms.ComboBox comboBoxDeviceList;
        private System.Windows.Forms.CheckBox checkBoxPlayMusic;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxMusicList;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.CheckBox checkBoxRepeatMusic;
        private System.Windows.Forms.GroupBox groupBoxNewDeviceControls;
        private System.Windows.Forms.GroupBox groupBoxMusicControls;
        private System.Windows.Forms.GroupBox Log;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button buttonClearLog;
        private System.Windows.Forms.TextBox textBoxLog;
        private System.Windows.Forms.GroupBox groupBoxNameDisplayLcd;
        private System.Windows.Forms.Button buttonClearText;
        private System.Windows.Forms.TextBox textBoxNameStringL1;
        private System.Windows.Forms.Button buttonDisplayTextPxL1;
        private System.Windows.Forms.Button buttonResetNameDisplay;
        private System.Windows.Forms.Button buttonWriteNdUID;
        private System.Windows.Forms.TextBox textBoxNdUid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonTurnOnPixels;
        private System.Windows.Forms.ComboBox comboBoxFontsL1;
        private System.Windows.Forms.Button buttonDisplayTextDefault;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxFontsL2;
        private System.Windows.Forms.TextBox textBoxNameStringL2;
        private System.Windows.Forms.Button buttonDisplayTextPxL1L2;
        private System.Windows.Forms.Button buttonGetNdUID;
        private System.Windows.Forms.GroupBox groupBoxUID;
        private System.Windows.Forms.Button buttonIncUID;
        private System.Windows.Forms.Button buttonDecUID;
        private System.Windows.Forms.Button buttonWriteUid;
        private System.Windows.Forms.TextBox textBoxUid;
        private System.Windows.Forms.Button buttonGetUid;
        private System.Windows.Forms.GroupBox groupBoxLightControls;
        private System.Windows.Forms.Button buttonGreen1;
        private System.Windows.Forms.Button buttonSetRgbValues;
        private System.Windows.Forms.ComboBox comboBoxFlashSpeedList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBoxFlashLight;
        private System.Windows.Forms.CheckBox checkBoxDimLight;
        private System.Windows.Forms.Label labelBlue;
        private System.Windows.Forms.Label labelGreen;
        private System.Windows.Forms.Label labelRed;
        private System.Windows.Forms.TextBox textBoxBlue;
        private System.Windows.Forms.VScrollBar vScrollBarBlue;
        private System.Windows.Forms.TextBox textBoxGreen;
        private System.Windows.Forms.VScrollBar vScrollBarGreen;
        private System.Windows.Forms.CheckBox checkBoxDisplayLight;
        private System.Windows.Forms.TextBox textBoxRed;
        private System.Windows.Forms.VScrollBar vScrollBarRed;
        private System.Windows.Forms.Button buttonRed1;
        private System.Windows.Forms.Button buttonBlue1;
        private System.Windows.Forms.Button buttonWhite1;
        private System.Windows.Forms.Button buttonIncUIDNp;
        private System.Windows.Forms.Button buttonDecUIDNp;
        private System.Windows.Forms.Button buttonOrange;
        private System.Windows.Forms.Button buttonYellow1;
        private System.Windows.Forms.Button buttonPurple;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBoxMute;
        private System.Windows.Forms.CheckBox checkBoxPulsate;
    }
}

