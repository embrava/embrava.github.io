/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[35];
    char stringdata0[821];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 25), // "on_cbDeviceList_activated"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 5), // "index"
QT_MOC_LITERAL(4, 44, 25), // "SearchAndListBlyncDevices"
QT_MOC_LITERAL(5, 70, 7), // "CleanUp"
QT_MOC_LITERAL(6, 78, 36), // "EnableUIComponentsForBlyncUsb..."
QT_MOC_LITERAL(7, 115, 37), // "DisableUIComponentsForBlyncUs..."
QT_MOC_LITERAL(8, 153, 40), // "EnableUIComponentsForBlyncUsb..."
QT_MOC_LITERAL(9, 194, 41), // "DisableUIComponentsForBlyncUs..."
QT_MOC_LITERAL(10, 236, 29), // "on_pbUpdateDeviceList_clicked"
QT_MOC_LITERAL(11, 266, 16), // "on_pbRed_clicked"
QT_MOC_LITERAL(12, 283, 18), // "on_pbGreen_clicked"
QT_MOC_LITERAL(13, 302, 17), // "on_pbBlue_clicked"
QT_MOC_LITERAL(14, 320, 20), // "on_pbMagenta_clicked"
QT_MOC_LITERAL(15, 341, 17), // "on_pbCyan_clicked"
QT_MOC_LITERAL(16, 359, 19), // "on_pbYellow_clicked"
QT_MOC_LITERAL(17, 379, 18), // "on_pbWhite_clicked"
QT_MOC_LITERAL(18, 398, 18), // "on_pbReset_clicked"
QT_MOC_LITERAL(19, 417, 36), // "on_checkBoxDisplayLight_state..."
QT_MOC_LITERAL(20, 454, 4), // "arg1"
QT_MOC_LITERAL(21, 459, 35), // "on_cbDeviceList_currentIndexC..."
QT_MOC_LITERAL(22, 495, 22), // "on_pbSetColors_clicked"
QT_MOC_LITERAL(23, 518, 32), // "on_checkBoxDimLight_stateChanged"
QT_MOC_LITERAL(24, 551, 34), // "on_checkBoxFlashLight_stateCh..."
QT_MOC_LITERAL(25, 586, 33), // "on_checkBoxPlayMusic_stateCha..."
QT_MOC_LITERAL(26, 620, 34), // "on_cbMusicList_currentIndexCh..."
QT_MOC_LITERAL(27, 655, 35), // "on_cbFlashSpeed_currentIndexC..."
QT_MOC_LITERAL(28, 691, 23), // "on_hsVolume_sliderMoved"
QT_MOC_LITERAL(29, 715, 8), // "position"
QT_MOC_LITERAL(30, 724, 32), // "on_checkBoxRptMusic_stateChanged"
QT_MOC_LITERAL(31, 757, 19), // "on_pbGetUid_clicked"
QT_MOC_LITERAL(32, 777, 12), // "SetRgbValues"
QT_MOC_LITERAL(33, 790, 24), // "on_hsVolume_valueChanged"
QT_MOC_LITERAL(34, 815, 5) // "value"

    },
    "MainWindow\0on_cbDeviceList_activated\0"
    "\0index\0SearchAndListBlyncDevices\0"
    "CleanUp\0EnableUIComponentsForBlyncUsbDevices\0"
    "DisableUIComponentsForBlyncUsbDevices\0"
    "EnableUIComponentsForBlyncUsb1020Devices\0"
    "DisableUIComponentsForBlyncUsb1020Devices\0"
    "on_pbUpdateDeviceList_clicked\0"
    "on_pbRed_clicked\0on_pbGreen_clicked\0"
    "on_pbBlue_clicked\0on_pbMagenta_clicked\0"
    "on_pbCyan_clicked\0on_pbYellow_clicked\0"
    "on_pbWhite_clicked\0on_pbReset_clicked\0"
    "on_checkBoxDisplayLight_stateChanged\0"
    "arg1\0on_cbDeviceList_currentIndexChanged\0"
    "on_pbSetColors_clicked\0"
    "on_checkBoxDimLight_stateChanged\0"
    "on_checkBoxFlashLight_stateChanged\0"
    "on_checkBoxPlayMusic_stateChanged\0"
    "on_cbMusicList_currentIndexChanged\0"
    "on_cbFlashSpeed_currentIndexChanged\0"
    "on_hsVolume_sliderMoved\0position\0"
    "on_checkBoxRptMusic_stateChanged\0"
    "on_pbGetUid_clicked\0SetRgbValues\0"
    "on_hsVolume_valueChanged\0value"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      29,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  159,    2, 0x08 /* Private */,
       4,    0,  162,    2, 0x08 /* Private */,
       5,    0,  163,    2, 0x08 /* Private */,
       6,    0,  164,    2, 0x08 /* Private */,
       7,    0,  165,    2, 0x08 /* Private */,
       8,    0,  166,    2, 0x08 /* Private */,
       9,    0,  167,    2, 0x08 /* Private */,
      10,    0,  168,    2, 0x08 /* Private */,
      11,    0,  169,    2, 0x08 /* Private */,
      12,    0,  170,    2, 0x08 /* Private */,
      13,    0,  171,    2, 0x08 /* Private */,
      14,    0,  172,    2, 0x08 /* Private */,
      15,    0,  173,    2, 0x08 /* Private */,
      16,    0,  174,    2, 0x08 /* Private */,
      17,    0,  175,    2, 0x08 /* Private */,
      18,    0,  176,    2, 0x08 /* Private */,
      19,    1,  177,    2, 0x08 /* Private */,
      21,    1,  180,    2, 0x08 /* Private */,
      22,    0,  183,    2, 0x08 /* Private */,
      23,    1,  184,    2, 0x08 /* Private */,
      24,    1,  187,    2, 0x08 /* Private */,
      25,    1,  190,    2, 0x08 /* Private */,
      26,    1,  193,    2, 0x08 /* Private */,
      27,    1,  196,    2, 0x08 /* Private */,
      28,    1,  199,    2, 0x08 /* Private */,
      30,    1,  202,    2, 0x08 /* Private */,
      31,    0,  205,    2, 0x08 /* Private */,
      32,    0,  206,    2, 0x08 /* Private */,
      33,    1,  207,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,   29,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   34,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_cbDeviceList_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->SearchAndListBlyncDevices(); break;
        case 2: _t->CleanUp(); break;
        case 3: _t->EnableUIComponentsForBlyncUsbDevices(); break;
        case 4: _t->DisableUIComponentsForBlyncUsbDevices(); break;
        case 5: _t->EnableUIComponentsForBlyncUsb1020Devices(); break;
        case 6: _t->DisableUIComponentsForBlyncUsb1020Devices(); break;
        case 7: _t->on_pbUpdateDeviceList_clicked(); break;
        case 8: _t->on_pbRed_clicked(); break;
        case 9: _t->on_pbGreen_clicked(); break;
        case 10: _t->on_pbBlue_clicked(); break;
        case 11: _t->on_pbMagenta_clicked(); break;
        case 12: _t->on_pbCyan_clicked(); break;
        case 13: _t->on_pbYellow_clicked(); break;
        case 14: _t->on_pbWhite_clicked(); break;
        case 15: _t->on_pbReset_clicked(); break;
        case 16: _t->on_checkBoxDisplayLight_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_cbDeviceList_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->on_pbSetColors_clicked(); break;
        case 19: _t->on_checkBoxDimLight_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->on_checkBoxFlashLight_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->on_checkBoxPlayMusic_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->on_cbMusicList_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->on_cbFlashSpeed_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 24: _t->on_hsVolume_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 25: _t->on_checkBoxRptMusic_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 26: _t->on_pbGetUid_clicked(); break;
        case 27: _t->SetRgbValues(); break;
        case 28: _t->on_hsVolume_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 29)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 29;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
