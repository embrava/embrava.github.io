﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Blynclight;
using System.Threading;
using System.Runtime.InteropServices;
using System.IO;

namespace BlyncLightTest
{
    public partial class Form1 : Form
    {
        // Create object for the base class BlynclightController
        internal BlynclightController oBlynclightController = new BlynclightController();

        private int nNumberOfBlyncDevices = 0;
        private int nSelectedDeviceIndex = 0;

        internal const byte DEVICETYPE_NODEVICE_INVALIDDEVICE_TYPE = 0x00;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_TENX_10 = 0x01;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_TENX_20 = 0x02;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V30 = 0x03;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V30S = 0x04;
        internal const byte DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 = 0x05;
        internal const byte DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S = 0x06;
        internal const byte DEVICETYPE_BLYNC_MINI_CHIPSET_V30S = 0x07;
        internal const byte DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 = 0x08;
        internal const byte DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA = 0x09;
        internal const byte DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 = 0x0A;
        internal const byte DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220 = 0x0B;
        internal const byte DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 = 0x0C;
        internal const byte DEVICETYPE_BLYNC_MINI_CHIPSET_V40S = 13;
        internal const byte DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S = 14;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V40 = 15;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V40S = 16;
        internal const byte DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE = 17;
        internal const byte DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR = 21;
        internal const byte DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 = 22; // version 2.0 - BrightTrend devices
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 = 23;
        internal const byte DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 = 24;

        private byte bySelectedMusic = 1;
        private byte bySelectedFlashSpeed = 1;
        private byte byVolumeLevel = 5;

        private string[] arrMusicListForBlyncUSB30S = { 
                                                          "Music 1", "Music 2", "Music 3", "Music 4", "Music 5", 
                                                          "Music 6", "Music 7", "Music 8", "Music 9", "Music 10"
                                                      };
        
        private string[] arrMusicListForBlyncMiniWireless = { 
                                                                "Music 1", "Music 2", "Music 3", "Music 4", "Music 5", 
                                                                "Music 6", "Music 7", "Music 8", "Music 9", "Music 10", 
                                                                "Music 11", "Music 12", "Music 13", "Music 14"
                                                            };

        private string[] arrFlashSpeed1 = {
                                            "Slow", "Medium", "Fast"
                                            };

        private string[] arrFlashSpeed2 = {
                                            "Slow", "Medium", "Fast", "Pulsating"
                                            };

        /*private bool bLumenaBluetoothDeviceNotificationInterfaceAvailable = false;
        private Thread[] threadReadInputReport = new Thread[10];
        private ThreadProc[] aoThreadProc= ThreadProc.NewInitArray(10);
        // private int nNumberOfLumenaBluetoothHeadsetDevices = 0;*/

        internal const UInt32 ERROR_IO_PENDING = 997;
        internal const UInt32 INFINITE = 0xFFFFFFFF;
        internal const UInt32 WAIT_ABANDONED = 0x00000080;
        internal const UInt32 WAIT_OBJECT_0 = 0x00000000;
        internal const UInt32 WAIT_TIMEOUT = 0x00000102;

        // Logging support
        private bool bloggingEnabled = false;
        private String strUserAppDir = "";
        private String strUserBlynclightTestDir = "";
        private String strLogFile = "";

        public Form1()
        {
            InitializeComponent();

            if (bloggingEnabled == true)
            {
                InitLogging(true);
                oBlynclightController.InitLogging();
            }

            WriteToLog("Main form Initializing");

            // Form_Closing event while exiting the application
            this.Closing += Form1_Closing;

            comboBoxFlashSpeedList.Items.AddRange(arrFlashSpeed1);

            Byte bySelectedFlashSpeed = 0x04;
            Byte byLightControl = 0x00;
            
            byLightControl |= (Byte)((bySelectedFlashSpeed & 0x0F) << 3);

            //DisableUIComponentsForBlyncUsb1020Devices();
            DisableUIComponentsForBlyncUsb30Devices();

            SearchAndListBlyncDevices();

            //comboBoxMusicList.SelectedIndex = 0;
            comboBoxFlashSpeedList.SelectedIndex = 0;
            comboBoxFontsL1.SelectedIndex = 0;
        }

        private void InitLogging(bool bDeleteExistingLogFile)
        {
            if (bloggingEnabled == false)
            {
                return;
            }

            strUserAppDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            strUserBlynclightTestDir = strUserAppDir + "\\BlynclightTest";

            try
            {
                // If the directory doesn't exist, create it.
                if (!Directory.Exists(strUserBlynclightTestDir))
                {
                    Directory.CreateDirectory(strUserBlynclightTestDir);
                }

                strLogFile = strUserBlynclightTestDir + "\\dbglog_blynclighttest.txt";

                if (bDeleteExistingLogFile == true)
                {
                    if (File.Exists(strLogFile))
                    {
                        File.Delete(strLogFile);
                    }
                }


                // if the file doen't exist, create it.
                if (!File.Exists(strLogFile))
                {
                    File.Create(strLogFile).Close();
                    File.AppendAllText(strLogFile, "Debug Log written by BlynclightTest software:");
                    File.AppendAllText(strLogFile, Environment.NewLine);
                }
            }
            catch (Exception ex)
            {

            }
        }

        internal void WriteToLog(String logText)
        {
            if (bloggingEnabled == false)
            {
                return;
            }

            try
            {
                InitLogging(false);

                File.AppendAllText(strLogFile, DateTime.Now.ToString("HH:mm:ss.fff", System.Globalization.DateTimeFormatInfo.InvariantInfo) + "    ");
                File.AppendAllText(strLogFile, logText);
                File.AppendAllText(strLogFile, Environment.NewLine);
            }
            catch (Exception ex)
            {

            }
        }

        private void SearchAndListBlyncDevices()
        {
            WriteToLog("SearchAndListBlyncDevices Entry");

            int nCbIndex = 0;

            // If there is already a list of devices, free the list of device and resources allocated
            comboBoxDeviceList.Items.Clear();

            // Look for the Blync devices connected to the System
            // the nNumberOfBlyncDevices will be equal to the number 
            // of Blync devices connected to the System USB Ports

            //bLumenaBluetoothDeviceNotificationInterfaceAvailable = false;
            //nNumberOfLumenaBluetoothHeadsetDevices = 0;

            CleanUp();

            WriteToLog("Searching for Blynclight devices");

            nNumberOfBlyncDevices = oBlynclightController.InitBlyncDevices();

            if (nNumberOfBlyncDevices > 0)
            {
                WriteToLog("Listing Blynclight devices");

                WriteToLog("Number of Blynclight devices: " + nNumberOfBlyncDevices);

                // Add the Blync devices detected to the combobox
                for (int i = 0; i < nNumberOfBlyncDevices; i++)
                {
                    comboBoxDeviceList.Items.Insert(i, oBlynclightController.aoDevInfo[i].szDeviceName);

                    if (oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_TENX_10 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_TENX_20)
                    {
                        //comboBoxDeviceList.Items.Insert(nCbIndex, oBlynclightController.aoDevInfo[i].szDeviceName);
                        //nCbIndex++;

                        //EnableUIComponentsForBlyncUsb1020Devices();
                        //DisableUIComponentsForBlyncUsb30Devices();
                    }
                    else if (oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
                    {
                        //comboBoxDeviceList.Items.Insert(nCbIndex, oBlynclightController.aoDevInfo[i].szDeviceName);
                        //nCbIndex++;

                        EnableUIComponentsForBlyncUsb30Devices();
                        //DisableUIComponentsForBlyncUsb1020Devices();
                    }
                    /*else if (oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210_NOTIFICATIONINTERFACE ||
                    oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220_NOTIFICATIONINTERFACE)
                    {
                        DisableUIComponentsForBlyncUsb1020Devices();
                        DisableUIComponentsForBlyncUsb30Devices();
                    }*/
                }

                comboBoxDeviceList.SelectedIndex = 0;
                nSelectedDeviceIndex = 0;

                /*// Check for the availability of Lumena 210/220 Bluetooth Headset devices
                for (int i = 0; i < nNumberOfBlyncDevices; i++)
                {
                    if (oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                        oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
                    {
                        bLumenaBluetoothDeviceNotificationInterfaceAvailable = true;
                        //nNumberOfLumenaBluetoothHeadsetDevices++;
                    }
                }

                // If Lumena 210/220 Bluetooth Headset devices are available start the thread that receives the input report from the 
                // devices for the following notifications - IsOnCall, AnsweredCall, EndCall

                if (bLumenaBluetoothDeviceNotificationInterfaceAvailable == true)
                {
                    WriteToLog("Lumena Bluetooth Headset Device Notification Interfaces detected");

                    for (int i = 0; i < nNumberOfBlyncDevices; i++)
                    {
                        if (oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 || 
                            oBlynclightController.aoDevInfo[i].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
                        {
                            try
                            {
                                aoThreadProc[i].nIndex = i;
                                // aoThreadProc[i].form1 = this;
                                threadReadInputReport[i] = new Thread(new ThreadStart(aoThreadProc[i].ReadInputReportThreadProc));
                                threadReadInputReport[i].Priority = ThreadPriority.Normal;
                                // bExitFromReadThread = false;
                                threadReadInputReport[i].Start();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Exception: " + ex.Message, "BlynclightTest",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                            }
                        }
                    }
                }*/
            }
            else
            {
                MessageBox.Show("No Blync Devices Detected", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                // If device is not present disable all UI components
                //DisableUIComponentsForBlyncUsb1020Devices();
                DisableUIComponentsForBlyncUsb30Devices();
            }

            WriteToLog("SearchAndListBlyncDevices Exit");
        }

        /*private void EnableUIComponentsForBlyncUsb1020Devices()
        {
            WriteToLog("EnableUIComponentsForBlyncUsb1020Devices Entry");

            groupBoxOldDeviceControls.Enabled = true;

            WriteToLog("EnableUIComponentsForBlyncUsb1020Devices Exit");
        }

        private void DisableUIComponentsForBlyncUsb1020Devices()
        {
            WriteToLog("DisableUIComponentsForBlyncUsb1020Devices Entry");

            groupBoxOldDeviceControls.Enabled = false;

            WriteToLog("DisableUIComponentsForBlyncUsb1020Devices Exit");
        }
        */
        private void EnableUIComponentsForBlyncUsb30Devices()
        {
            WriteToLog("EnableUIComponentsForBlyncUsb30Devices Entry");

            groupBoxNameDisplayLcd.Enabled = false;

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20)
            {
                groupBoxLightControls.Enabled = true;
                groupBoxMusicControls.Enabled = true;
            }
            else if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
            {
                groupBoxLightControls.Enabled = true;
                groupBoxMusicControls.Enabled = false;
            }

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20)
            {
                buttonGetUid.Enabled = true;
            }
            else
            {
                buttonGetUid.Enabled = true;
            }

            buttonGetNdUID.Enabled = false;
            
            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE)
            {
                groupBoxNameDisplayLcd.Enabled = true;

                buttonGetUid.Enabled = false;

                buttonGetNdUID.Enabled = true;
            }

            WriteToLog("EnableUIComponentsForBlyncUsb30Devices Exit");
        }

        private void DisableUIComponentsForBlyncUsb30Devices()
        {
            WriteToLog("DisableUIComponentsForBlyncUsb30Devices Entry");

            groupBoxLightControls.Enabled = false;
            groupBoxMusicControls.Enabled = false;

            groupBoxNameDisplayLcd.Enabled = false;

            WriteToLog("DisableUIComponentsForBlyncUsb30Devices Exit");
        } 

        private void comboBoxDeviceList_SelectedIndexChanged(object sender, EventArgs e)
        {
            WriteToLog("comboBoxDeviceList_SelectedIndexChanged Entry");

            /*if (comboBoxDeviceList.SelectedIndex >= 0)
            {
                nSelectedDeviceIndex = oBlynclightController.aoDevInfo[comboBoxDeviceList.SelectedIndex].nDeviceIndex;
            }*/

            nSelectedDeviceIndex = comboBoxDeviceList.SelectedIndex;

            if (nSelectedDeviceIndex >= 0)
            {
                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_TENX_10 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_TENX_20)
                {
                    //EnableUIComponentsForBlyncUsb1020Devices();
                    //DisableUIComponentsForBlyncUsb30Devices();
                }
                else if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
                {
                    EnableUIComponentsForBlyncUsb30Devices();
                    //DisableUIComponentsForBlyncUsb1020Devices();

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 || 
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20)
                    {
                        comboBoxFlashSpeedList.Items.Clear();
                        comboBoxFlashSpeedList.Items.AddRange(arrFlashSpeed2);
                        comboBoxFlashSpeedList.SelectedIndex = 0;
                    }
                    else
                    {
                        comboBoxFlashSpeedList.Items.Clear();
                        comboBoxFlashSpeedList.Items.AddRange(arrFlashSpeed1);
                        comboBoxFlashSpeedList.SelectedIndex = 0;
                    }

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR)
                    {
                        if (comboBoxMusicList.Items.Count > 0)
                        {
                            comboBoxMusicList.Items.Clear();                            
                        }

                        for (int j = 0; j < arrMusicListForBlyncUSB30S.Length; j++)
                        {
                            comboBoxMusicList.Items.Insert(j, arrMusicListForBlyncUSB30S[j]);
                        }

                        comboBoxMusicList.SelectedIndex = 0;
                    }
                    else if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        if (comboBoxMusicList.Items.Count > 0)
                        {
                            comboBoxMusicList.Items.Clear();
                        }

                        for (int j = 0; j < arrMusicListForBlyncMiniWireless.Length; j++)
                        {
                            comboBoxMusicList.Items.Insert(j, arrMusicListForBlyncMiniWireless[j]);
                        }

                        comboBoxMusicList.SelectedIndex = 0;
                    }
                }
            }

            WriteToLog("comboBoxDeviceList_SelectedIndexChanged Exit");
        }

        private void buttonRed_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonRed_Click Entry");
            // Call TurnOnRedLight and pass the nSelectedDeviceIndex.
            // nSelectedDeviceIndex value will be updated on device selection in the Combo box

            bool bResult = false;
            bResult = oBlynclightController.TurnOnRedLight(nSelectedDeviceIndex);

            WriteToLog("buttonRed_Click Exit");
        }

        private void buttonBlue_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonBlue_Click Entry");
            oBlynclightController.TurnOnBlueLight(nSelectedDeviceIndex);
            WriteToLog("buttonBlue_Click Exit");
        }

        private void buttonMagenta_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonMagenta_Click Entry");
            oBlynclightController.TurnOnMagentaLight(nSelectedDeviceIndex);
            WriteToLog("buttonMagenta_Click Exit");
        }

        private void buttonCyan_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonCyan_Click Entry");
            oBlynclightController.TurnOnCyanLight(nSelectedDeviceIndex);
            WriteToLog("buttonCyan_Click Exit");
        }

        private void buttonGreen_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonGreen_Click Entry");
            oBlynclightController.TurnOnGreenLight(nSelectedDeviceIndex);
            WriteToLog("buttonGreen_Click Exit");
        }

        private void buttonYellow_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonYellow_Click Entry");
            oBlynclightController.TurnOnYellowLight(nSelectedDeviceIndex);
            WriteToLog("buttonYellow_Click Exit");
        }

        private void buttonWhite_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonWhite_Click Entry");
            oBlynclightController.TurnOnWhiteLight(nSelectedDeviceIndex);
            WriteToLog("buttonWhite_Click Exit");
        }

        private void buttonResetEffects_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonResetEffects_Click Entry");
            oBlynclightController.ResetLight(nSelectedDeviceIndex);
            WriteToLog("buttonWhite_Click Exit");
        }

        private void buttonUpdateDevList_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonUpdateDevList_Click Entry");

            SearchAndListBlyncDevices();

            String nameString = "ABCDEFGHI";

            Byte[] abyCommandBuffer = new Byte[64];

            for (int i = 0; i < abyCommandBuffer.Length; i++)
            {
                abyCommandBuffer[i] = 0;
            }

            if (String.IsNullOrEmpty(nameString) == true)
            {
                return;
            }

            byte[] nameStringAscii = null;

            try
            {
                nameStringAscii = ASCIIEncoding.ASCII.GetBytes(nameString);
            }
            catch (Exception ex)
            {
                return;
            }

            if (nameStringAscii == null)
            {
                return;
            }

            if (nameStringAscii.Length == 0)
            {
                return;
            }

            byte byNameStringLength = (Byte)nameStringAscii.Length;

            if (byNameStringLength > 29)
            {
                byNameStringLength = 29;
            }

            abyCommandBuffer[0] = (Byte)(nameStringAscii.Length + 3);

            abyCommandBuffer[1] = 0x3C;
            abyCommandBuffer[2] = 0x01;

            Array.Copy(nameStringAscii, 0, abyCommandBuffer, 3, byNameStringLength);

            abyCommandBuffer[(byNameStringLength + 3)] = 0x3E;

            WriteToLog("buttonUpdateDevList_Click Exit");
        }

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            WriteToLog("Form1_Closing Entry");

            if (nNumberOfBlyncDevices > 0)
            {
                for (int i = 0; i < nNumberOfBlyncDevices; i++)
                {
                    oBlynclightController.ResetLight(i);

                    byte byDetectedDeviceType = oBlynclightController.aoDevInfo[i].byDeviceType;

                    // Clear Music
                    if (byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        oBlynclightController.StopMusicPlay(i);
                        oBlynclightController.ClearMusicRepeat(i);
                        oBlynclightController.SetVolumeMute(i);
                    }

                    // Clear light
                    if (byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 || 
                        byDetectedDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                        byDetectedDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220)
                    {
                        oBlynclightController.StopLightFlash(i);
                        oBlynclightController.ClearLightDim(i);
                        oBlynclightController.ResetLight(i);
                    }
                }

                CleanUp();
            }

            WriteToLog("Form1_Closing Exit");
        }

        private void checkBoxDisplayLight_CheckedChanged(object sender, EventArgs e)
        {
            WriteToLog("checkBoxDisplayLight_CheckedChanged Entry");

            bool bDisplayLight = checkBoxDisplayLight.Checked;
            bool bResult = false;

            // Select turn on or off light based on check box value
            if (bDisplayLight == true)
            {
                // Send the RGB color values
                SetRgbValues();
            }
            else
            {
                bResult = oBlynclightController.ResetLight(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("TurnOffLight failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }

            WriteToLog("checkBoxDisplayLight_CheckedChanged Exit");
        }

        private void checkBoxPlayMusic_CheckedChanged(object sender, EventArgs e)
        {
            WriteToLog("checkBoxPlayMusic_CheckedChanged Entry");

            bool bPlayMusic = checkBoxPlayMusic.Checked;
            bool bResult = false;
            byVolumeLevel = (Byte)trackBar1.Value;
            
            bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
            {
                Thread.Sleep(250);
            }            

            bResult = oBlynclightController.SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
            {
                Thread.Sleep(250);
            }

            bResult = oBlynclightController.SetMusicVolume(nSelectedDeviceIndex, byVolumeLevel);

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
            {
                Thread.Sleep(250);
            }

            if (bPlayMusic == true)
            {
                if (checkBoxRepeatMusic.Checked == true)
                {
                    bResult = oBlynclightController.SetMusicRepeat(nSelectedDeviceIndex);
                }
                else
                {
                    //bResult = oBlynclightController.ClearMusicRepeat(nSelectedDeviceIndex);
                }

                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                {
                    Thread.Sleep(500);
                }

                bResult = oBlynclightController.StartMusicPlay(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("StartMusicPlay failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }

                //Thread.Sleep(100);

                /*bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("StopMusicPlay failed", "Information",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }*/
            }
            else
            {
                bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("StopMusicPlay failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }

            WriteToLog("checkBoxPlayMusic_CheckedChanged Exit");
        }

        private void checkBoxDimLight_CheckedChanged(object sender, EventArgs e)
        {
            WriteToLog("checkBoxDimLight_CheckedChanged Entry");

            bool bDimLight = checkBoxDimLight.Checked;
            bool bResult = false;

            if (bDimLight == true)
            {
                bResult = oBlynclightController.SetLightDim(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("SetLightDim failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }
            else
            {
                bResult = oBlynclightController.ClearLightDim(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("ClearLightDim failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }

            WriteToLog("checkBoxDimLight_CheckedChanged Exit");
        }

        private void checkBoxFlashLight_CheckedChanged(object sender, EventArgs e)
        {
            WriteToLog("checkBoxFlashLight_CheckedChanged Entry");

            bool bFlashLight = checkBoxFlashLight.Checked;
            bool bResult = false;

            if (bFlashLight == true)
            {
                bResult = oBlynclightController.StartLightFlash(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("StartLightFlash failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }
            else
            {
                bResult = oBlynclightController.StopLightFlash(nSelectedDeviceIndex);
                if (bResult == false)
                {
                    MessageBox.Show("StopLightFlash failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }

            // Select light flash speed
            bResult = oBlynclightController.SelectLightFlashSpeed(nSelectedDeviceIndex, bySelectedFlashSpeed);
            if (bResult == false)
            {
                MessageBox.Show("SelectLightFlashSpeed failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }

            WriteToLog("checkBoxFlashLight_CheckedChanged Exit");
        }

        private void checkBoxRepeatMusic_CheckedChanged(object sender, EventArgs e)
        {
            WriteToLog("checkBoxRepeatMusic_CheckedChanged Entry");

            bool bRepeatMusic = checkBoxRepeatMusic.Checked;
            bool bResult = false;

            if (bRepeatMusic == true)
            {
                if (checkBoxPlayMusic.Checked == true)
                {
                    bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);

                    bResult = oBlynclightController.SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        Thread.Sleep(250);
                    }

                    bResult = oBlynclightController.SetMusicVolume(nSelectedDeviceIndex, byVolumeLevel);

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        Thread.Sleep(250);
                    }

                    bResult = oBlynclightController.SetMusicRepeat(nSelectedDeviceIndex);

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        Thread.Sleep(300);
                    }

                    bResult = oBlynclightController.StartMusicPlay(nSelectedDeviceIndex);
                }
            }
            else
            {
                bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);
                bResult = oBlynclightController.ClearMusicRepeat(nSelectedDeviceIndex);

                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                {
                    Thread.Sleep(300);
                }
                
                bResult = oBlynclightController.StartMusicPlay(nSelectedDeviceIndex);
                bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);               
            }

            WriteToLog("checkBoxRepeatMusic_CheckedChanged Exit");
        }

        private void buttonSetRgbValues_Click(object sender, EventArgs e)
        {
            WriteToLog("buttonSetRgbValues_Click Entry");

            if (checkBoxDisplayLight.Checked)
            {
                SetRgbValues();
            }

            WriteToLog("buttonSetRgbValues_Click Exit");
        }

        private void SetRgbValues()
        {
            WriteToLog("SetRgbValues Entry");

            Boolean bResult = false;

            Byte byRedLevel = 255;
            Byte byGreenLevel = 255;
            Byte byBlueLevel = 255;

            try
            {
                byRedLevel = Byte.Parse(textBoxRed.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\nPlease check Red color value. It should be a value from 0 to 255.", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            try
            {
                byGreenLevel = Byte.Parse(textBoxGreen.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\nPlease check Green color value. It should be a value from 0 to 255.", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            try
            {
                byBlueLevel = Byte.Parse(textBoxBlue.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\nPlease check Blue color value. It should be a value from 0 to 255.", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                return;
            }

            bResult = oBlynclightController.TurnOnRGBLights(nSelectedDeviceIndex, byRedLevel, byGreenLevel, 
                byBlueLevel);

            if (!bResult)
            {
                MessageBox.Show("TurnOnRGBColors failed.", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }

            WriteToLog("SetRgbValues Exit");
        }

        private void comboBoxMusicList_SelectedIndexChanged(object sender, EventArgs e)
        {
            WriteToLog("comboBoxMusicList_SelectedIndexChanged Entry");

            bySelectedMusic = (Byte)(comboBoxMusicList.SelectedIndex + 1);

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20)
            {
                if (checkBoxPlayMusic.Checked == true)
                {
                    bool bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);

                    bResult = oBlynclightController.SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        Thread.Sleep(500);
                    }

                    if (checkBoxRepeatMusic.Checked == true)
                    {
                        bResult = oBlynclightController.SetMusicRepeat(nSelectedDeviceIndex);
                    }
                    else
                    {
                        bResult = oBlynclightController.ClearMusicRepeat(nSelectedDeviceIndex);
                    }

                    if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                        oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                    {
                        Thread.Sleep(500);
                    }

                    bResult = oBlynclightController.StartMusicPlay(nSelectedDeviceIndex);
                }
            }

            WriteToLog("comboBoxMusicList_SelectedIndexChanged Exit");
        }

        private void comboBoxFlashSpeedList_SelectedIndexChanged(object sender, EventArgs e)
        {
            WriteToLog("comboBoxFlashSpeedList_SelectedIndexChanged Entry");

            bySelectedFlashSpeed = (Byte)(comboBoxFlashSpeedList.SelectedIndex + 1);

            if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40S_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_PLANTRONICS_STATUS_INDICATOR ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V30 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_CHIPSET_V40_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_EMBRAVA_EMBEDDED_V30 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA110 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA120 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA || 
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_MINI_CHIPSET_V40S_VERSION20 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA210 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_HEADSET_CHIPSET_V30_LUMENA220 ||
                oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_NAMEDISPLAY_DEVICE)
            {
                // Select light flash speed
                bool bResult = oBlynclightController.SelectLightFlashSpeed(nSelectedDeviceIndex, bySelectedFlashSpeed);
                if (bResult == false)
                {
                    MessageBox.Show("SelectLightFlashSpeed failed", "BlynclightTest",
                        MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
            }

            WriteToLog("comboBoxFlashSpeedList_SelectedIndexChanged Exit");
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            WriteToLog("trackBar1_Scroll Entry");

            byVolumeLevel = (Byte)trackBar1.Value;
            bool bResult = false;

            bySelectedMusic = (Byte)(comboBoxMusicList.SelectedIndex + 1);

            if (checkBoxPlayMusic.Checked == true)
            {
                bResult = oBlynclightController.StopMusicPlay(nSelectedDeviceIndex);

                bResult = oBlynclightController.SelectMusicToPlay(nSelectedDeviceIndex, bySelectedMusic);

                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                {
                    Thread.Sleep(250);
                }

                bResult = oBlynclightController.SetMusicVolume(nSelectedDeviceIndex, byVolumeLevel);

                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                {
                    Thread.Sleep(250);
                }

                if (checkBoxRepeatMusic.Checked == true)
                {
                    bResult = oBlynclightController.SetMusicRepeat(nSelectedDeviceIndex);
                }
                else
                {
                    bResult = oBlynclightController.ClearMusicRepeat(nSelectedDeviceIndex);
                }

                if (oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V30S ||
                    oBlynclightController.aoDevInfo[nSelectedDeviceIndex].byDeviceType == DEVICETYPE_BLYNC_WIRELESS_CHIPSET_V40S)
                {
                    Thread.Sleep(500);
                }

                bResult = oBlynclightController.StartMusicPlay(nSelectedDeviceIndex);
            }

            WriteToLog("trackBar1_Scroll Exit");
        }

        private void vScrollBarRed_Scroll(object sender, ScrollEventArgs e)
        {
            WriteToLog("vScrollBarRed_Scroll Entry");
            textBoxRed.Text = vScrollBarRed.Value.ToString();
            WriteToLog("trackBar1_Scroll Exit");
        }

        private void vScrollBarGreen_Scroll(object sender, ScrollEventArgs e)
        {
            WriteToLog("vScrollBarGreen_Scroll Entry");
            textBoxGreen.Text = vScrollBarGreen.Value.ToString();
            WriteToLog("vScrollBarGreen_Scroll Exit");
        }

        private void vScrollBarBlue_Scroll(object sender, ScrollEventArgs e)
        {
            WriteToLog("vScrollBarBlue_Scroll Entry");
            textBoxBlue.Text = vScrollBarBlue.Value.ToString();
            WriteToLog("vScrollBarBlue_Scroll Exit");
        }

        private void CleanUp()
        {
            WriteToLog("CleanUp Entry");

            oBlynclightController.CloseDevices(nNumberOfBlyncDevices);

            WriteToLog("CleanUp Exit");
        }

        private void buttonClearLog_Click(object sender, EventArgs e)
        {
            textBoxLog.Text = "";
        }

        private void buttonGetUid_Click(object sender, EventArgs e)
        {
            ulong unUniqueId = 0x00;

            unUniqueId = oBlynclightController.GetDeviceUniqueId(nSelectedDeviceIndex);

            // Print the activity string
            this.textBoxLog.AppendText("Device Unique ID: " + unUniqueId);

            this.textBoxLog.AppendText("\n");

            this.textBoxLog.AppendText("\n");
        }

        private void buttonDisplayTextPxL1_Click(object sender, EventArgs e)
        {
            String nameStringL1 = textBoxNameStringL1.Text;

            if (String.IsNullOrEmpty(nameStringL1) == true)
            {
                return;
            }

            String nameString = "Test String 1";

            nameString = nameString.Substring(0, 3);

            bool bResult = false;

            // bool bResult = oBlynclightController.ClearDisplayOnNameDisplayDevice(nSelectedDeviceIndex);

            nFontTypeL1 = comboBoxFontsL1.SelectedIndex + 1;

            bResult = oBlynclightController.DisplayTextOnNameDisplayUsingPixelControlNameAdjust(nSelectedDeviceIndex, nameStringL1, nFontTypeL1);
        }

        private void buttonClearText_Click(object sender, EventArgs e)
        {
            bool bResult = true;

            bResult = oBlynclightController.ClearTextOnNameDisplay(nSelectedDeviceIndex);
        }

        private void buttonResetNameDisplay_Click(object sender, EventArgs e)
        {
            bool bResult = true;

            bResult = oBlynclightController.ResetNameDisplay(nSelectedDeviceIndex);
        }

        private void buttonTurnOnPixels_Click(object sender, EventArgs e)
        {
            oBlynclightController.TurnOnAllPixelsOnNameDisplay(nSelectedDeviceIndex);
        }

        int nFontTypeL1 = 1;

        private void comboBoxFonts_SelectedIndexChanged(object sender, EventArgs e)
        {
            nFontTypeL1 = comboBoxFontsL1.SelectedIndex + 1;
        }

        private void buttonDisplayTextDefault_Click(object sender, EventArgs e)
        {
            String nameString = textBoxNameStringL1.Text;

            if (String.IsNullOrEmpty(nameString) == true)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.DisplayTextOnNameDisplay(nSelectedDeviceIndex, nameString);
        }

        private void buttonGetNdUID_Click(object sender, EventArgs e)
        {
            ulong unUniqueId = 0x00;

            unUniqueId = oBlynclightController.GetDeviceUniqueId(nSelectedDeviceIndex);

            //Thread.Sleep(10);

            // Print the activity string
            this.textBoxLog.AppendText("Device Unique ID: " + unUniqueId);

            this.textBoxLog.AppendText("\n");

            this.textBoxLog.AppendText("\n");
        }

        private void buttonRed1_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnRedLight(nSelectedDeviceIndex);
            if (bResult == false)
            {
                MessageBox.Show("TurnOnRedLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void buttonGreen1_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnGreenLight(nSelectedDeviceIndex);
            if (bResult == false)
            {
                MessageBox.Show("TurnOnGreenLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void buttonBlue1_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnBlueLight(nSelectedDeviceIndex);
            if (bResult == false)
            {
                MessageBox.Show("TurnOnBlueLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void buttonWhite1_Click(object sender, EventArgs e)
        {
            bool bResult = false;

            bResult = oBlynclightController.TurnOnWhiteLight(nSelectedDeviceIndex);
            if (bResult == false)
            {
                MessageBox.Show("TurnOnWhiteLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void buttonOrange_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnOrangeLight(nSelectedDeviceIndex);

            if (bResult == false)
            {
                MessageBox.Show("TurnOnOrangeLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void buttonYellow1_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnYellowLight(nSelectedDeviceIndex);

            if (bResult == false)
            {
                MessageBox.Show("TurnOnYellowLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void buttonPurple_Click(object sender, EventArgs e)
        {
            bool bDisplayLight = checkBoxDisplayLight.Checked;

            if (bDisplayLight == false)
            {
                return;
            }

            bool bResult = false;

            bResult = oBlynclightController.TurnOnMagentaLight(nSelectedDeviceIndex);

            if (bResult == false)
            {
                MessageBox.Show("TurnOnMagentaLight failed", "BlynclightTest",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void checkBoxMute_CheckedChanged(object sender, EventArgs e)
        {
            if (nSelectedDeviceIndex < 0)
            {
                return;
            }

            if (checkBoxMute.Checked)
            {
                oBlynclightController.SetVolumeMute(nSelectedDeviceIndex);
            }
            else
            {
                oBlynclightController.ClearVolumeMute(nSelectedDeviceIndex);
            }
        }
    }
}
