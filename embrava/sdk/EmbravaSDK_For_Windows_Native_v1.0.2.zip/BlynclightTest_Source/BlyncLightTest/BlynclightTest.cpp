// BlynclightTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "BlynclightNative.h"

int main()
{
	int nNumberOfBlyncDevices = 0;

	BOOL bResult = TRUE;
	
	printf("Blynclight Native Test Application\n\n");

	do
	{
		nNumberOfBlyncDevices = InitBlyncDevices();

		if (nNumberOfBlyncDevices < 1)
		{
			printf("No Blync Devices Connected\n\n");
			break;
		}

		printf("Number of Blync Devices Connected: %d \n\n", nNumberOfBlyncDevices);

		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			printf("Device %d: %s\n\n", (aoDevInfo[i].nDeviceIndex + 1), aoDevInfo[i].szDeviceName);
		}

		printf("API function testing starts for connected devices...\n\n");

		printf("TurnOnRGBLights for 3 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = TurnOnRGBLights(i, 200, 200, 200); // RGB values range from 0 to 255
		}
		Sleep(3000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("TurnOnRedLight for 3 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = TurnOnRedLight(i); 
		}
		Sleep(3000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("TurnOnGreenLight for 3 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = TurnOnGreenLight(i);
		}
		Sleep(3000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("TurnOnBlueLight for 3 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = TurnOnBlueLight(i);
		}
		Sleep(3000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("TurnOnCyanLight for 3 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = TurnOnCyanLight(i);
		}
		Sleep(3000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("TurnOnOrangeLight for 3 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
		bResult = TurnOnOrangeLight(i);
		}
		Sleep(3000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("TurnOnYellowLight for 3 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = TurnOnYellowLight(i);
		}
		Sleep(3000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("TurnOnWhiteLight for 3 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = TurnOnWhiteLight(i);
		}
		Sleep(3000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("TurnOnMagentaLight for 3 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = TurnOnMagentaLight(i);
		}
		Sleep(3000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("SetLightDim for 3 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = SetLightDim(i);
		}
		Sleep(3000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("ClearLightDim \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = ClearLightDim(i);
		}
		Sleep(3000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("FlashLight at Low Speed for 5 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = SelectLightFlashSpeed(i, 1);
			if (bResult == FALSE)
			{
				break;
			}
			bResult = StartLightFlash(i);
		}
		Sleep(5000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("FlashLight at Medium Speed for 5 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = SelectLightFlashSpeed(i, 2);
		}
		Sleep(5000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("FlashLight at High Speed for 5 seconds \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = SelectLightFlashSpeed(i, 3);
		}
		Sleep(5000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("Stop Light Flashing \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = StopLightFlash(i);
		}
		Sleep(1000);
		if (bResult == FALSE)
		{
			break;
		}

		printf("Playing Music 1 @ Volume level 10 \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = SelectMusicToPlay(i, 1);
			if (bResult == FALSE)
			{
				break;
			}
			bResult = SetMusicRepeat(i);
			if (bResult == FALSE)
			{
				break;
			}
			bResult = SetMusicVolume(i, 10);
			if (bResult == FALSE)
			{
				break;
			}
			bResult = StartMusicPlay(i);			
		}
		if (bResult == FALSE)
		{
			break;
		}
		Sleep(8000);

		printf("Stop Playing Music \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = ClearMusicRepeat(i);
			if (bResult == FALSE)
			{
				break;
			}
			bResult = StopMusicPlay(i);
		}
		if (bResult == FALSE)
		{
			break;
		}
		
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			UINT64 uniqueId = GetDeviceUniqueId(i);
			printf("Device Unique ID of Device %d : %d \n\n", (i + 1), uniqueId);
		}		

		printf("Resetting Device \n\n");
		for (int i = 0; i < nNumberOfBlyncDevices; i++)
		{
			bResult = ResetLight(i);
		}

		CloseDevices(nNumberOfBlyncDevices);

	} while (FALSE);

	printf("Press Enter to exit...");

	getchar();

    return 0;
}

