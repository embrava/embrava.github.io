Stop-Process -name EmbravaConnect -Force
$users = Get-ChildItem C:\Users
foreach ($user in $users) {
    $folder = "$($user.fullname)\AppData\Local\Embrava_Pty_Ltd"
    If (Test-Path $folder) {
        Get-ChildItem $folder | Remove-Item -Recurse -Force -ErrorAction silentlycontinue 
    } 
}