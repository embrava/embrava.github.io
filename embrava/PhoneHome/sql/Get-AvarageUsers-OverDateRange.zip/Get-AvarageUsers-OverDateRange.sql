/****** Script for SelectTopNRows command from SSMS  ******/
DECLARE @StartDate DATE, @EndDate DATE, @AverageByDays INT
SET @StartDate = '2023-02-12'
SET @EndDate = '2023-02-15'
SET @AverageByDays = '4'
DECLARE @result_table TABLE (DateValue DATETIME, UID CHAR(50), Activity CHAR(20));
INSERT INTO @result_table (DateValue, UID, Activity)
SELECT DISTINCT * FROM [dbo].[EmbravaConnect_Activity]
WHERE Activity = 'Running' AND Date BETWEEN @StartDate AND @EndDate;
DECLARE @row_count INT;
SELECT @row_count = COUNT(*) FROM @result_table
SELECT  CONVERT(FLOAT,  @row_count) / @AverageByDays AS AverageUsersOverSpecifiedDays

